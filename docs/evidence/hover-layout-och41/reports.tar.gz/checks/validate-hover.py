import json,subprocess,time,os
from pathlib import Path
out=Path(__file__).parent
commands=[
 ('native',['./scripts/gpuio','exec','cargo','test','--offline','--locked','-j2','-p','gpuio-native','--lib','--features','native-canvas-tests,native-image-tests']),
 ('clippy',['./scripts/gpuio','exec','cargo','clippy','--offline','--workspace','--all-targets','--locked','-j2','--features','gpuio-native/native-canvas-tests,gpuio-native/native-image-tests,gpuio-native/presentation-diagnostics','--','-D','warnings']),
 ('fmt',['./scripts/gpuio','exec','cargo','fmt','--all','--check']),
 ('gallery-build',['./scripts/gpuio','exec','dune','build','-j2','examples/gallery/main.exe']),
]
results=[]
for name,cmd in commands:
 print('START',name,flush=True);start=time.monotonic()
 with (out/('hover-final-'+name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'GPUIO_JOBS':'2'})
 results.append(dict(name=name,command=cmd,exit=r.returncode,seconds=time.monotonic()-start))
 (out/'hover-final-validation.json').write_text(json.dumps(results,indent=2)+'\n')
 print('END',results[-1],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
