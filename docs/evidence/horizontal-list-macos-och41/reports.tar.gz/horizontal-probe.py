import sys,signal,json,time
from pathlib import Path
sys.path.insert(0,'scripts')
import test_gallery as g
from test_canvas import screenshot
out=Path('scratch/agents/root-20261007-access-check/horizontal-probe-001')
def probe(mac,images):
 mac.press(g.TITLE,'Lists, trees & tables');mac.press(g.TITLE,'Horizontal cards')
 mac.press(g.TITLE,'First card')
 g.reveal_gallery_control(mac,'Research cards',None,scroll_in_left_gutter=True)
 mac.wait_text(g.TITLE,'FIELD NOTE / 00000');time.sleep(.2)
 root=mac.wait_find(g.TITLE,'Research cards',None)
 def read(n,depth=0):
  v,children=mac.node_values(n)
  try:return {'role':v[0],'title':v[1],'description':v[2],'value':v[3],'bounds':list(g.element_rect(mac,n)),'children':[read(c,depth+1) for c in children] if depth<6 else []}
  finally:
   for c in children:mac.release(c)
 try: data=read(root)
 finally:mac.release(root)
 (out/'tree.json').write_text(json.dumps(data,indent=2))
 screenshot(mac,out/'cards.png',title=g.TITLE)
 print('HORIZONTAL_PROBE_OK',flush=True)
def timeout(*_):raise RuntimeError('probe watchdog')
signal.signal(signal.SIGALRM,timeout);signal.alarm(90)
g.exercise_shell=probe
sys.argv=['scripts/test_gallery.py','--section','shell','--images',str(out)]
g.main()
