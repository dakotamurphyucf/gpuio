from pathlib import Path
import os,subprocess,json,time
p=Path('scratch/agents/root-20261004-resumed'); results=[]
checks=[('fmt',['./scripts/gpuio','exec','cargo','fmt','--all']),('native-unit',['./scripts/gpuio','exec','cargo','test','-p','gpuio-native','--features','native-image-tests,native-canvas-tests','--lib','--locked','-j2']),('clippy',['./scripts/gpuio','exec','cargo','clippy','-p','gpuio-native','--features','native-tests,native-canvas-tests,native-image-tests','--all-targets','--locked','-j2','--','-D','warnings']),('chat-build',['./scripts/gpuio','build','examples/agent_chat/main.exe'])]
for name,args in checks:
 start=time.time();print('START',name,flush=True)
 with (p/f'results-pointer-{name}.log').open('w') as log:r=subprocess.run(args,env={**os.environ,'GPUIO_JOBS':'2'},stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,args=args,exit=r.returncode,seconds=time.time()-start));(p/'results-pointer-checks.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
