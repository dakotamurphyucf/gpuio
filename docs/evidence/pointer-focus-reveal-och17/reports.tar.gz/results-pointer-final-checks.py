from pathlib import Path
import os,subprocess,json,time
p=Path('scratch/agents/root-20261004-resumed'); results=[]
checks=[('native-link',['./scripts/gpuio','exec','cargo','test','-p','gpuio-native','--features','native-image-tests','--test','native_link','--locked','-j2']),('native-table',['./scripts/gpuio','exec','cargo','test','-p','gpuio-native','--features','native-image-tests','--test','native_table_host','--locked','-j2']),('dune',['./scripts/gpuio','exec','dune','build','@all','@runtest','@fmt','-j2'])]
for name,args in checks:
 start=time.time();print('START',name,flush=True)
 with (p/f'results-pointer-{name}.log').open('w') as log:r=subprocess.run(args,env={**os.environ,'GPUIO_JOBS':'2'},stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,args=args,exit=r.returncode,seconds=time.time()-start));(p/'results-pointer-final-checks.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
