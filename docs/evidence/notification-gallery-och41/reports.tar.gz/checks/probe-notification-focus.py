import sys, subprocess, time, ctypes as C
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from test_agent_chat import Mac
from test_gallery import TITLE, activate, focus_gallery_control, reveal_gallery_control, element_rect
child=subprocess.Popen(['_build/default/examples/gallery/main.exe'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
mac=None
try:
 mac=Mac(child.pid,child)
 mac.press(TITLE,'Commands & feedback')
 reveal_gallery_control(mac,'Layer notification cards','AXCheckBox')
 activate(mac,mac.wait_find(TITLE,'Layer notification cards','AXCheckBox'))
 activate(mac,mac.wait_find(TITLE,'Animate notifications','AXCheckBox'))
 focus_gallery_control(mac,'Notifications','AXGroup')
 time.sleep(.8)
 mac.key(48)
 time.sleep(.2)
 node=mac.attr(mac.app,'AXFocusedUIElement')
 for _ in range(14):
  if not node: break
  print('FOCUSED_PARENT',[mac.text(node,k) for k in ('AXRole','AXTitle','AXDescription','AXValue')],flush=True)
  parent=mac.attr(node,'AXParent');mac.release(node);node=parent
 if node: mac.release(node)
 for label in ('Workspace saved','Research complete','A new idea is ready'):
  card=mac.wait_find(TITLE,label)
  print('CARD',label,mac.text(card,'AXRole'),element_rect(mac,card),flush=True)
  mac.release(card)
 mac.key(53)
 time.sleep(.6)
 focus_gallery_control(mac,'Notifications','AXGroup')
 for label in ('Workspace saved','Research complete','A new idea is ready'):
  node=mac.find(TITLE,label)
  print('AFTER_ESCAPE',label,bool(node),flush=True)
  if node:mac.release(node)
 mac.close(TITLE)
 child.wait(timeout=10)
finally:
 if mac: mac.release(mac.app)
 if child.poll() is None:
  child.terminate()
  try: child.wait(timeout=5)
  except subprocess.TimeoutExpired: child.kill();child.wait()
