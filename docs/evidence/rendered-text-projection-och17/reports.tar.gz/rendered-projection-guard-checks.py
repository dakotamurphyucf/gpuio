from pathlib import Path
import json,os,signal,subprocess,time
notes=Path('scratch/agents/root-20261004-resumed');env=dict(os.environ,GPUIO_JOBS='2',RUST_BACKTRACE='1')
checks=[
 ('native-full-016',['./scripts/gpuio','exec','cargo','test','--offline','--locked','-j2','-p','gpuio-native','--lib','--features','native-canvas-tests,native-image-tests'],240),
 ('clippy-017',['./scripts/gpuio','exec','cargo','clippy','--offline','--locked','-j2','-p','gpuio-native','--all-targets','--features','native-canvas-tests,native-image-tests,presentation-diagnostics','--','-D','warnings'],300),
 ('dune-018',['./scripts/gpuio','exec','dune','build','-j2','@all','@runtest','@fmt'],1800),
]
results=[]
for name,command,timeout in checks:
 path=notes/('rendered-projection-'+name+'.log');start=time.monotonic();print('START',name,flush=True)
 with path.open('w') as log:
  child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:status=child.wait(timeout=timeout)
  except BaseException:
   os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 result=dict(name=name,command=command,exit=status,seconds=time.monotonic()-start,log=str(path))
 results.append(result);(notes/'rendered-projection-guard-checks.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,status,flush=True)
 if status:raise SystemExit(status)
