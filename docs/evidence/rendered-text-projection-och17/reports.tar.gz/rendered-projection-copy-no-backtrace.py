from pathlib import Path
import ctypes as C,json,subprocess,sys,time,hashlib
sys.path.insert(0,str(Path('scripts').resolve()))
from test_agent_chat import Mac
from test_gallery import TITLE,document_reading_order,expect_focus
from mac_input_source import foreground_keys
from mac_clipboard import preserved_clipboard
from test_macos_text_selection import Selection
n=Path('scratch/agents/root-20261004-resumed');binary=Path('_build/default/examples/gallery/main.exe').resolve()
report={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
with preserved_clipboard() as board,(n/'rendered-projection-copy-no-backtrace-app.log').open('w') as log:
 child=subprocess.Popen([str(binary),'--trace-windows'],stdout=log,stderr=subprocess.STDOUT);mac=None
 try:
  mac=Mac(child.pid,child);mac.press(TITLE,'Markdown & code');mac.wait_text(TITLE,'Markdown preview');mac.wait_text(TITLE,'A place for ideas')
  report['reading_order']=document_reading_order(mac)
  node=mac.wait_find(TITLE,'Document content','AXGroup')
  try:
   mac.set(node,'AXFocused',mac.true);foreground_keys(mac);expect_focus(mac,'Document content','AXGroup')
   mac.key(0,flags=1<<20);time.sleep(.2)
   report['selected_text']=mac.text(node,'AXSelectedText')
   try:report['selected_range']=Selection(mac).read(node)
   except AssertionError as error:report['range_error']=str(error)
   seq=board.call(board.board,'changeCount',result=C.c_long);mac.key(8,flags=1<<20)
   deadline=time.monotonic()+5
   while board.call(board.board,'changeCount',result=C.c_long)==seq:
    if time.monotonic()>deadline:raise AssertionError('Copy did not update pasteboard')
    time.sleep(.025)
   report['copied_rendered_text']=board.text()
   assert 'A place for ideas' in report['copied_rendered_text'];assert '**Markdown**' not in report['copied_rendered_text']
  finally:mac.release(node)
  mac.close(TITLE);assert child.wait(timeout=15)==0
  report['probe_complete']=True
 finally:
  if mac:mac.release(mac.app)
  if child.poll() is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait()
  report['child_exit']=child.returncode
  (n/'rendered-projection-copy-no-backtrace.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
report['clipboard_restored']=True
(n/'rendered-projection-copy-no-backtrace.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
