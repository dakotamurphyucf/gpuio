//! Native cache reuse must preserve semantic content and action routing.
use super::*;

struct CachedDocument {
    text: Entity<TextViewState>,
    renders: Arc<AtomicUsize>,
    clicks: Arc<AtomicUsize>,
}
impl Render for CachedDocument {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        self.renders.fetch_add(1, Ordering::Relaxed);
        let clicks = self.clicks.clone();
        div().size_full()
            .child(TextView::new(&self.text))
            .child(div().id("cached-control").role(accesskit::Role::Button)
                .aria_label("Cached action").h(px(30.)).w(px(180.))
                .on_a11y_action(gpui::AccessibleAction::Click, move |_, _, _| {
                    clicks.fetch_add(1, Ordering::Relaxed);
                }))
    }
}
struct Parent(Entity<CachedDocument>);
impl Render for Parent {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        div().w(px(440.)).h(px(200.))
            .child(gpui_base::TextSelectionLayer)
            .child(self.0.clone().cached(gpui::StyleRefinement::default().size_full()))
    }
}
#[test]
fn cached_document_keeps_semantics_and_actions_without_rendering_again() {
    let mut app = TestAppContext::single();
    app.update(gpui_base::init);
    let renders = Arc::new(AtomicUsize::new(0));
    let clicks = Arc::new(AtomicUsize::new(0));
    let (parent, cx) = app.add_window_view(|_, cx| {
        Parent(cx.new(|cx| CachedDocument {
            text: cx.new(|cx| {
                let mut state = TextViewState::externally_prepared(cx);
                state.set_prepared(PreparedText::parse("Cached 世界", MarkdownExtensions::default()).unwrap(), None, cx);
                state
            }), renders: renders.clone(), clicks: clicks.clone(),
        }))
    });
    cx.simulate_a11y_active(true);
    draw(cx);
    let initial = cx.a11y_tree().unwrap();
    let control = initial.nodes.iter().find(|(_, node)| node.label() == Some("Cached action")).expect("initial control").0;
    let document = initial.nodes.iter().find(|(_, node)| node.role() == accesskit::Role::Document).expect("initial document").0;
    let count = renders.load(Ordering::Relaxed);
    parent.update(cx, |_, cx| cx.notify());
    draw(cx);
    assert_eq!(renders.load(Ordering::Relaxed), count, "test must actually reuse the cache");
    let cached = cx.a11y_tree().unwrap();
    assert!(cached.nodes.iter().any(|(id, node)| *id == control && node.label() == Some("Cached action")), "cached native button disappeared from accessibility");
    assert!(cached.nodes.iter().any(|(id, node)| *id == document && node.role() == accesskit::Role::Document), "cached document retained");
    cx.simulate_a11y_action(accesskit::ActionRequest {
        action: accesskit::Action::Click, target_node: control,
        target_tree: accesskit::TreeId::ROOT, data: None,
    });
    assert_eq!(clicks.load(Ordering::Relaxed), 1, "cached action listener retained");
}
