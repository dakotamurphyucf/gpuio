from pathlib import Path
import os,subprocess
root=Path.cwd();logs=root/'scratch/agents/root-20261004-resumed/cursor';logs.mkdir(exist_ok=True)
env=os.environ.copy();env['GPUIO_JOBS']='2'
steps=[
 ('rust-fmt',['cargo','fmt','--all']),
 ('ocaml-fmt',['ocamlformat','-i','lib/core/chart_inspection.mli','lib/protocol/chart_inspection_wire.ml','test/chart/chart_inspection_test.ml','examples/charts/samples/inspection.ml','examples/charts/samples/inspection.mli']),
 ('chart-expect',['dune','build','-j2','@test/chart/runtest']),
 ('protocol',['cargo','test','-p','gpuio-protocol','--locked','-j2']),
 ('native',['cargo','test','-p','gpuio-native','--features','native-canvas-tests,native-image-tests','--lib','--locked','-j2']),
 ('native-input',['cargo','test','-p','gpuio-native','--features','native-canvas-tests','--test','native_chart_input','--locked','-j2']),
]
for name,args in steps:
 print('RUN',name,flush=True)
 with (logs/(name+'.log')).open('w') as log:
  r=subprocess.run(['./scripts/gpuio','exec',*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('RESULT',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
