from pathlib import Path
import os,subprocess
root=Path.cwd();logs=root/'scratch/agents/root-20261004-resumed/cursor'
env=os.environ.copy();env['GPUIO_JOBS']='2'
steps=[
 ('fmt',['./scripts/gpuio','exec','cargo','fmt','--all']),
 ('gallery-build',['./scripts/gpuio','build','examples/gallery/main.exe']),
 ('gallery',['python3','scripts/test_gallery.py','--section','chart-inspection','--images',str(logs/'gallery-images')]),
 ('native-view',['./scripts/gpuio','exec','cargo','test','-p','gpuio-native','--features','native-canvas-tests','--test','native_chart_view','--locked','-j2']),
 ('clippy',['./scripts/gpuio','exec','cargo','clippy','--workspace','--all-targets','--locked','-j2','--','-D','warnings']),
 ('feature-clippy',['./scripts/gpuio','exec','cargo','clippy','-p','gpuio-native','--features','native-canvas-tests,native-image-tests','--lib','--tests','--locked','-j2','--','-D','warnings']),
 ('dune',['./scripts/gpuio','exec','dune','build','-j2','@all','@runtest','@fmt']),
 ('consumer',['python3','scripts/test_extension_consumer.py','--example','gallery','--run','--gallery-section','chart-inspection','--workspace',str(logs/'installed')]),
]
for name,args in steps:
 print('RUN',name,flush=True)
 with (logs/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('RESULT',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
