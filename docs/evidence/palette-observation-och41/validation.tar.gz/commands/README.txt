Base 5ea77dd plus archived patch/new files. macOS14.5 arm64; isolated stockOCaml5.3/Bonsai0.17/Core/Eio.
PASS GPUIO_JOBS=2 ./scripts/gpuio exec cargo test -p gpuio-native --lib --features native-image-tests -- --test-threads=1
960passed/2existing skips. Later lint-only redundant.into/as removed, strictclippy recompiles.
PASS GPUIO_JOBS=2 ./scripts/gpuio exec cargo test -p gpuio-protocol --test palette_state
PASS GPUIO_JOBS=2 ./scripts/gpuio exec cargo clippy -p gpuio-native -p gpuio-protocol --all-targets --features native-image-tests -- -D warnings
PASS GPUIO_JOBS=2 ./scripts/gpuio exec dune build -j 2 @runtest @fmt examples/gallery/main.exe (build-final log)
PASS GPUIO_JOBS=2 python3 scripts/test_extension_consumer.py --example gallery --workspace scratch/agents/root-20261004-resumed/palette-observation-consumer
PASS python3 -u scratch/agents/root-20261004-resumed/run_palette_observation_gui.py
PASS GPUIO_JOBS=2 ./scripts/gpuio exec cargo fmt --all
PASS python3 -m py_compile scripts/test_gallery.py
PASS git diff --check
Counterfactual FAIL: --features native-image-tests coalesced_query_edits -- --test-threads=1 (before tracking editor revision).
Initial native-tests feature ran only2list tests, not palette TestPlatform tests; native-4/5/final use correctnative-image-tests.
Initial decoder typo, invalid registry-removal fixture, direct Dune runner path, docstring and redundantcastlint failures retained.
No expectations auto-promoted; dune fmt promotions only.
