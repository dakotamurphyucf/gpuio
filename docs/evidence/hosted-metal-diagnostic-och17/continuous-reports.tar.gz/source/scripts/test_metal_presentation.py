#!/usr/bin/env python3
"""Build/run the bounded two-window Metal hook qualification (macOS only).

No VoiceOver, accessibility automation or preference changes. The native probe
closes its windows. The parent also imposes a timeout and requires a fresh report;
an NSApplication exit(0) without completed assertions cannot pass.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--binary", type=Path, help="Use an already built probe")
    parser.add_argument("--idle-before-frames-ms", type=int, default=0,
                        help="Observe native idle-to-active behavior without the OCaml bridge (0..5000)")
    parser.add_argument('--warmup', action='store_true', help='Record a separate active warmup before unchanged strict measured frames')
    parser.add_argument('--continuous-warmup', action='store_true', help='Keep animation scheduled while warmup callbacks settle; report transition render counts')
    args = parser.parse_args()
    if args.continuous_warmup and not args.warmup:
        parser.error('Continuous warmup requires --warmup')
    if not 0 <= args.idle_before_frames_ms <= 5000:
        parser.error("Idle delay must be between 0 and 5000 ms")
    if sys.platform != "darwin":
        raise SystemExit("This qualification requires a macOS Metal desktop")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    report = output / "report.json"
    if report.exists():
        raise SystemExit("Refusing to reuse an existing report; choose a fresh output directory")
    binary = args.binary
    if binary is None:
        command = [str(ROOT / "scripts/gpuio"), "exec", "cargo", "build", "-p", "gpuio-native",
                   "--locked", "--features", "presentation-diagnostics", "--test",
                   "native_metal_presentation", "--message-format=json", "-j", os.environ.get("GPUIO_JOBS", "2")]
        with (output / "build.jsonl").open("w") as stdout, (output / "build.log").open("w") as stderr:
            subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, check=True)
        artifacts = [json.loads(line) for line in (output / "build.jsonl").read_text().splitlines()]
        candidates = [item["executable"] for item in artifacts
                      if item.get("reason") == "compiler-artifact"
                      and item.get("target", {}).get("name") == "native_metal_presentation"
                      and item.get("executable")]
        if len(candidates) != 1:
            raise RuntimeError(f"Expected one current native probe artifact, got {candidates}")
        binary = Path(candidates[0])
    environment = {**os.environ, "GPUIO_PRESENTATION_REPORT": str(report),
                   "GPUIO_PRESENTATION_IDLE_MS": str(args.idle_before_frames_ms),
                   "GPUIO_PRESENTATION_WARMUP": "1" if args.warmup else "0",
                   "GPUIO_PRESENTATION_CONTINUOUS_WARMUP": "1" if args.continuous_warmup else "0"}
    # subprocess.run kills and reaps the child on timeout; no detached process.
    with (output / "native.log").open("w") as log:
        result = subprocess.run([str(binary.resolve())], cwd=ROOT, env=environment,
                                stdout=log, stderr=subprocess.STDOUT, timeout=25 + args.idle_before_frames_ms / 1000 + (14 if args.warmup else 0), check=True)
    data = json.loads(report.read_text())
    if data.get("schema") != 1 or data.get("kind") != "gpui_metal_hook_qualification" or data.get("passed") is not True:
        raise RuntimeError(f"Native qualification did not pass; inspect {report}")
    if data.get("idle_before_frames_ms") != args.idle_before_frames_ms:
        raise RuntimeError("Native probe did not report the requested idle setup")
    if data.get('warmup') != args.warmup or not data.get('warmup_finished'):
        raise RuntimeError('Missing or mismatched warmup configuration/finish')
    if len(data.get('warmup_sessions', [])) != (2 if args.warmup else 0):
        raise RuntimeError('Missing separate warmup records')
    if data.get('continuous_warmup') != args.continuous_warmup:
        raise RuntimeError('Missing or mismatched continuous warmup configuration')
    transition = data.get('transition_unmeasured_render_counts', [])
    if len(transition) != (2 if args.warmup else 0) or any(type(n) is not int or n < 0 for n in transition):
        raise RuntimeError('Missing or invalid unmeasured transition render counts')
    if len(data.get("sessions", [])) != 2:
        raise RuntimeError("Missing independent window results")
    print(json.dumps({"passed": True, "exit_code": result.returncode, "report": str(report),
                      "presented": [s["counts"]["presented"] for s in data["sessions"]]}))


if __name__ == "__main__":
    main()
