from pathlib import Path
import subprocess
base=Path(__file__).resolve().parent
parent='93006c09f5fa82635a0c54c9bdecf499d4be511f'
def source(path):return subprocess.check_output(['git','show',f'{parent}:{path}'],text=True)
s=source('rust/native/tests/native_metal_presentation.rs')
s=s.replace('pub fn run(path: PathBuf, idle_before_frames: Duration)', 'pub fn run(path: PathBuf, idle_before_frames: Duration, warmup: bool)')
needle='''                let sessions = windows
'''
assert s.count(needle)==1
s=s.replace(needle,'''                // Separate, fully retained active warmup. The measured phase
                // below keeps its original 90-frame, zero-loss/zero-skip checks.
                // This is steady-state hookup qualification, not cold startup.
                let mut warmup_reports = Vec::new();
                let mut warmup_finished = !warmup;
                if warmup {
                    let preflight = windows.iter().map(|w| {
                        w.update(cx, |view, window, cx| {
                            let session = Session::start(window, Limits::default()).unwrap();
                            view.running = true;
                            cx.notify();
                            session
                        }).unwrap()
                    }).collect::<Vec<_>>();
                    let start = Instant::now();
                    while start.elapsed() < Duration::from_secs(12) {
                        warmup_finished = windows.iter().all(|w| {
                            w.update(cx, |view, _, _| view.frames == FRAMES).unwrap_or(false)
                        });
                        if warmup_finished { break; }
                        cx.background_executor().timer(Duration::from_millis(20)).await;
                    }
                    for session in &preflight { session.stop(); }
                    let settlement = Instant::now();
                    while settlement.elapsed() < Duration::from_secs(2)
                        && preflight.iter().any(|s| s.pending() != 0) {
                        cx.background_executor().timer(Duration::from_millis(10)).await;
                    }
                    warmup_finished &= preflight.iter().all(|s| s.pending() == 0);
                    warmup_reports = preflight.iter().map(report).collect();
                    // Snapshots retain values only. Drop the old measurement
                    // owners before starting distinct replacement sessions.
                    drop(preflight);
                    for window in &windows {
                        window.update(cx, |view, _, _| {
                            view.frames = 0;
                            view.running = false;
                        }).unwrap();
                    }
                }
                let sessions = windows
''')
s=s.replace('let valid = animation_samples &&', 'let valid = warmup_finished && animation_samples &&')
s=s.replace('"passed": valid, "idle_before_frames_ms":', '"passed": valid, "warmup": warmup, "warmup_finished": warmup_finished, "warmup_sessions": warmup_reports, "idle_before_frames_ms":')
s=s.replace('macos::run(path.into(), std::time::Duration::from_millis(idle_ms));','macos::run(path.into(), std::time::Duration::from_millis(idle_ms), std::env::var("GPUIO_PRESENTATION_WARMUP").is_ok_and(|v| v == "1"));')
(base/'native_metal_presentation_warmup.rs').write_text(s)
s=source('scripts/test_metal_presentation.py')
s=s.replace('    args = parser.parse_args()', '''    parser.add_argument('--warmup', action='store_true', help='Record a separate active warmup before unchanged strict measured frames')
    args = parser.parse_args()''')
s=s.replace('"GPUIO_PRESENTATION_IDLE_MS": str(args.idle_before_frames_ms)}','"GPUIO_PRESENTATION_IDLE_MS": str(args.idle_before_frames_ms),\n                   "GPUIO_PRESENTATION_WARMUP": "1" if args.warmup else "0"}')
s=s.replace('timeout=25 + args.idle_before_frames_ms / 1000', 'timeout=25 + args.idle_before_frames_ms / 1000 + (14 if args.warmup else 0)')
s=s.replace('    if len(data.get("sessions", [])) != 2:', '''    if data.get('warmup') != args.warmup or not data.get('warmup_finished'):
        raise RuntimeError('Missing or mismatched warmup configuration/finish')
    if len(data.get('warmup_sessions', [])) != (2 if args.warmup else 0):
        raise RuntimeError('Missing separate warmup records')
    if len(data.get("sessions", [])) != 2:''')
(base/'test_metal_presentation_warmup.py').write_text(s)
s=source('.github/workflows/metal-presentation-diagnostic.yml')
s=s.replace('Two-window GPUI probe after 2500 ms startup idle','Two-window GPUI probe with separately recorded active warmup')
s=s.replace('--idle-before-frames-ms 2500','--warmup').replace('metal-native-hook-intel-idle2500','metal-native-hook-intel-warmup')
(base/'metal-presentation-warmup.yml').write_text(s)
print('Prepared isolated warmup fixture; no main-worktree change')
