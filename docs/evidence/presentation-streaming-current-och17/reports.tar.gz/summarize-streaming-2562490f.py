import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
batch = json.loads((base / 'streaming-2562490f-batch.json').read_text())
summary = {k: batch[k] for k in ('revision', 'executable_source_revision', 'executable_sha256', 'plan', 'running')}
summary['trials'] = []
for trial in batch['trials']:
    path = base / f"streaming-2562490f-{trial['name']}" / 'report.json'
    raw = path.read_bytes()
    report = json.loads(raw)
    row = {k: v for k, v in trial.items() if k != 'command'}
    row.update(report_sha256=hashlib.sha256(raw).hexdigest())
    for k in ('revision', 'dirty', 'executable_sha256', 'budget_failures', 'peak_rss_bytes', 'wall_seconds', 'cpu_user_seconds', 'cpu_system_seconds'):
        row[k] = report.get(k)
    workload = report.get('workload', {})
    row['total_source_bytes'] = workload.get('total_source_bytes')
    row['stream_update_counts'] = [len(x['elapsed_ns']) for x in workload.get('streams', [])]
    row['key_count'] = len(report.get('evidence', {}).get('keys', []))
    row['input_source_restored'] = report.get('evidence', {}).get('input_source_restored')
    row['peak_active_rows'] = workload.get('peak_active_rows')
    cpu = workload.get('interval')
    if cpu:
        row['streaming'] = dict(elapsed_ns=cpu['elapsed_ns'], histograms={k: {n: v[n] for n in ('count', 'p95', 'p99')} for k, v in cpu['histograms'].items()})
    native = report.get('presentation', {}).get('streaming')
    if native:
        row['streaming']['presentation'] = dict(counts=native['native']['counts'], startup_transition=native['startup_transition'],
            histograms={k: {n: v[n] for n in ('count', 'p95', 'p99')} for k, v in native['native']['histograms'].items()},
            observations=len(native['observations']), all_sampled_active_visible=all(x['active'] and x['visible'] for x in [*native['observations'], native['end_observation']]))
    summary['trials'].append(row)
(base / 'streaming-2562490f-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'running': summary['running'], 'trials': [{k: row.get(k) for k in ('name','complete','driver_exit','budget_failures','input_source_restored')} for row in summary['trials']]}, indent=2))
