import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path('scratch/agents/root-20261007-access-check')
binary = Path('_build/default/examples/performance_presented/streaming/main.exe')
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
assert b'GPUIO_METAL_STARTUP' not in binary.read_bytes()
assert b'GPUIO_IDLE_TRACE' not in binary.read_bytes()
assert hashlib.sha256(binary.read_bytes()).hexdigest() == '60388014ddb81f069323dfbb18baf29e3b071c928aeef6a45090a8e9b096b373'
assert all(p.startswith('docs/') for p in subprocess.check_output(['git', 'diff', '--name-only', '2562490f', 'HEAD'], text=True).splitlines())
report = dict(executable_source_revision='2562490ffee13059a6ca99ddc7108556f2a3972a', revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
              plan='One warm-up followed by exactly three full 120-second four-stream trials with 1200 foreground key events each using code from 2562490f (subsequent commits only change docs); unchanged budgets; retain every outcome; stop remaining trials on child execution failure or missing input-source restoration',
              trials=[])
env = dict(os.environ)
env.pop('GPUIO_TRACE_METAL_STARTUP', None)
awake = subprocess.Popen(['/usr/bin/caffeinate', '-di', '-w', str(os.getpid())])
try:
    for name, smoke in [('warmup', True), ('001', False), ('002', False), ('003', False)]:
        output = base / f'streaming-2562490f-{name}'
        cmd = ['python3', 'scripts/measure_streaming_typing.py', '--build-profile', 'release',
               '--presentation', '--smoke' if smoke else '--check-budgets', '--timeout', '1200',
               '--executable', str(binary), '--output', str(output)]
        report['running'] = name
        (base / 'streaming-2562490f-batch.json').write_text(json.dumps(report, indent=2) + '\n')
        print('START', name, flush=True)
        with (base / f'streaming-2562490f-{name}.log').open('w') as log:
            result = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        child_report = json.loads((output / 'report.json').read_text())
        report['trials'].append(dict(name=name, command=cmd, driver_exit=result.returncode,
                                    complete=child_report['complete'], error=child_report.get('failure', child_report.get('error')),
                                    child_returncode=child_report.get('returncode')))
        report['running'] = None
        (base / 'streaming-2562490f-batch.json').write_text(json.dumps(report, indent=2) + '\n')
        print('FINISH', report['trials'][-1], flush=True)
        if child_report.get('returncode') != 0 or child_report.get('evidence', {}).get('input_source_restored') is not True:
            raise RuntimeError('Stop after child failure or unverified input-source restoration; do not repeat broken execution')
finally:
    awake.terminate()
    awake.wait(timeout=5)
    report['keep_awake_reaped'] = True
    (base / 'streaming-2562490f-batch.json').write_text(json.dumps(report, indent=2) + '\n')
