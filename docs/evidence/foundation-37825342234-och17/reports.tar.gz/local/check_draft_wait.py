import sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path.cwd() / 'scripts'))
from test_agent_chat_dates_colors import DatesColors

class Probe:
    def __init__(self, values):
        self.values = iter(values)
        self.reads = 0
    def draft(self, title, conversation):
        self.reads += 1
        return next(self.values)

expected = 'Civil dates and colors preserve my draft λ'
p = Probe(['', expected])
with patch('test_agent_chat_dates_colors.time.monotonic', side_effect=[0, 0, .03]), patch('test_agent_chat_dates_colors.time.sleep'):
    DatesColors.expect_draft(p, expected)
assert p.reads == 2
p = Probe(['lost text'])
with patch('test_agent_chat_dates_colors.time.monotonic', side_effect=[0, 0, 9]), patch('test_agent_chat_dates_colors.time.sleep'):
    try:
        DatesColors.expect_draft(p, expected)
    except RuntimeError as error:
        assert 'lost text' in str(error) and expected in str(error)
    else:
        raise AssertionError('Persistent mismatch was accepted')
assert p.reads == 1
print('PASS: delayed exact observation accepted; persistent mismatch rejected; reads only')
