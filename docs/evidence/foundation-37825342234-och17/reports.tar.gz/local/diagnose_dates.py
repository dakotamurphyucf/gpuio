import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / 'scripts'))
import test_agent_chat_dates_colors as test
original = test.DatesColors.draft

def draft(self, *args, **kwargs):
    result = original(self, *args, **kwargs)
    print('DRAFT_DIAGNOSTIC', repr(result), flush=True)
    return result

test.DatesColors.draft = draft
test.main()
