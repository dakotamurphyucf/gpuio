from pathlib import Path
import json,os,signal,subprocess,time
p=Path('scratch/agents/root-20261004-resumed')
command=['python3','scripts/test_macos_document_shutdown.py','--log',str(p/'ax-scopes-shutdown.log'),'--report',str(p/'ax-scopes-shutdown.json')]
start=time.monotonic()
with (p/'ax-scopes-shutdown-driver.log').open('w') as log:
 child=subprocess.Popen(command,env=dict(os.environ,RUST_BACKTRACE='1',GPUIO_JOBS='2'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:status=child.wait(timeout=240)
 except BaseException:
  os.killpg(child.pid,signal.SIGKILL);child.wait();raise
(p/'ax-scopes-shutdown-check.json').write_text(json.dumps({'command':command,'exit':status,'seconds':time.monotonic()-start},indent=2)+'\n')
print('SHUTDOWN_EXIT',status)
raise SystemExit(status)
