use accesskit::{Node,NodeId,Role,Tree,TreeId,TreeUpdate,TextPosition,TextSelection};
fn text(value: &str) -> Node {
 let mut n=Node::new(Role::TextRun);n.set_value(value);n.set_character_lengths(value.chars().map(|c|c.len_utf8() as u8).collect::<Vec<_>>());n
}
fn node(role:Role,children:&[u64])->Node {let mut n=Node::new(role);n.set_children(children.iter().map(|i|NodeId(*i)).collect::<Vec<_>>());n}
fn main(){
 let mut input=node(Role::TextInput,&[4]);input.set_value("editor");
 let root=node(Role::Document,&[1,2,3]);
 let tree=accesskit_consumer::Tree::new(TreeUpdate{nodes:vec![(NodeId(0),root),(NodeId(1),text("before")),(NodeId(2),input),(NodeId(4),text("editor")),(NodeId(3),text("after"))],tree:Some(Tree::new(NodeId(0))),tree_id:TreeId::ROOT,focus:NodeId(0)},false);
 println!("parent document including child editor: {:?}",tree.state().root().document_range().text());
 let mut root=node(Role::Document,&[1,2]);root.set_text_selection(TextSelection{anchor:TextPosition{node:NodeId(1),character_index:0},focus:TextPosition{node:NodeId(2),character_index:0}});
 let tree=accesskit_consumer::Tree::new(TreeUpdate{nodes:vec![(NodeId(0),root),(NodeId(1),text("")),(NodeId(2),text(""))],tree:Some(Tree::new(NodeId(0))),tree_id:TreeId::ROOT,focus:NodeId(0)},false);
 let root=tree.state().root();let r=root.text_selection().unwrap();
 println!("two empty run edges: text={:?}, collapsed={}, anchor_utf16={}, focus_utf16={}",r.text(),r.is_degenerate(),root.text_selection_anchor().unwrap().to_global_utf16_index(),root.text_selection_focus().unwrap().to_global_utf16_index());
}
