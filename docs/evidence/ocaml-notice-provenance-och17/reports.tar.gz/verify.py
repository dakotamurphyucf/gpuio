"""Read-only provenance audit of this inventory; no license approval or downloads."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile

root = Path(__file__).resolve().parent
inventory_dir = root / 'inventory'
report = json.loads((inventory_dir / 'inventory.json').read_text())
pins = json.loads(Path('third_party/sources.json').read_text())['native_bonsai']
archive_index = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def archive_files(path, expected):
    raw = path.read_bytes()
    for algorithm, value in expected:
        assert hashlib.new(algorithm, raw).hexdigest() == value, (path, algorithm)
    sha = digest(raw)
    if sha not in archive_index:
        paths, hashes, skipped = {}, {}, []
        with tarfile.open(path) as archive:
            members = archive.getmembers()
            prefixes = {PurePosixPath(m.name).parts[0] for m in members if PurePosixPath(m.name).parts}
            assert len(prefixes) == 1, (path, prefixes)
            for member in members:
                name = PurePosixPath(member.name)
                assert not name.is_absolute() and '..' not in name.parts, member.name
                relative = str(PurePosixPath(*name.parts[1:]))
                if member.isfile():
                    assert relative not in paths, relative
                    data = archive.extractfile(member).read()
                    entry = {'path': relative, 'sha256': digest(data), 'bytes': len(data)}
                    paths[relative] = entry
                    hashes.setdefault(entry['sha256'], []).append(relative)
                elif not member.isdir():
                    skipped.append({'path':relative,'type':repr(member.type),'target':member.linkname})
        archive_index[sha] = (paths, hashes, skipped)
    return sha, archive_index[sha]

rows = []
for package in report['packages']:
    manifest = (inventory_dir/package['manifest_file']).read_bytes()
    assert digest(manifest) == package['manifest_sha256']
    assert Path(package['manifest_path']).read_bytes() == manifest
    row = {key:package[key] for key in ('kind','name','version','manifest_sha256','license_field')}
    row['notices'] = []
    expected = []
    path = None
    if package['kind'] == 'vendor':
        name = Path(package['name']).name
        pin = pins[name]
        expected = [('sha256', pin['archive_sha256'])]
        path = Path('scratch/agents/root-20261004-resumed/bonsai-archives')/(name+'.tar.gz')
        row['source_url'] = f"https://codeload.github.com/janestreet/{name}/tar.gz/{pin['commit']}"
    else:
        # Deliberately accept only the simple top-level url blocks present in
        # these exact manifests, not arbitrary opam syntax or extra-source blocks.
        blocks = re.findall(r'^url \{\n(.*?)^\}', manifest.decode(), re.M|re.S)
        assert len(blocks) <= 1
        if blocks:
            block = blocks[0]
            url = re.search(r'\bsrc:\s*"([^"\\]+)"', block)
            assert url, package['name']
            row['source_url'] = url[1]
            expected = re.findall(r'"(sha256|sha512|md5)=([0-9a-f]+)"', block)
            assert any(alg in ('sha256','sha512') for alg,_ in expected), package['name']
            candidates = [Path('.opam-root/download-cache')/alg/value[:2]/value for alg,value in expected]
            path = next((p for p in candidates if p.is_file()), None)
            if path is None:
                row['source_issue'] = 'hash-pinned source archive not available in local cache'
        else:
            row['source_issue'] = 'no primary source archive in installed manifest; review package classification separately'
    row['declared_checksums'] = [f'{a}={v}' for a,v in expected]
    entries, hashes = {}, {}
    if path is not None:
        sha, (entries, hashes, skipped) = archive_files(path, expected)
        row.update(archive_sha256=sha, archive_file=str(path), archive_regular_files=len(entries), archive_nonregular_entries=skipped)
    for notice in package['notices']:
        data = (inventory_dir/notice['file']).read_bytes()
        assert digest(data) == notice['sha256'] and len(data) == notice['bytes']
        assert (Path(notice['source_directory'])/notice['source_path']).read_bytes() == data
        item = {key:notice[key] for key in ('origin','source_path','file','sha256','bytes')}
        if notice['origin'] in ('source-tree','vendor-source'):
            entry = entries.get(notice['source_path'])
            matches = [notice['source_path']] if entry and entry['sha256'] == notice['sha256'] else []
        else:
            # Installed documents may be renamed or flattened; preserve every
            # original matching member rather than infer its source location.
            matches = hashes.get(notice['sha256'], [])
        item['matching_archive_paths'] = matches
        item['source_verified'] = bool(matches)
        row['notices'].append(item)
    rows.append(row)
# Explicit reviewed provider for this virtual package's installed runtime notice.
# Do not silently apply cross-package matching to any other missing notice.
virtual = next(r for r in rows if r['name'] == 'ocaml' and r['version'] == '5.3.0')
compiler = next(r for r in rows if r['name'] == 'ocaml-compiler' and r['version'] == '5.3.0')
assert compiler['archive_sha256'] == '22c1dd9de21bf43b62d1909041fb5fad648905227bf69550a6a6bef31e654f38'
assert len(virtual['notices']) == 1
notice = virtual['notices'][0]
assert notice['origin'] == 'installed-doc' and notice['source_path'] == 'LICENSE'
provider = next(n for n in compiler['notices'] if n['source_path'] == 'LICENSE')
assert provider['source_verified'] and notice['sha256'] == provider['sha256']
assert notice['sha256'] == '65f47d3bf5a921011ac7fa30f23d54f9dffbe7683921eeb116d5ce8dc26ff0c1'
notice.update(source_verified=True, matching_archive_paths=['LICENSE'],
              source_package='ocaml-compiler.5.3.0', source_archive_sha256=compiler['archive_sha256'])
virtual['source_issue'] = 'No primary archive: installed LICENSE explicitly verified against matching compiler archive; this does not attest configuration helper sources.'
result = {'schema_version':1,'license_review_complete':False,'scope':'Exact-byte provenance of collected notices; not full source/build, embedded attribution, license interpretation or binary link coverage.','inventory_sha256':digest((inventory_dir/'inventory.json').read_bytes()),'packages':rows}
summary = {'packages':len(rows),'archives_verified':sum('archive_sha256' in r for r in rows),'distinct_archives':len(archive_index),'notices':sum(len(r['notices']) for r in rows),'verified_notices':sum(n['source_verified'] for r in rows for n in r['notices']),'unverified':[{k:r.get(k) for k in ('name','version','source_issue')}|{'notices':[n for n in r['notices'] if not n['source_verified']]} for r in rows if 'source_issue' in r or any(not n['source_verified'] for n in r['notices'])]}
result['summary']=summary
(root/'provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
