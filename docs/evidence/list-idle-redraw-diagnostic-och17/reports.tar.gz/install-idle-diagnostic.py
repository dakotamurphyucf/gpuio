from pathlib import Path
b=Path(__file__).resolve().parent
paths=['vendor/gpui/src/window.rs','examples/performance/main.ml']
for name in paths:
 p=Path(name); backup=b/('idle-original-'+p.parent.name+'-'+p.name)
 assert not backup.exists(),backup
 backup.write_bytes(p.read_bytes())
p=Path(paths[0]);s=p.read_text()
marker='    pub fn invalidate_view(&self, entity: EntityId, cx: &mut App) -> bool {'
assert s.count(marker)==1
s=s.replace(marker,'    #[track_caller]\n'+marker)
s=s.replace('            let became_dirty = !inner.dirty;\n            inner.dirty = true;', '            let became_dirty = !inner.dirty;\n            if became_dirty { qualification_idle_trace("invalidate_view"); }\n            inner.dirty = true;',1)
marker='    pub fn refresh(&mut self) {\n        if self.invalidator.not_drawing() {'
assert s.count(marker)==1
s=s.replace(marker,'    #[track_caller]\n'+marker+'\n            qualification_idle_trace("refresh");')
marker='    pub fn dispatch_event(&mut self, event: PlatformInput, cx: &mut App) -> DispatchEventResult {'
assert s.count(marker)==1
s=s.replace(marker,marker+'\n        qualification_idle_trace(event.kind_name());')
s+='''
// TEMPORARY OCH-17 diagnostic; restore before performance qualification.
#[track_caller]
fn qualification_idle_trace(reason: &str) {
    static ENABLED: std::sync::LazyLock<bool> = std::sync::LazyLock::new(||
        std::env::var_os("GPUIO_IDLE_TRACE").is_some());
    static EPOCH: std::sync::LazyLock<std::time::Instant> =
        std::sync::LazyLock::new(std::time::Instant::now);
    static COUNT: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    if *ENABLED && COUNT.fetch_add(1, std::sync::atomic::Ordering::Relaxed) < 16384 {
        eprintln!("GPUIO_IDLE_TRACE {} {} {}", EPOCH.elapsed().as_nanos(), reason,
            std::panic::Location::caller());
    }
}
'''
p.write_text(s)
p=Path(paths[1]);s=p.read_text();old='let idle_seconds = if smoke then 2. else 60. in';assert s.count(old)==1;s=s.replace(old,'let idle_seconds = 60. in');p.write_text(s)
