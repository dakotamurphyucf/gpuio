import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, 'scripts')
from measure_chart_stream import collect
from test_agent_chat import Mac
from test_gallery import GalleryMouse, element_rect

base = Path(__file__).resolve().parent
binary = Path('_build/default/examples/performance_presented/list/main.exe')
os.environ['GPUIO_IDLE_TRACE'] = '1'
awake = subprocess.Popen(['caffeinate', '-di', '-w', str(os.getpid())])
try:
    for mode in ('untouched', 'pointer'):
        output = base / f'idle-diagnostic-{mode}-001'
        output.mkdir(exist_ok=False)
        log = output / 'application.log'
        report = {'scope': 'Diagnostic only: temporary bounded invalidation trace and 96-row smoke with 60-second idle; not performance acceptance',
                  'mode': mode, 'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                  'pointer_events': [], 'complete': False}
        idle_start = None
        offset = 0
        mac = None
        def poll(child):
            global idle_start, offset, mac
            if idle_start is None:
                with log.open() as inp:
                    inp.seek(offset)
                    chunk = inp.read()
                    offset = inp.tell()
                if 'GPUIO_PERF begin (idle ' in chunk:
                    idle_start = time.monotonic()
                    print(mode, 'IDLE_BEGIN', flush=True)
            if mode != 'pointer' or idle_start is None:
                return
            step = len(report['pointer_events'])
            if step >= 14:
                return
            elapsed = time.monotonic() - idle_start
            deadline = 5 + (step // 2) * 5 + (step % 2) * .25
            if elapsed < deadline:
                return
            if mac is None:
                mac = Mac(child.pid, child)
            window = mac.window('GPUIO · Performance qualification')
            assert window
            try:
                x, y, w, h = element_rect(mac, window)
                point = (x + (40 if step % 2 == 0 else w-25), y + (80 if step % 2 == 0 else h/2))
                mouse = GalleryMouse(mac)
                mouse.check_owner(point)
                mouse.send(5, point)
                report['pointer_events'].append({'step': step, 'elapsed_idle_s': elapsed, 'point': point})
            finally:
                mac.release(window)
        try:
            collect(binary, log, report, 120, arguments=['--smoke'], on_poll=poll, poll_interval=.05)
            report['complete'] = True
        except Exception as error:
            report['error'] = f'{type(error).__name__}: {error}'
        finally:
            if mac is not None:
                mac.release(mac.app)
            lines = log.read_text().splitlines()
            report['trace_records'] = sum(line.startswith('GPUIO_IDLE_TRACE ') for line in lines)
            report['idle_presentations'] = [json.loads(line.removeprefix('GPUIO_PRESENTATION '))
                for line in lines if line.startswith('GPUIO_PRESENTATION ')][1:]
            (output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
            print(mode, {k:report.get(k) for k in ('complete','returncode','error','trace_records')}, flush=True)
finally:
    awake.terminate()
    awake.wait(timeout=5)
