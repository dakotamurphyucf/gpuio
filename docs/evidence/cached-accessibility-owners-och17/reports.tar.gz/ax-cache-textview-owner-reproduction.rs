//! Cache ownership must preserve live text and promptly retire unrelated state.
use super::*;
struct Text {
    text: Entity<TextViewState>,
    renders: Arc<AtomicUsize>,
}
impl Render for Text {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        self.renders.fetch_add(1, Ordering::Relaxed);
        div().size_full().child(TextView::new(&self.text))
    }
}
struct TextParent(Entity<Text>);
impl Render for TextParent {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        div().w(px(440.)).h(px(200.)).child(gpui_base::TextSelectionLayer)
            .child(self.0.clone().cached(gpui::StyleRefinement::default().size_full()))
    }
}
#[test]
fn cached_text_view_preserves_selection_and_copy_without_re_rendering() {
    let mut app = TestAppContext::single();
    app.update(gpui_base::init);
    let renders = Arc::new(AtomicUsize::new(0));
    let (parent, cx) = app.add_window_view(|_, cx| TextParent(cx.new(|cx| Text {
        text: cx.new(|cx| {
            let mut text = TextViewState::externally_prepared(cx);
            text.set_prepared(PreparedText::parse("Cached 世界", MarkdownExtensions::default()).unwrap(), None, cx);
            text
        }), renders: renders.clone(),
    })));
    let text = parent.read_with(cx, |p, cx| p.0.read(cx).text.clone());
    cx.simulate_a11y_active(true); cx.run_until_parked();
    text.update(cx, |text, cx| text.select_all(cx));
    cx.update(|window, cx| { window.refresh(); window.draw(cx).clear(cx); });
    assert_eq!(cx.update(gpui_base::TextSelection::selected_text), "Cached 世界", "fresh paint selected content");
    let count = renders.load(Ordering::Relaxed);
    parent.update(cx, |_, cx| cx.notify()); draw(cx);
    let selected = cx.update(gpui_base::TextSelection::selected_text);
    assert_eq!(renders.load(Ordering::Relaxed), count, "actual cache reuse, selected={selected:?}");
    assert_eq!(selected, "Cached 世界");
}

struct Mixed {
    cached: Entity<CachedDocument>,
    transient: Option<Arc<()>>,
}
impl Render for Mixed {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        div().w(px(440.)).h(px(200.))
            .child(self.cached.clone().cached(gpui::StyleRefinement::default().size_full()))
            .when_some(self.transient.clone(), |this, owner| this.child(
                div().id("uncached-control").role(accesskit::Role::Button).aria_label("Temporary")
                    .on_a11y_action(gpui::AccessibleAction::Click, move |_, _, _| { let _ = &owner; })
            ))
    }
}
#[test]
fn unrelated_uncached_callback_owners_retire_in_the_removal_frame() {
    let mut app = TestAppContext::single();
    app.update(gpui_base::init);
    let owner = Arc::new(());
    let weak = Arc::downgrade(&owner);
    let (parent, cx) = app.add_window_view(|_, cx| Mixed {
        cached: cx.new(|cx| CachedDocument { renders: Arc::new(AtomicUsize::new(0)), clicks: Arc::new(AtomicUsize::new(0)), focus: cx.focus_handle(), label: "Cached", deferred: false }),
        transient: Some(owner),
    });
    cx.simulate_a11y_active(true); cx.run_until_parked();
    cx.update(|window, cx| { window.refresh(); window.draw(cx).clear(cx); });
    assert!(weak.upgrade().is_some());
    parent.update(cx, |parent, _| { parent.transient = None; });
    // Observe one removal frame; a second frame must not hide delayed release.
    cx.update(|window, cx| window.draw(cx).clear(cx));
    assert!(weak.upgrade().is_none(), "unrelated cache retained the removed callback owner");
}
