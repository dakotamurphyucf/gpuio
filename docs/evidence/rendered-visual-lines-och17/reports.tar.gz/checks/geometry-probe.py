import ctypes as C,json,subprocess,sys,time
from pathlib import Path
ROOT=Path('/Users/dakotamurphy/gpuio');sys.path.insert(0,str(ROOT/'scripts'))
from test_agent_chat import Mac
from test_gallery import TITLE,focus_gallery_control
from test_macos_text_selection import Range,utf16
from mac_input_source import foreground_keys
OUT=Path(__file__).parent/'geometry-probe-1';OUT.mkdir(exist_ok=False)
class Rect(C.Structure):_fields_=[('x',C.c_double),('y',C.c_double),('width',C.c_double),('height',C.c_double)]
mac=None;report={}
with (OUT/'app.log').open('w') as log:
 child=subprocess.Popen([str(ROOT/'_build/default/examples/gallery/main.exe')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 try:
  mac=Mac(child.pid,child)
  query=mac.ax.AXUIElementCopyParameterizedAttributeValue;query.restype,query.argtypes=C.c_int,[C.c_void_p,C.c_void_p,C.c_void_p,C.POINTER(C.c_void_p)]
  create=mac.ax.AXValueCreate;create.restype,create.argtypes=C.c_void_p,[C.c_int,C.c_void_p]
  get=mac.ax.AXValueGetValue;get.restype,get.argtypes=C.c_bool,[C.c_void_p,C.c_int,C.c_void_p]
  number=mac.cf.CFNumberCreate;number.restype,number.argtypes=C.c_void_p,[C.c_void_p,C.c_int,C.c_void_p]
  get_number=mac.cf.CFNumberGetValue;get_number.restype,get_number.argtypes=C.c_bool,[C.c_void_p,C.c_int,C.c_void_p]
  def param(n,name,value,kind):
   key=mac.string(name);out=C.c_void_p()
   try:
    error=query(n,key,value,C.byref(out))
    if error:return {'error':error}
    if kind=='number':
     result=C.c_longlong();assert get_number(out.value,4,C.byref(result));return result.value
    result=Range() if kind=='range' else Rect()
    assert get(out.value,4 if kind=='range' else 3,C.byref(result))
    return {name:getattr(result,name) for name,_ in result._fields_}
   finally:
    if out.value:mac.release(out.value)
    mac.release(key);mac.release(value)
  mac.press(TITLE,'Markdown & code');mac.wait_text(TITLE,'A place for ideas')
  focus_gallery_control(mac,'Document content','AXGroup');foreground_keys(mac);mac.key(0,flags=1<<20)
  n=mac.wait_find(TITLE,'Document content','AXGroup')
  try:
   deadline=time.monotonic()+5
   while True:
    text=mac.text(n,'AXSelectedText') or ''
    if 'A place for ideas' in text:break
    assert time.monotonic()<deadline;time.sleep(.05)
   report['text']=text;report['observations']=[]
   for term in ['A place for ideas','世界','👨‍👩‍👧‍👦','Explore']:
    start=utf16(text[:text.index(term)]);length=utf16(term)
    rect=param(n,'AXBoundsForRange',create(4,C.byref(Range(start,length))),'rect')
    line=param(n,'AXLineForIndex',number(None,4,C.byref(C.c_longlong(start))),'number')
    row={'term':term,'start':start,'length':length,'rect':rect,'line':line}
    if isinstance(line,int):row['line_range']=param(n,'AXRangeForLine',number(None,4,C.byref(C.c_longlong(line))),'range')
    report['observations'].append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
  finally:mac.release(n)
  report['result']='observed'
 finally:
  if mac:
   try:mac.close(TITLE);child.wait(timeout=5)
   except Exception as error:report['close_error']=repr(error)
   mac.release(mac.app)
  if child.poll() is None:
   child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait()
  report['exit']=child.returncode;(OUT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
