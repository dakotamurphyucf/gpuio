import ctypes as C
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/dakotamurphy/gpuio')
sys.path.insert(0, str(ROOT / 'scripts'))
from test_agent_chat import Mac
from test_gallery import TITLE, expect_focus
from mac_input_source import foreground_keys
from mac_clipboard import preserved_clipboard

OUT = Path(__file__).parent / 'voiceover-caption-probe-2'
OUT.mkdir(exist_ok=False)
VO = (1 << 18) | (1 << 19)
SHIFT = 1 << 17
COMMAND = (1 << 20) | (1 << 23)

def enabled():
    return subprocess.check_output(['defaults', 'read', 'com.apple.universalaccess', 'voiceOverOnOffKey'], text=True).strip() == '1'

def wait_state(value):
    deadline = time.monotonic() + 15
    while enabled() != value:
        if time.monotonic() > deadline:
            raise RuntimeError(f'VoiceOver did not become {value}')
        time.sleep(.2)

def toggle_system(mac):
    post = mac.cg.CGEventPost
    post.restype, post.argtypes = None, [C.c_uint32, C.c_void_p]
    for down in [True, False]:
        event = mac.key_event(None, 96, down)
        try:
            mac.key_flags(event, COMMAND)
            post(0, event)
        finally:
            mac.release(event)
        time.sleep(.08)

assert not enabled(), 'Probe requires baseline VoiceOver off; nothing changed'
Mac.require_accessibility()
report = {'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'baseline_voiceover': False, 'observations': [], 'result': 'pending'}
mac = child = None
try:
    with preserved_clipboard() as board, (OUT / 'app.log').open('w') as log:
        try:
            child = subprocess.Popen([str(ROOT / '_build/default/examples/gallery/main.exe'), '--trace-windows'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            report['pid'] = child.pid
            mac = Mac(child.pid, child)
            mac.press(TITLE, 'Markdown & code')
            mac.wait_text(TITLE, 'A place for ideas')
            node = mac.wait_find(TITLE, 'Document content', 'AXGroup')
            try:
                mac.set(node, 'AXFocused', mac.true)
            finally:
                mac.release(node)
            expect_focus(mac, 'Document content', 'AXGroup')
            foreground_keys(mac)
            mac.key(96, flags=COMMAND)
            wait_state(True)
            report['voiceover_started'] = True
            deadline = time.monotonic() + 20
            while True:
                result = subprocess.run(['osascript', '-e', 'tell application "System Events"\nif exists process "VoiceOver Quickstart" then\ntell process "VoiceOver Quickstart"\nif exists button "Use VoiceOver" of window 1 then\nclick button "Use VoiceOver" of window 1\nreturn "accepted"\nend if\nend tell\nend if\nreturn "waiting"\nend tell'], capture_output=True, text=True, timeout=5)
                if result.stdout.strip() == 'accepted': break
                assert time.monotonic() < deadline, ('No VoiceOver welcome', result.stdout, result.stderr)
                time.sleep(.2)
            time.sleep(3)
            from test_gallery import focus_gallery_control
            focus_gallery_control(mac, 'Document content', 'AXGroup')
            # Read only diagnostic names and the screen reader's own caption.
            known = subprocess.check_output(['ps', '-axo', 'pid,comm'], text=True)
            report['reader_processes'] = [line for line in known.splitlines()
                if any(name in line for name in ['VoiceOver', 'ScreenReader', 'AccessibilityVisualsAgent'])]
            print(json.dumps({'reader_processes': report['reader_processes']}), flush=True)
            scripts = [
                'tell application "VoiceOver" to get content of last phrase',
                'tell application "System Events" to get name of every application process whose name contains "VoiceOver"',
                'tell application "System Events" to tell process "VoiceOver" to get name of windows',
                'tell application "System Events" to tell process "AccessibilityVisualsAgent" to get name of windows',
                'tell application "System Events" to tell process "AccessibilityVisualsAgent" to get {name, value} of every static text of window 1',
            ]
            for command in scripts:
                result = subprocess.run(['osascript', '-e', command], capture_output=True, text=True, timeout=10)
                observation = dict(command=command, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
                report['observations'].append(observation)
                print(json.dumps(observation), flush=True)
            report['result'] = 'observed'
        finally:
            try:
                if mac and enabled():
                    toggle_system(mac)
                    time.sleep(.5)
                    if enabled():
                        subprocess.run(['osascript', '-e', 'tell application "System Events" to tell process "VoiceOver Quickstart" to click button "Turn Off VoiceOver" of window 1'], timeout=10)
                    wait_state(False)
            except Exception as error:
                report['voiceover_cleanup_error'] = repr(error)
            report['voiceover_restored'] = not enabled()
            if mac:
                try:
                    mac.close(TITLE)
                    child.wait(timeout=5)
                except Exception as error:
                    report['close_error'] = repr(error)
            if child and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait()
            if child:
                report['child_exit'] = child.returncode
            if mac:
                mac.release(mac.app)
    report['clipboard_restored'] = True
except BaseException as error:
    report.update(result='fail', error=repr(error))
    raise
finally:
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(report, ensure_ascii=False), flush=True)
