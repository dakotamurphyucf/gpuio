from pathlib import Path
import contextlib,json,os,signal,subprocess,sys,time
out=Path(__file__).parent
sys.path.insert(0,str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
base=['./scripts/gpuio','exec'];env={**os.environ,'GPUIO_JOBS':'2'}
checks=[
 ('clippy',base+['cargo','clippy','--offline','--workspace','--all-targets','--locked','-j2','--features','gpuio-native/native-canvas-tests,gpuio-native/native-image-tests,gpuio-native/presentation-diagnostics','--','-D','warnings'],False),
 ('fmt',base+['cargo','fmt','--all','--check'],False),
 ('vendor-fmt',base+['rustfmt','--edition','2024','--check','vendor/gpui/src/window/a11y.rs','vendor/gpui-base/src/text/semantic_attachments.rs','vendor/gpui-base/src/text/visual_lines.rs'],False),
 ('desktop',base+['cargo','test','--offline','--locked','-j2','-p','gpuio-native','--features','native-tests','--test','native_document'],True),
]
results=[]
for name,cmd,clipboard in checks:
 print('START',name,flush=True);start=time.monotonic()
 with (preserved_clipboard() if clipboard else contextlib.nullcontext()), (out/('visual-lines-final-'+name+'.log')).open('w') as log:
  child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  try:status=child.wait(timeout=300)
  except BaseException:
   os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 results.append(dict(name=name,command=cmd,exit=status,seconds=time.monotonic()-start,clipboard_restored=clipboard))
 (out/'visual-lines-final-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print('END',name,status,flush=True)
 if status:raise SystemExit(status)
