from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd() / 'scripts'))
import gallery_split
exec(Path(__file__).with_name('split_identity_diagnostic.py').read_text(), gallery_split.__dict__)
import test_gallery
test_gallery.main()
