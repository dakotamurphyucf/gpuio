open Core
module Direction = Gpuio.List_paging.Direction
module Boundary = Gpuio.List_paging.Boundary
module Request = Gpuio.List_paging.Request
module Status = Gpuio.List_paging.Status

module Page : sig
  type ('key, 'data) t =
    { rows : ('key * 'data) list
    ; next : Boundary.t
    }
end

module Snapshot = Gpuio.List_paging.Snapshot

(** A scoped, UI-domain-owned paged collection. [load] runs as an Eio producer;
    capture the explicit filesystem/network capabilities it needs. [on_change]
    receives an immutable snapshot on the UI loop for status or data changes.
    It can publish that snapshot directly to Bonsai without capturing the
    controller in its own constructor. It must not perform blocking I/O.

    Give this controller a conversation/application scope when loads should
    survive row deactivation. Viewport changes do not cancel tasks. [reset],
    [cancel], [close] and parent-scope cancellation cancel affected producers
    and suppress their queued completions. Two lazily allocated reusable workers
    bound concurrent producers, including cancellation cleanup. A worker becomes
    reusable only after its producer exits and returns through the UI inbox.
    Only the latest request per boundary waits behind occupied workers; rapid
    resets do not grow the queue. Idle workers block without polling and remain
    charged to the owning Scope task quota until the controller closes.
    Do not create or mutate controllers during Incremental graph evaluation. *)
type ('key, 'data, 'cmp) t

val create
  :  ?on_change:(('key, 'data, 'cmp) Snapshot.t -> unit Bonsai.Effect.t)
  -> scope:Scope.t
  -> ('key, 'data, 'cmp) Gpuio.List_collection.t
  -> before:Boundary.t
  -> after:Boundary.t
  -> load:(Request.t -> ('key, 'data) Page.t Or_error.t)
  -> ('key, 'data, 'cmp) t Or_error.t

val items : ('key, 'data, 'cmp) t -> ('key, 'data, 'cmp) Gpuio.List_collection.t
val snapshot : ('key, 'data, 'cmp) t -> ('key, 'data, 'cmp) Snapshot.t
val status : (_, _, _) t -> Direction.t -> Status.t

(** Repeated requests while loading, failed or at end are no-ops. A new request
    can wait behind cancelling workers. Immediate worker-admission errors return
    directly and publish Failed; later worker/producer failures publish Failed.
    Failures require explicit [retry]; scrolling does not repeatedly retry. *)
val request : (_, _, _) t -> Direction.t -> unit Or_error.t

val retry : (_, _, _) t -> Direction.t -> unit Or_error.t
val cancel : (_, _, _) t -> Direction.t -> unit

val reset
  :  ('key, 'data, 'cmp) t
  -> ('key, 'data, 'cmp) Gpuio.List_collection.t
  -> before:Boundary.t
  -> after:Boundary.t
  -> unit Or_error.t

val set : ('key, 'data, _) t -> key:'key -> data:'data -> unit Or_error.t

(** Idempotently cancel this controller's workers and queued requests, unregister
    its cleanup hook and publish the final cancelled-boundary snapshot to [value].
    Retained data remains readable. No [on_change] callback runs on closure;
    parent-scope cancellation has the same behavior. Other scoped tasks survive. *)
val close : (_, _, _) t -> unit

(** Reactive snapshots published on the UI domain. The optional [on_change]
    callback is additional notification; ordinary Bonsai lists can use [value]
    directly, without a separate variable or a self-referential constructor. *)
val value : ('key, 'data, 'cmp) t -> ('key, 'data, 'cmp) Snapshot.t Bonsai.Cont.t

(** Pure UI effects with generation checks and the pager's scoped ownership.
    Closed or obsolete generations ignore delayed actions. Admission failures
    appear as [Failed] snapshots for explicit retry. *)
val controls : (_, _, _) t -> Gpuio_bonsai.Virtual_list.Paging.t

(** Append newly created rows at a known latest boundary ([After = End]).
    Preserves generation, scroll identity and pending older-history requests.
    Duplicate keys or an unknown latest boundary fail without changing state. *)
val append : ('key, 'data, _) t -> ('key * 'data) list -> unit Or_error.t
