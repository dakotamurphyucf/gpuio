Base709273854e2a77966512c524e358075cf38f5d50 plus archived source files; macOS14.5 arm64/M1Max.
GPUIO_JOBS=2 throughout builds. No dependency version changes, no switch/default mutations.

PASS: ./scripts/gpuio exec dune build @all @fmt @runtest
PASS after subsequent example-only second-owner addition: ./scripts/gpuio exec dune build examples/menu_controller/main.exe @fmt
PASS416: ./scripts/gpuio exec cargo test -p gpuio-protocol --locked -j 2
PASS981/2existingignored: ./scripts/gpuio exec cargo test -p gpuio-native --features native-image-tests,native-canvas-tests --lib --locked -j 2
PASS: ./scripts/gpuio exec cargo clippy -p gpuio-native -p gpuio-protocol --all-targets --features native-image-tests,native-canvas-tests --locked -j 2 -- -D warnings
PASS: ./scripts/gpuio exec cargo fmt --all -- --check
PASS: python3 -m py_compile scripts/test_menu_controller_macos.py scripts/test_extension_consumer.py
PASS: scratch/agents/root-20260925-resumed/actionlint/actionlint -shellcheck= .github/workflows/foundation.yml

PASS: python3 scripts/test_extension_consumer.py --example menu_controller --workspace scratch/agents/root-20261004-resumed/popup-controller-consumer
PASS(finalfullsequenceincludingdifferent-ownerBusy): python3 scripts/test_menu_controller_macos.py --binary scratch/agents/root-20261004-resumed/popup-controller-consumer/consumer/_build/default/main.exe
PASS(beforeaddingsecondowner): python3 scripts/test_menu_controller_macos.py
PASS(legacycontext/nativeCopyregression,clipboardrestored): python3 scripts/test_native_popup_macos.py
All GUI children exited0 and were reaped. No LinuxGUI/VoiceOver/presentationlatency acceptance.

Early physical log is diagnostic pre-observer-followup binary, opening firstposition/selectingRun/closing; not finalqualification.
Corrected compile errors are retained: Command.Idshadow; Rusthelpervisibility/newmailboxvariant; nonexistentW.Event.encode and unrelatedCommand_sourcepattern.
The subsequent OCaml/native/Clippy checks above pass. No assertions removed to obtain acceptance.
