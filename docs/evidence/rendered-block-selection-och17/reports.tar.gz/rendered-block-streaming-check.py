from pathlib import Path
import contextlib,json,os,signal,subprocess,sys,time
notes=Path('scratch/agents/root-20261004-resumed')
sys.path.insert(0,str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
base=['./scripts/gpuio','exec']; env=dict(os.environ,GPUIO_JOBS='2',RUST_BACKTRACE='1')
checks=[
 ('streaming-010',base+['cargo','test','--offline','--locked','-j2','-p','gpuio-native','--features','native-tests','--test','native_document'],240,True),
]
results=[]
for name,command,timeout,clipboard in checks:
 path=notes/('rendered-block-'+name+'.log');start=time.monotonic();print('START',name,flush=True)
 with (preserved_clipboard() if clipboard else contextlib.nullcontext()),path.open('w') as log:
  child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:status=child.wait(timeout=timeout)
  except BaseException:
   os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 result=dict(name=name,command=command,exit=status,seconds=time.monotonic()-start,log=str(path))
 results.append(result);(notes/'rendered-block-streaming-check.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,status,flush=True)
 if status:raise SystemExit(status)
