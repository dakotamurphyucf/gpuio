import ctypes as C
import hashlib
import json
from pathlib import Path
import sys
import time
sys.path.insert(0, 'scripts')
from measure_chart_stream import collect
from test_agent_chat import Mac
from test_canvas import screenshot

TITLE = 'GPUIO · Performance qualification'
base = Path('scratch/agents/root-20261007-access-check/list-slow-capture-001')
base.mkdir(exist_ok=False)
binary = Path('_build/default/examples/performance_presented/list/main.exe')
report = {'complete': False, 'scope': '96-row diagnostic with 200ms delay per acknowledged move; not performance acceptance',
          'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'captures': []}
class Pair(C.Structure):
    _fields_ = [('x', C.c_double), ('y', C.c_double)]
started = time.monotonic()
next_capture = 3.
def poll(child):
    global next_capture
    elapsed = time.monotonic() - started
    if elapsed < next_capture or len(report['captures']) >= 6:
        return
    mac = Mac(child.pid, child)
    window = mac.window(TITLE)
    if not window:
        mac.release(mac.app)
        return
    get_value = mac.ax.AXValueGetValue
    get_value.restype, get_value.argtypes = C.c_bool, [C.c_void_p, C.c_int, C.c_void_p]
    def pair(node, attr, kind):
        value = mac.attr(node, attr)
        try:
            p = Pair()
            return [p.x, p.y] if value and get_value(value, kind, C.byref(p)) else None
        finally:
            if value: mac.release(value)
    nodes = []
    def visit(node, depth):
        if depth > 16 or len(nodes) >= 400: return
        role = mac.text(node, 'AXRole')
        value = mac.text(node, 'AXValue') or mac.text(node, 'AXTitle') or mac.text(node, 'AXDescription')
        nodes.append({'role': role, 'text': value[:120] if value else None,
                      'position': pair(node, 'AXPosition', 1), 'size': pair(node, 'AXSize', 2), 'depth': depth})
        children = mac.children(node)
        try:
            for item in children: visit(item, depth + 1)
        finally:
            for item in children: mac.release(item)
    try:
        visit(window, 0)
        index = len(report['captures'])
        screenshot(mac, base / f'frame-{index}.png', title=TITLE)
        (base / f'frame-{index}.json').write_text(json.dumps(nodes, indent=2) + '\n')
        report['captures'].append({'index': index, 'elapsed_s': elapsed, 'nodes': len(nodes)})
        print('CAPTURE', index, elapsed, len(nodes), flush=True)
        next_capture = elapsed + 3.
    finally:
        mac.release(window)
        mac.release(mac.app)
try:
    collect(binary, base/'application.log', report, 90, arguments=['--smoke'], on_poll=poll, poll_interval=.2)
    report['complete'] = True
finally:
    (base/'report.json').write_text(json.dumps(report, indent=2) + '\n')
