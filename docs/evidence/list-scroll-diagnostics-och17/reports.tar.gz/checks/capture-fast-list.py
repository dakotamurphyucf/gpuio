import ctypes as C
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,'scripts')
from test_agent_chat import Mac
from test_canvas import screenshot
pid=int(sys.argv[1]);base=Path('scratch/agents/root-20261007-access-check/list-fast-capture-002');base.mkdir(exist_ok=False)
mac=Mac(pid)
report={'pid':pid,'scope':'Diagnostic captures perturb workload; not performance acceptance','frames':[]}
try:
 for i in range(12):
  start=time.monotonic();screenshot(mac,base/f'frame-{i:02d}.png',title='GPUIO · Performance qualification')
  value=mac.attr(mac.app,'AXFrontmost')
  try:
   mac.cf.CFBooleanGetValue.restype=C.c_bool;mac.cf.CFBooleanGetValue.argtypes=[C.c_void_p]
   active=bool(mac.cf.CFBooleanGetValue(value)) if value else None
  finally:
   if value:mac.release(value)
  report['frames'].append({'index':i,'monotonic_s':start,'active':active});time.sleep(.1)
finally:
 mac.release(mac.app);(base/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Captured',len(report['frames']),'owned-window frames')
