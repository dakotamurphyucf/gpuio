import ctypes as C
import hashlib
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,'scripts')
from measure_chart_stream import collect
from test_agent_chat import Mac
base=Path('scratch/agents/root-20261007-access-check/list-controlled-minimize-002')
base.mkdir(exist_ok=False)
binary=Path('_build/default/examples/performance_presented/list/main.exe')
report={'complete':False,'scope':'Intentional AXMinimized=true after3s; validates failure-only diagnostics, not performance acceptance','sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
start=time.monotonic()
def poll(child):
 if 'minimize_seconds' in report or time.monotonic()-start<3: return
 mac=Mac(child.pid,child)
 window=mac.window('GPUIO · Performance qualification')
 assert window
 attr=mac.string('AXMinimized')
 try:
  status=mac.set_attr(window,attr,mac.true)
  assert status==0,status
  fn=mac.cf.CFBooleanGetValue
  fn.restype,fn.argtypes=C.c_bool,[C.c_void_p]
  deadline=time.monotonic()+2
  minimized=False
  while time.monotonic()<deadline:
   value=mac.attr(window,'AXMinimized')
   try: minimized=bool(value and fn(value))
   finally:
    if value: mac.release(value)
   if minimized: break
   time.sleep(.05)
  assert minimized
  report['minimize_seconds']=time.monotonic()-start
 finally:
  mac.release(attr);mac.release(window);mac.release(mac.app)
try:
 try: collect(binary,base/'application.log',report,35,on_poll=poll,poll_interval=.25)
 except RuntimeError as error:
  report['expected_child_failure']=str(error)
 log=(base/'application.log').read_text()
 assert report.get('returncode')==2,report
 assert 'GPUIO_LIST_WAIT_FAILED' in log,log
 report['complete']=True
finally:
 (base/'report.json').write_text(json.dumps(report,indent=2)+'\n')
