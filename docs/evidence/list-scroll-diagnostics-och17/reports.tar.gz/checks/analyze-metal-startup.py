"""Diagnostic-only host-clock decomposition; never changes acceptance decisions."""
import json
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
text = (path / 'application.log').read_text()
pattern = re.compile(r'^GPUIO_METAL_STARTUP (\d+) start=([\d.]+) acquired=([\d.]+) encoded=([\d.]+) submitted=([\d.]+) transaction=(true|false)$')
frames = []
for line in text.splitlines():
    match = pattern.fullmatch(line)
    if match:
        sequence, start, acquired, encoded, submitted, transaction = match.groups()
        row = dict(sequence=int(sequence), start=float(start), acquired=float(acquired),
                   encoded=float(encoded), submitted=float(submitted), transaction=transaction == 'true')
        assert row['sequence'] == len(frames)
        assert row['start'] <= row['acquired'] <= row['encoded'] <= row['submitted']
        frames.append(row)
assert 0 < len(frames) <= 32
phases = [json.loads(line.removeprefix('GPUIO_PRESENTATION ')) for line in text.splitlines()
          if line.startswith('GPUIO_PRESENTATION ')]
assert len(phases) == 2
rows = []
trace = phases[0]['native']['trace']
for r in trace[:12]:
    matches = [f for f in frames if f['encoded'] - 1e-8 <= r['submit_host_s'] <= f['submitted'] + 1e-8]
    assert len(matches) == 1, (r['sequence'], len(matches))
    frame = matches[0]
    before = frames[frame['sequence'] - 1] if frame['sequence'] else None
    ms = lambda seconds: round(seconds * 1000, 6)
    rows.append(dict(sequence=r['sequence'], outcome=r['outcome'],
                     since_first_submit_ms=ms(r['submit_host_s'] - trace[0]['submit_host_s']),
                     preceding_gap_ms=ms(frame['start'] - before['submitted']) if before else None,
                     drawable_acquisition_ms=ms(frame['acquired'] - frame['start']),
                     encoding_ms=ms(frame['encoded'] - frame['acquired']),
                     submit_ms=ms(frame['submitted'] - frame['encoded']),
                     presentation_after_first_submit_ms=ms(r['presented_host_s'] - trace[0]['submit_host_s']) if r['presented_host_s'] else None,
                     transaction=frame['transaction']))
result = dict(scope='Temporary bounded instrumentation; no performance qualification',
              logged_frames=len(frames), history_counts=phases[0]['native']['counts'], first_frames=rows)
(path / 'startup-diagnostic.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
