import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path('scratch/agents/root-20261007-access-check')
binary = Path('_build/default/examples/performance_presented/list/main.exe')
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
assert b'GPUIO_METAL_STARTUP' not in binary.read_bytes()
report = dict(revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
              plan='One warm-up followed by exactly three full trials; unchanged budgets; retain all outcomes',
              trials=[])
env = dict(os.environ)
env.pop('GPUIO_TRACE_METAL_STARTUP', None)
awake = subprocess.Popen(['/usr/bin/caffeinate', '-di', '-w', str(os.getpid())])
try:
    for name, smoke in [('warmup', True), ('001', False), ('002', False), ('003', False)]:
        output = base / f'list-current-{name}'
        cmd = ['python3', 'scripts/measure_list_history.py', '--build-profile', 'release',
               '--presentation', '--smoke' if smoke else '--check-budgets', '--timeout', '900',
               '--executable', str(binary), '--output', str(output)]
        report['running'] = name
        (base / 'list-current-batch.json').write_text(json.dumps(report, indent=2) + '\n')
        print('START', name, flush=True)
        with (base / f'list-current-{name}.log').open('w') as log:
            result = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        child_report = json.loads((output / 'report.json').read_text())
        report['trials'].append(dict(name=name, command=cmd, driver_exit=result.returncode,
                                    complete=child_report['complete'], error=child_report.get('error'),
                                    child_returncode=child_report.get('returncode')))
        report['running'] = None
        (base / 'list-current-batch.json').write_text(json.dumps(report, indent=2) + '\n')
        print('FINISH', report['trials'][-1], flush=True)
        if child_report.get('returncode') != 0:
            raise RuntimeError('Stop after child failure; do not repeat broken execution')
finally:
    awake.terminate()
    awake.wait(timeout=5)
    report['keep_awake_reaped'] = True
    (base / 'list-current-batch.json').write_text(json.dumps(report, indent=2) + '\n')
