import ctypes as C
import hashlib
import json
from pathlib import Path
import re
import sys
import time
sys.path.insert(0, 'scripts')
from measure_chart_stream import collect
from test_agent_chat import Mac
from test_canvas import screenshot
from test_gallery import GalleryMouse, element_rect

TITLE = 'GPUIO · Performance qualification'
base = Path('scratch/agents/root-20261007-access-check/list-wheel-capture-001')
base.mkdir(exist_ok=False)
binary = Path('_build/default/examples/performance_presented/list/main.exe')
report = {'complete': False, 'scope': 'Same 10k variable-height fixture; temporary 25s interactive hold; pixel-wheel events, no automatic traversal. AX geometry/sampled images, not performance acceptance or a frame-by-frame visual guarantee.', 'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'samples': []}
start = time.monotonic()
next_step = 3.
step = 0

def poll(child):
    global next_step, step
    elapsed = time.monotonic() - start
    if elapsed < next_step or step >= 80:
        return
    mac = Mac(child.pid, child)
    window = mac.window(TITLE)
    assert window
    rows = []
    list_bounds = None
    def visit(node, depth=0):
        nonlocal list_bounds
        assert depth < 20
        role = mac.text(node, 'AXRole')
        value = mac.text(node, 'AXValue') or mac.text(node, 'AXTitle') or ''
        if role == 'AXList': list_bounds = element_rect(mac, node)
        match = re.match(r'Row (\d+)', value)
        if role == 'AXStaticText' and match:
            rows.append({'id': int(match[1]), 'bounds': element_rect(mac, node)})
        children = mac.children(node)
        try:
            for item in children: visit(item, depth+1)
        finally:
            for item in children: mac.release(item)
    try:
        visit(window)
        rows.sort(key=lambda r:r['bounds'][1])
        overlaps = []
        for a,b in zip(rows, rows[1:]):
            if a['bounds'][1]+a['bounds'][3] > b['bounds'][1]+.5:
                overlaps.append([a['id'],b['id']])
        delta = -24 if step < 40 else 24
        sample = {'step': step, 'elapsed': elapsed, 'frontmost': mac.text(mac.app,'AXFrontmost'), 'rows': rows, 'overlaps': overlaps, 'next_wheel_pixels': delta}
        report['samples'].append(sample)
        assert list_bounds and rows, sample
        assert not overlaps, sample
        assert all(a['id'] < b['id'] for a,b in zip(rows,rows[1:])), sample
        if step in (0,10,20,30,39,50,60,70,79):
            screenshot(mac,base/f'frame-{step:02d}.png',title=TITLE)
        x,y,w,h = list_bounds
        point = (x+w/2,y+h/2)
        mouse = GalleryMouse(mac)
        mouse.check_owner(point)
        mouse.send(5,point)
        create=mac.cg.CGEventCreateScrollWheelEvent
        create.restype,create.argtypes=C.c_void_p,[C.c_void_p,C.c_uint,C.c_uint,C.c_int]
        locate=mac.cg.CGEventSetLocation
        locate.restype,locate.argtypes=None,[C.c_void_p,GalleryMouse.Point]
        event=create(None,0,1,delta)
        assert event
        try:
            locate(event,GalleryMouse.Point(*point))
            mouse.post(0,event)
        finally: mac.release(event)
        print('WHEEL',step,delta,rows[0]['id'],rows[0]['bounds'][1],flush=True)
        step+=1
        next_step=time.monotonic()-start+.1
    finally:
        mac.release(window)
        mac.release(mac.app)
try:
    collect(binary,base/'application.log',report,40,arguments=['--wheel-diagnostic'],on_poll=poll,poll_interval=.05)
    assert step==80,step
    assert len({tuple((r['id'],r['bounds'][1]) for r in s['rows']) for s in report['samples']}) > 10
    report['complete']=True
finally:
    (base/'report.json').write_text(json.dumps(report,indent=2)+'\n')
