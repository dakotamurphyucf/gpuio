import hashlib,json,sys,subprocess
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from measure_chart_stream import collect
base=Path(__file__).resolve().parent
reports=[]
for name,relative,markers in [
 ('controls','target/debug/deps/native_controls-1d7396c722ee9af8',['GPUIO_COMMAND_WINDOWS_OK','GPUIO_MENU_BAR_ICONS_OK','GPUIO_CONTROLS_NATIVE_OK','GPUIO_CONTROLS_MACOS_AX_OK']),
 ('menus','target/debug/deps/native_menus-4dc179eda3856661',['GPUIO_MENU_BAR_ICONS_OK','GPUIO_MENU_RETENTION_OK'])]:
 binary=Path(relative)
 report=dict(name=name,binary=relative,sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),dirty=True,complete=False)
 log=base/f'menu-fixture-002-{name}.log'
 try:
  collect(binary,log,report,90)
  text=log.read_text()
  report['markers']={m:m in text for m in markers}
  assert all(report['markers'].values())
  report['complete']=True
 except BaseException as error:
  report['error']=repr(error)
  raise
 finally:
  reports.append(report)
  (base/'menu-fixture-validation-002.json').write_text(json.dumps(reports,indent=2)+'\n')
 print(name,report['complete'],report.get('returncode'),flush=True)
