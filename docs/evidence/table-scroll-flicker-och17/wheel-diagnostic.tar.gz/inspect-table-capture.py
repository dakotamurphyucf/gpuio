import sys,json
from pathlib import Path
sys.path.insert(0, str(Path.cwd()/'scripts'))
from capture_window_startup import WindowCapture
from window_pixels import read_png
base=Path(sys.argv[1]);r=json.loads((base/'report.json').read_text());mac=WindowCapture()
summary=[]
for frame in r['frames']:
 if 'capture_finished_seconds' not in frame: continue
 p=read_png(mac,base/frame['path']);scale=p.width/1200;ink=[]
 for row in range(21):
  x0,x1=int(44*scale),int(151*scale)
  y0,y1=int((117+row*32)*scale),int((135+row*32)*scale)
  ink.append(sum(1 for y in range(y0,y1,2) for x in range(x0,x1,2) if min(p.rgb(x,y))>110))
 filled=[i for i,n in enumerate(ink) if n>20]
 summary.append({'frame':frame['path'],'start':frame['capture_started_seconds'],'end':frame['capture_finished_seconds'],'filled_rows':filled,'ink':ink})
 if len(filled)<21: print(frame['path'],round(frame['capture_started_seconds'],3),'filled',filled)
(base/'row-ink-diagnostic.json').write_text(json.dumps(summary,indent=2)+'\n')
print('samples',len(summary),'status',r['status'],'child',r['child_returncode_after_cleanup'])
