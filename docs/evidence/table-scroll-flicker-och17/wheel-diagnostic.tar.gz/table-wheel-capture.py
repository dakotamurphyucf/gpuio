import ctypes as C
import json
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0, str(Path.cwd()/'scripts'))
from capture_window_startup import WindowCapture, stop_child
from test_tree_outline import Outline, Point

TITLE='GPUIO · Paged table qualification'
base=Path(__file__).resolve().parent
out=base/'table-wheel-capture-002'
out.mkdir(exist_ok=False)
Outline.require_accessibility()
capture=WindowCapture()
report={'status':'incomplete','scope':'sampled native wheel screen diagnostics, not latency or complete frame coverage','frames':[]}
child=None;mac=None
started=time.monotonic();deadline=started+25
try:
 with (out/'child.log').open('w') as log:
  child=subprocess.Popen([str(base/'table-wheel.exe'),'--smoke','--wall-clock'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  report['child_pid']=child.pid
  mac=Outline(child.pid,child)
  window=None
  while time.monotonic()<deadline-15:
   window=mac.window(TITLE)
   if window:break
   time.sleep(.05)
  if not window:raise RuntimeError('no owned window')
  try:
   position,size=Point(),Point()
   for name,kind,result in [('AXPosition',1,position),('AXSize',2,size)]:
    raw=mac.attr(window,name)
    try:
     if not raw or not mac.value(raw,kind,C.byref(result)):raise RuntimeError('missing window geometry')
    finally:
     if raw:mac.release(raw)
   point=Point(position.x+size.x/2,position.y+size.y/2)
  finally:mac.release(window)
  time.sleep(1)
  wheel=mac.cg.CGEventCreateScrollWheelEvent
  wheel.restype=C.c_void_p;wheel.argtypes=[C.c_void_p,C.c_uint,C.c_uint,C.c_int]
  location=mac.cg.CGEventSetLocation
  location.restype=None;location.argtypes=[C.c_void_p,Point]
  for i,delta in enumerate([0]+[-32]*12+[-96]*12+[32]*12+[96]*12):
   if time.monotonic()>deadline-1:raise TimeoutError('bounded wheel acquisition deadline')
   mac.send(5,point)  # AX hit-testing confirms the target belongs to our child.
   if delta:
    event=wheel(None,0,1,delta)
    if not event:raise RuntimeError('cannot create wheel event')
    try:
     location(event,point);mac.key_flags(event,0);mac.post(0,event)
    finally:mac.release(event)
   sent=time.monotonic()-started
   time.sleep(.025)
   windows=capture.owned_windows(child.pid,{TITLE})
   if len(windows)!=1:raise RuntimeError('owned window missing or ambiguous')
   window_id,_=windows[0]
   path=out/f'frame-{i:04d}-window-{window_id}.png'
   frame={'path':path.name,'delta_pixels':delta,'sent_seconds':sent,'capture_started_seconds':time.monotonic()-started}
   report['frames'].append(frame)
   subprocess.run(['screencapture','-x','-o','-l',str(window_id),str(path)],check=True,timeout=min(3,deadline-time.monotonic()))
   frame['capture_finished_seconds']=time.monotonic()-started
   time.sleep(.025)
  report['status']='collected'
except BaseException as error:
 report['error']=f'{type(error).__name__}: {error}'
 raise
finally:
 if mac:mac.release(mac.app)
 if child:
  stop_child(child);report['child_returncode_after_cleanup']=child.returncode
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('WHEEL_CAPTURE_COLLECTED',len(report['frames']))
