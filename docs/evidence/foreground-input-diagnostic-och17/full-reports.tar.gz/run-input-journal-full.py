"""One predeclared full diagnostic, never performance acceptance."""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
sys.path.insert(0, str(Path.cwd() / 'scripts'))
from test_agent_chat import Mac
base = Path(__file__).resolve().parent
out = base / 'input-journal-full-001'
out.mkdir()
binary = Path('_build/default/examples/performance_presented/list/main.exe').resolve()
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest == '92fe5c3cd058d2ee70e2f93b6508210a68f46d7500fc753d8b11f03115414ada'
report = {'plan': 'One full unchanged 10k-row traversal/growth/60s idle. Existing recorded diagnostic binary; journal enabled, no input injection. Startup activation only before first begin; no AX query during measurement. Retain any failure, no automatic retries. Not performance acceptance.',
          'executable_sha256': digest, 'command': [str(binary)],
          'journal_enabled': True, 'phases': [], 'foreground_preflight': False}
(out / 'plan.json').write_text(json.dumps(report, indent=2)+'\n')
def timeout(*_):
    raise TimeoutError('Full diagnostic exceeded 600 seconds')
signal.signal(signal.SIGALRM, timeout)
child = subprocess.Popen([str(binary)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True, env={**os.environ, 'GPUIO_DIAGNOSE_FOREGROUND_INPUT': '1'})
awake = subprocess.Popen(['/usr/bin/caffeinate','-di','-w',str(child.pid)])
mac = None
phase = None
started = time.monotonic()
try:
    signal.alarm(600)
    mac = Mac(child.pid, child)
    with (out/'application.log').open('w') as log:
        for line in child.stdout:
            log.write(line)
            log.flush()
            if line.startswith('GPUIO_PERF config '):
                deadline = time.monotonic()+5
                window = mac.window('GPUIO · Performance qualification')
                while not window and time.monotonic()<deadline:
                    time.sleep(.025)
                    window = mac.window('GPUIO · Performance qualification')
                assert window
                try:
                    mac.set(mac.app,'AXFrontmost',mac.true)
                    mac.perform(window,'AXRaise')
                finally:
                    mac.release(window)
                get=mac.cf.CFBooleanGetValue
                get.restype,get.argtypes=C.c_bool,[C.c_void_p]
                while time.monotonic()<deadline:
                    value=mac.attr(mac.app,'AXFrontmost')
                    try:
                        if value and get(value):
                            report['foreground_preflight']=True
                            break
                    finally:
                        if value:mac.release(value)
                    time.sleep(.025)
                assert report['foreground_preflight']
                mac.release(mac.app)
                mac=None
            if line.startswith('GPUIO_PERF begin '):
                assert report['foreground_preflight']
                phase = line.split('(',1)[1].split()[0]
                print('PHASE',phase,'elapsed',round(time.monotonic()-started,3),flush=True)
            if line.startswith('GPUIO_PRESENTATION '):
                raw=json.loads(line.removeprefix('GPUIO_PRESENTATION '))
                report['phases'].append({'name':phase, 'cpu_draw_samples':raw['cpu_draw_samples'],
                   'cpu_input_samples':raw['cpu_input_samples'],
                   'cpu_elapsed_ns':raw['cpu_elapsed_ns'],
                   'inputs':raw['diagnostic_foreground_inputs'],
                   'end_observation':raw['end_observation']})
                print('SUMMARY',json.dumps(report['phases'][-1]),flush=True)
            if line.startswith('GPUIO_PERF cleanup '):report['cleanup']=line.strip()
            if line.startswith('GPUIO_PERF complete '):report['app_complete']=line.strip()
    report['exit']=child.wait(timeout=5)
except BaseException as error:
    report['error']=f'{type(error).__name__}: {error}'
    raise
finally:
    signal.alarm(0)
    if child.poll() is None:
        child.terminate()
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:child.kill();child.wait()
    if mac:mac.release(mac.app)
    if child.stdout:child.stdout.close()
    if awake.poll() is None:awake.terminate()
    awake.wait(timeout=5)
    report['child_reaped_exit']=child.returncode
    report['elapsed_seconds']=time.monotonic()-started
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print('FINISHED',report.get('exit'),flush=True)
