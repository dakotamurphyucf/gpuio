import ctypes as C
import hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, str(Path.cwd()/'scripts'))
from test_agent_chat import Mac
from test_gallery import GalleryMouse, element_rect
root=Path('scratch/agents/root-20261007-access-check')
binary=Path('_build/default/examples/performance_presented/list/main.exe').resolve()
mode=sys.argv[1]
assert mode in ('quiet','input')
out=root/('input-journal-'+mode+'-'+sys.argv[2]);out.mkdir()
report={'mode':mode,'executable_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'scope':'diagnostic smoke only; not release acceptance','summaries':[]}
def timeout(*_):raise TimeoutError('bounded input diagnostic smoke exceeded 60 seconds')
signal.signal(signal.SIGALRM,timeout)
child=subprocess.Popen([str(binary),'--smoke'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env={**os.environ,'GPUIO_DIAGNOSE_FOREGROUND_INPUT':'1'})
mac=None
try:
 signal.alarm(60)
 mac=Mac(child.pid,child)
 with (out/'application.log').open('w') as log:
  for line in child.stdout:
   log.write(line);log.flush()
   if line.startswith('GPUIO_PERF config '):
    window=mac.window('GPUIO · Performance qualification')
    deadline=time.monotonic()+5
    while not window and time.monotonic()<deadline:
     time.sleep(.05);window=mac.window('GPUIO · Performance qualification')
    assert window
    try:mac.set(mac.app,'AXFrontmost',mac.true);mac.perform(window,'AXRaise')
    finally:mac.release(window)
   if line.startswith('GPUIO_PERF begin (idle ') and mode=='input':
    window=mac.window('GPUIO · Performance qualification')
    try:x,y,w,h=element_rect(mac,window)
    finally:mac.release(window)
    mouse=GalleryMouse(mac)
    for dx in (0,30,60,90):
     point=(x+w/2+dx,y+h/2);mouse.check_owner(point);mouse.send(5,point);time.sleep(.06)
    report['injected_mouse_moves']=4
   if line.startswith('GPUIO_PRESENTATION '):
    data=json.loads(line.removeprefix('GPUIO_PRESENTATION '))
    report['summaries'].append(data['diagnostic_foreground_inputs'])
 report['exit']=child.wait(timeout=5)
 assert len(report['summaries'])==2,report
 idle=report['summaries'][1]
 assert idle is not None and idle['lost_entries']==0,report
 if mode=='input':
  assert report.get('injected_mouse_moves')==4 and idle['input_events']>=4,report
  assert any('mouse' in r['kind'].lower() and r['events']>=4 for r in idle['kinds']),report
 else:
  assert report['exit']==0 and idle['input_events']==0,report
 report['diagnostic_verified']=True
finally:
 signal.alarm(0)
 if child.poll() is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait()
 if mac:mac.release(mac.app)
 if child.stdout:child.stdout.close()
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
