# OCH-41 finite counts / directions draft

Previous goalturnPROGRESS4c959f5; cleanrevalidated; CI37374125077 queuedbothjobs.
Interface drafted animation.mli before implementation. Keep old Repeat variants
bytes/semantics. Append Finite(count,direction), Infinite(direction). Count abstract
unsigned64, wiretwo validated32-bit limbs highthenlow in binprot int64fields;
no count-dependentallocation. Public of_int/of_int64/of_string + canonicaldecimal.
DirectionsNormal/Reverse/Alternate/Alternate_reverse. Explicitnewpolicies reverse
whole compiled timeline time (easing(1-t) forsingle stage); oldProgramAlternate
retains interval-reversal contract. Source vendor/gpui-base/src/motion/timing.rs.
Finite count0 terminal lastiteration=max(count-1,0), directedprogress1 perupstream.
Finite completes onceafterpaint, no per-stage/per-cycleevents fornewFinitepolicy;
oldOncekeepsstageobservations. Infinite neverfinish. Finitezero-durationallowed;
infinitecyclemustpositive. SharedclocksInfiniteonly (legacyLoopAlternatealso),
noinitialdelay andtimedstages. Positiveinitialdelay beforeallcycles once; negative
elapsedoffset alreadyimplemented. Pause/hidden/snapshotfencespreserved.
Directed reverse finalvalue is compiledtimelineinitial, normalfinalvalueitsfinal.
Reducedfinite follows terminaldirection; infinite holdsdirectedstart,no wakes.
Retargetfirstcycle usespaintedfrom, subsequentdeclaredranges; reverseintentional
jump allowedconsistentnegativeoffset. Springreverse sampledtrajectorytime backward,
velocitynegated; no rerun numericalintegration/percyclecompile.
Need account timelines, reversed holds/deadlines, constantfinite wakeatcompletion,
largecountu128math <=2^64*oneday nanos fitsu128; capu128waitwhenconvertingDuration.
