from pathlib import Path
import json,os,signal,subprocess,time
notes=Path('scratch/agents/root-20261004-resumed');env=dict(os.environ,GPUIO_JOBS='2',RUST_BACKTRACE='1')
import sys
sys.path.insert(0,str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
checks=[('shutdown-011',['python3','scripts/test_macos_document_shutdown.py','--log',str(notes/'rendered-cross-shutdown-current-app.log'),'--report',str(notes/'rendered-cross-shutdown-current.json')],90)]
results=[]
for name,command,timeout in checks:
 path=notes/('rendered-cross-'+name+'.log');start=time.monotonic();print('START',name,flush=True)
 with preserved_clipboard(), path.open('w') as log:
  child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:status=child.wait(timeout=timeout)
  except BaseException:
   os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 result=dict(name=name,command=command,exit=status,seconds=time.monotonic()-start,log=str(path))
 results.append(result);(notes/'rendered-cross-shutdown-checks.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,status,flush=True)
 if status:raise SystemExit(status)
