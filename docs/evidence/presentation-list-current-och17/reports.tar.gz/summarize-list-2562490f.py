import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
batch = json.loads((base / 'list-2562490f-batch.json').read_text())
summary = {'revision': batch['revision'], 'executable_sha256': batch['executable_sha256'],
           'plan': batch['plan'], 'running': batch.get('running'), 'trials': []}
for trial in batch['trials']:
    path = base / f"list-2562490f-{trial['name']}" / 'report.json'
    raw = path.read_bytes()
    report = json.loads(raw)
    row = {k: v for k, v in trial.items() if k != 'command'}
    row.update(report_sha256=hashlib.sha256(raw).hexdigest(),
               revision=report['revision'], dirty=report['dirty'],
               executable_sha256=report['executable_sha256'],
               budget_failures=report.get('budget_failures'),
               peak_rss_bytes=report.get('peak_rss_bytes'),
               wall_seconds=report.get('wall_seconds'))
    workload = report.get('workload', {})
    row['coverage'] = workload.get('coverage')
    for phase in ('history', 'idle'):
        cpu = workload.get(phase)
        if cpu:
            row[phase] = dict(elapsed_ns=cpu['elapsed_ns'],
                              histograms={k: {n: v[n] for n in ('count', 'p95', 'p99')}
                                          for k, v in cpu['histograms'].items()})
        native = report.get('presentation', {}).get(phase)
        if native:
            row[phase]['presentation'] = dict(
                counts=native['native']['counts'],
                startup_transition=native['startup_transition'],
                histograms={k: {n: v[n] for n in ('count', 'p95', 'p99')}
                            for k, v in native['native']['histograms'].items()},
                observations=len(native['observations']),
                all_sampled_active_visible=all(x['active'] and x['visible']
                    for x in [*native['observations'], native['end_observation']]))
    summary['trials'].append(row)
output = base / 'list-2562490f-summary.json'
output.write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'running': summary['running'], 'trials': [
    {k: row.get(k) for k in ('name', 'complete', 'driver_exit', 'budget_failures')}
    for row in summary['trials']]}, indent=2))
