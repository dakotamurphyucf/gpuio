Base revision: 80b1f781a11c4fb8810cd547b43cabeb9f5b2ed5, plus archived source changes.
macOS 14.5 arm64, M1 Max. GPUIO_JOBS=2; isolated toolchain. Native library/protocol unchanged.
GPUIO_JOBS=2 ./scripts/gpuio exec dune build examples/menus/main.exe @fmt
GPUIO_JOBS=2 python3 scripts/test_extension_consumer.py --example menus --workspace scratch/agents/root-20261004-resumed/native-popup-lifecycle-armed-consumer
python3 scripts/test_native_popup_macos.py --binary scratch/agents/root-20261004-resumed/native-popup-lifecycle-armed-consumer/consumer/_build/default/main.exe
Repeat final command with --lifecycle close, retire, invalidate, replace, hide, disable, modal, each sequentially.
Eight final installed physical runs passed; all children exited0; ordinary interaction preserved/restored clipboard.
python3 -m py_compile scripts/test_native_popup_macos.py
scratch/agents/root-20260925-resumed/actionlint/actionlint -shellcheck= .github/workflows/foundation.yml
Build/@fmt, independent staging, Python and actionlint pass. Hosted new workflow step not yet run.
Initial build.log retains a corrected Bonsai button callback type error; initial local replace/hide/disable/modal logs precede explicit Arm button improvement.
