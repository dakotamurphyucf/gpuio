open Core

(** Application runner. [run] owns GPUI on the OS main thread and starts one
    OCaml UI domain running Eio. Initialization, components and effects run on
    that UI domain. All methods below enforce that ownership. *)
type t

module Stats : sig
  type t =
    { turns : int
    ; clock_ticks : int
    ; commits : int
    ; rendered : int
    ; completed_jobs : int
    }
  [@@deriving sexp_of]
end

module Window : sig
  type t

  val scope : t -> Scope.t

  (** Force-close; bypasses the application close decision and cancels the
      window scope. Repeated/reentrant calls are idempotent. If cleanup raises,
      remaining cleanup and queueing the native close request are attempted before
      re-raising the first failure; an opening window waits for its opening
      acknowledgement before submitting close. Native destruction is asynchronous.
      Use [request_close] for ordinary user commands. *)
  val close : t -> unit

  (** Coalesced asynchronous decision. Force-close invalidates a delayed answer.
      Window work remains live while a decision is pending. Default is Allow. *)
  val request_close : t -> unit

  val set_close_handler
    :  t
    -> (Gpuio.Window.Close_reason.t -> Gpuio.Window.Close_decision.t Bonsai.Effect.t)
    -> unit

  (** Last observed native state. It can arrive before the opening acknowledgement;
      [Some _] does not imply [is_open] or frame-request readiness. *)
  val snapshot : t -> Gpuio.Window.Snapshot.t option

  val on_change : t -> (Gpuio.Window.Snapshot.t -> unit Bonsai.Effect.t) -> unit

  (** Acknowledges current observed state. Resizing/fullscreen may complete later;
      listen to [on_change]. Requests use the exact window generation. *)
  val command
    :  t
    -> Gpuio.Window.Command.t
    -> (Gpuio.Window.Snapshot.t, Gpuio.Window.Error.t) Result.t Bonsai.Effect.t

  (** Native focus at request execution, including read-only text inputs but
      excluding hidden/disabled/modal-blocked owners. The option reports presence;
      it contains metadata only, never password/OTP values or arbitrary text.
      Uses the same bounded request lane and close rules as [command]. *)
  val focused_input
    :  t
    -> (Gpuio.Window.Input.t option, Gpuio.Window.Error.t) Result.t Bonsai.Effect.t

  (** Registered read-only text/document selection in the active native scope.
      These helpers neither access the clipboard nor read editable input values. *)
  val has_text_selection : t -> (bool, Gpuio.Window.Error.t) Result.t Bonsai.Effect.t

  (** Nonempty fragments joined in logical order with newlines. [max_bytes] is
      a UTF-8 byte limit in [0,262144], default [65536]. Oversize returns
      [Limit_exceeded], never a truncated result. Legacy renderer callbacks may
      allocate their individual fragment before the collector checks its size. *)
  val selected_text
    :  t
    -> ?max_bytes:int
    -> unit
    -> (string, Gpuio.Window.Error.t) Result.t Bonsai.Effect.t

  (** Clear window geometry and all registered renderer-local selections. Acts
      on current native selection at execution, including inactive registrations. *)
  val clear_text_selection : t -> (unit, Gpuio.Window.Error.t) Result.t Bonsai.Effect.t

  (** Stop selection drag/auto-scroll while preserving its visible range. *)
  val end_text_selection : t -> (unit, Gpuio.Window.Error.t) Result.t Bonsai.Effect.t

  val is_closed : t -> bool

  (** Native opening has been acknowledged, closing has not begun and the
      application is not stopping. This is not the negation of [is_closed]: both
      are false while opening. It does not imply focus, visibility, a rendered
      frame or published application data. Like other window queries, call on the
      OCaml UI domain. A later asynchronous operation must still handle closure. *)
  val is_open : t -> bool

  val set_theme : t -> Gpuio.Theme.t -> unit

  (** At most one request per open window. Call after [is_open]; requests
      before native opening return an error. This observes a render callback,
      not physical screen presentation. Delivery can be deferred while a window
      is occluded: the pinned macOS backend stops its display link then. Do not
      use a frame callback as an application/data readiness barrier. *)
  val request_frame
    :  t
    -> on_rendered:(revision:int64 -> unit Bonsai.Effect.t)
    -> unit Or_error.t

  module Expert : sig
    (** Correlated native picker, scoped to this exact window generation. Only
        one request may be pending per window. Closing returns [Closed]. *)
    val file_dialog
      :  t
      -> Gpuio.File_dialog.Request.t
      -> (Gpuio.File_path.t list option, Gpuio.File_dialog.Error.t) Result.t
           Bonsai.Effect.t

    val file_dialog_capabilities
      :  t
      -> (Gpuio.File_dialog.Capabilities.t, Gpuio.File_dialog.Error.t) Result.t
           Bonsai.Effect.t

    (** Captures the exact context-menu subscription. Successful replies mean
        native admission, not paint or selection. At most 64 requests may be
        pending per application; closing completes pending requests once. *)
    val menu_command
      :  t
      -> Gpuio.Menu.Snapshot.t
      -> Gpuio.Menu.Command.t
      -> (unit, Gpuio.Menu.Command_error.t) Result.t Bonsai.Effect.t

    (** Captures the exact observed palette subscription. An optional query
        fence is checked against current native input before executing. *)
    val palette_command
      :  t
      -> Gpuio.Command_palette.Snapshot.t
      -> ?if_query_unchanged:bool
      -> Gpuio.Command_palette.Command.t
      -> ( Gpuio.Command_palette.Snapshot.t
           , Gpuio.Command_palette.Command_error.t )
           Result.t
           Bonsai.Effect.t

    (** Correlated native commands for controller adapters. Captures the exact
        editor lease; a delayed effect never targets a remounted replacement. *)
    val editor_command
      :  t
      -> Gpuio.Text_input.Snapshot.t
      -> Gpuio.Text_input.Command.t
      -> (Gpuio.Text_input.Snapshot.t, Gpuio.Text_input.Command_error.t) Result.t
           Bonsai.Effect.t

    (** Metadata-only query on the exact observed editor lease, sharing the
        ordinary editor request budget and close/correlation checks. *)
    val editor_content_hint_status
      :  t
      -> Gpuio.Text_input.Snapshot.t
      -> ( Gpuio.Text_input.Content_hint.Status.t
           , Gpuio.Text_input.Command_error.t )
           Result.t
           Bonsai.Effect.t

    (** Last completed layout; acceptance of a scroll request is distinct from paint. *)
    val editor_viewport
      :  t
      -> Gpuio.Text_input.Snapshot.t
      -> (Gpuio.Editor_viewport.t option, Gpuio.Text_input.Command_error.t) Result.t
           Bonsai.Effect.t

    val editor_scroll_to
      :  t
      -> Gpuio.Text_input.Snapshot.t
      -> Gpuio.Editor_viewport.Offset.t
      -> (unit, Gpuio.Text_input.Command_error.t) Result.t Bonsai.Effect.t

    val editor_range_bounds
      :  t
      -> Gpuio.Text_input.Snapshot.t
      -> Gpuio.Text_input.Selection.t
      -> (Gpuio.Editor_geometry.t option, Gpuio.Text_input.Command_error.t) Result.t
           Bonsai.Effect.t

    val editor_search
      :  t
      -> Gpuio.Text_input.Snapshot.t
      -> Gpuio.Text_input.Search.Command.t
      -> ( Gpuio.Text_input.Search.Response.t * Gpuio.Text_input.Snapshot.t option
           , Gpuio.Text_input.Command_error.t )
           Result.t
           Bonsai.Effect.t

    (** Correlated slider commands bound to the exact observed window/node lease. *)
    val slider_command
      :  t
      -> Gpuio.Slider.Snapshot.t
      -> Gpuio.Slider.Command.t
      -> (Gpuio.Slider.Snapshot.t, Gpuio.Slider.Command_error.t) Result.t Bonsai.Effect.t

    (** Correlated OTP commands for the exact observed window/node lease. At most
        64 requests may be pending across the app. Closing rejects new requests;
        already-admitted commands can reply before native closure. Actual closure
        completes remaining requests with [Closed].
        Applied replies must preserve policy and not precede the observed revision. *)
    val otp_input_command
      :  t
      -> Gpuio.Otp_input.Snapshot.t
      -> Gpuio.Otp_input.Command.t
      -> (Gpuio.Otp_input.Snapshot.t, Gpuio.Otp_input.Command_error.t) Result.t
           Bonsai.Effect.t

    (** Correlated calendar commands for the exact observed window/node lease.
        At most 64 calendar requests may be pending across the app. Replies must
        preserve mode and not precede the observed revision. Unsupported dates or
        navigation offsets fail with [Invalid_value] before entering the queue.
        Actual window closure completes remaining requests with [Closed]. *)
    val calendar_command
      :  t
      -> Gpuio.Calendar.Snapshot.t
      -> Gpuio.Calendar.Command.t
      -> (Gpuio.Calendar.Snapshot.t, Gpuio.Calendar.Command_error.t) Result.t
           Bonsai.Effect.t

    (** Correlated color commands for the observed window/node lease. At most 64
        color requests may be pending across the app. Replies cannot precede the
        observed revision. Closing completes remaining requests with [Closed]. *)
    val color_input_command
      :  t
      -> Gpuio.Color_input.Snapshot.t
      -> Gpuio.Color_input.Command.t
      -> (Gpuio.Color_input.Snapshot.t, Gpuio.Color_input.Command_error.t) Result.t
           Bonsai.Effect.t

    (** Internal nonblocking cleanup on the owning UI domain. Uses the original
        request lease/token/revision, takes no ordinary pending-command slot and
        ignores its reply. Closed/stopping windows need no further decline. *)
    val decline_number_step : t -> Gpuio.Number_input.Step_request.t -> unit

    (** Correlated numeric commands bound to the observed window/node lease;
        at most 64 requests pending. Closing completes them with [Closed]. *)
    val number_input_command
      :  t
      -> Gpuio.Number_input.Snapshot.t
      -> Gpuio.Number_input.Command.t
      -> (Gpuio.Number_input.Snapshot.t, Gpuio.Number_input.Command_error.t) Result.t
           Bonsai.Effect.t
  end
end

module Expert : sig
  (** Application-scoped OS notifications: 16 pending requests plus a reserved
      close lane. [Close] permanently disables this application's service.
      Terminal shutdown resolves outstanding requests with [Closed]. *)
  val notification
    :  t
    -> Gpuio_protocol.Notification_wire.Request.t
    -> Gpuio_protocol.Notification_wire.Response.t Bonsai.Effect.t

  (** Exclusive, generation-checked availability subscription on the UI domain.
      Unregistering does not itself close native notification ownership. *)
  val on_notification_pending
    :  t
    -> (unit -> unit Bonsai.Effect.t)
    -> (unit -> unit, Gpuio.Notification.Error.t) Result.t

  (** Application-scoped desktop protocol. At most 16 pending requests; closing
      resolves them with [Closed]. Requesting [Take_links] consumes the native
      FIFO and its overflow counter, without routing or interpreting its values. *)
  val desktop
    :  t
    -> Gpuio_protocol.Desktop_wire.Request.t
    -> Gpuio_protocol.Desktop_wire.Response.t Bonsai.Effect.t

  (** Exclusive application subscription; a second live subscriber returns
      [Busy]. The returned idempotent unregister closure cannot remove a later
      subscriber. Pending signals survive initial registration, but queued jobs
      from a retired subscription cannot invoke a replacement. The callback runs
      on the UI domain and must request input when ready. Signals are coalesced
      availability hints, not one callback per URL. *)
  val on_desktop_pending
    :  t
    -> (unit -> unit Bonsai.Effect.t)
    -> (unit -> unit, Gpuio.Desktop.Error.t) Result.t

  (** Raw chart resource protocol, bounded to 63 pending requests with one lane
      reserved for the scoped adapter. Callers own release and late-reply cleanup.
      Publish replies only after native background validation and atomic commit. *)
  val chart
    :  t
    -> Gpuio_protocol.Wire.Chart.Request.t
    -> Gpuio_protocol.Wire.Chart.Response.t Bonsai.Effect.t

  (** Raw correlated scene-resource protocol; at most 63 pending requests.
      Callers own release and late-reply cleanup. This registers scene data;
      it does not itself create a rendered canvas. One additional request lane
      is reserved for the scoped adapter. *)
  val canvas
    :  t
    -> Gpuio_protocol.Wire.Canvas.Request.t
    -> Gpuio_protocol.Wire.Canvas.Response.t Bonsai.Effect.t

  (** Internal correlated document-resource lane. Bounded to 64 requests.
      Public applications use the scoped document adapter. *)
  val document
    :  t
    -> Gpuio_protocol.Wire.Document.Request.t
    -> Gpuio_protocol.Wire.Document.Response.t Bonsai.Effect.t

  val register_chart
    :  t
    -> scope:Scope.t
    -> Gpuio.Chart_data.t
    -> (Chart_registry.Registration.t, Chart_registry.Error.t) Result.t Bonsai.Effect.t

  val register_canvas
    :  t
    -> scope:Scope.t
    -> Gpuio.Canvas_scene.t
    -> (Canvas_registry.Registration.t, Canvas_registry.Error.t) Result.t Bonsai.Effect.t

  val register_document
    :  t
    -> scope:Scope.t
    -> Gpuio.Text_source.t
    -> (Document_registry.Registration.t, Gpuio_protocol.Wire.Document.Error.t) Result.t
         Bonsai.Effect.t

  (** Correlated raw registration protocol, bounded to 63 pending requests;
      a separate lane is reserved for scoped upload/cleanup.
      This is not the scoped public asset API: callers own release/late-reply
      cleanup. A completed upload contains encoded data, not decoded pixels. *)
  val asset
    :  t
    -> Gpuio_protocol.Wire.Asset.Request.t
    -> Gpuio_protocol.Wire.Asset.Response.t Bonsai.Effect.t

  val register_asset
    :  t
    -> scope:Scope.t
    -> Gpuio.Asset.Source.t
    -> (Asset_registry.Registration.t, Asset_registry.Error.t) Result.t Bonsai.Effect.t
end

val scope : t -> Scope.t
val stats : t -> Stats.t

module Diagnostics : sig
  (** Read-only UI-domain snapshot. Registry bytes are conservative OCaml-side
      reservations for encoded assets, canonical source snapshots and scenes;
      they exclude native decoded caches, GPU allocations and model payloads.
      Pending requests include correlated lifecycle, input, resource and frame
      requests; queued commands have not yet been accepted by the native host.
      Native command-queue bytes count accepted serialized input awaiting dispatch,
      with a lifetime high-water mark; they exclude executing work and outputs.
      Asset counts include uploads and registrations awaiting native release
      acknowledgments. After scope cancellation, source reservations can be zero
      while registrations are still retiring. Snapshot values do not update;
      sample again to observe cleanup progress.
      Sampling creates no bridge command and does not request a frame. *)
  type t =
    { runtime : Stats.t
    ; traffic : Gpuio_native.Traffic.t
    ; native_command_queue : Gpuio_native.Command_queue.t
    ; scopes : Scope.Stats.t
    ; windows : int
    ; queued_jobs : int
    ; queued_commands : int
    ; pending_requests : int
    ; assets : int
    ; asset_uploads : int
    ; asset_source_bytes : int
    ; documents : int
    ; document_source_bytes : int
    ; charts : int
    ; chart_data_bytes : int
    ; canvases : int
    ; canvas_scene_bytes : int
    }
  [@@deriving sexp_of]
end

val diagnostics : t -> Diagnostics.t

(** Force application cleanup, bypassing decisions. Remaining cleanup and native
    shutdown request queueing are still attempted if a cleanup raises, then the first
    failure is re-raised. Repeated/reentrant calls are idempotent; returning does
    not mean the native event loop has finished stopping. *)
val shutdown : t -> unit

(** Ask all live windows before destroying any of them. A denial keeps the
    application open. New windows are rejected during a pending quit decision. *)
val request_quit : t -> unit

val window_capabilities : t -> Gpuio.Window.Capabilities.t option
val on_reopen : t -> (unit -> unit Bonsai.Effect.t) -> unit

(** Immutable identity declared to [run]. Native configuration is queued before
    initialization can enqueue windows or desktop requests. *)
val desktop_identity : t -> Gpuio.Desktop.Identity.t option

(** Application-wide native motion policy. [System] follows available platform
    preferences and defaults to full motion when no preference is available.
    [Reduce] and [Full] override the platform until [System] is selected again.
    This also controls indeterminate progress. Changes are asynchronous and
    coalesced before submission; no per-frame OCaml callbacks are introduced.
    Calls after shutdown are ignored. *)
val set_motion : t -> Gpuio.Animation.Preference.t -> unit

(** Up to 32 simultaneously live windows; closed slots are reused with new
    generations. Width/height are logical pixels in [1,16384]. Titles contain
    1..4096 UTF-8 bytes without NUL. The component factory is invoked on the UI domain. *)
val open_window
  :  t
  -> ?theme:Gpuio.Theme.t
  -> ?focus:bool
  -> ?chrome:Gpuio.Window.Chrome.t
  -> ?resizable:bool
  -> ?frame:Gpuio.Window_frame.t
  -> title:string
  -> width:float
  -> height:float
  -> (Window.t -> unit Bonsai.Effect.t Gpuio.View.t Bonsai.Computation.t)
  -> Window.t Or_error.t

val open_window_config
  :  t
  -> ?theme:Gpuio.Theme.t
  -> Gpuio.Window.Config.t
  -> (Window.t -> unit Bonsai.Effect.t Gpuio.View.t Bonsai.Computation.t)
  -> Window.t Or_error.t

(** Defaults: 60 Hz shared monotonic timer, 1024 tasks, exit on last window,
    [System] motion preference. The initial motion policy precedes opening windows.
    With [exit_on_last_window=false], application/conversation work may continue
    with no windows; call [shutdown] to finish. Parameter validation raises.
    [tick_hz] is in [0.01,240]; [max_tasks] is in [1,65536].
    Application/task callback failures propagate after native and Eio cleanup.

    [document_defaults] belongs to this run and applies to every window, including
    later windows. Config omissions inherit; explicit values/Builtin override.
    Shared action/profile callbacks receive the resolved source config. *)
val run
  :  ?document_defaults:unit Bonsai.Effect.t Gpuio.Document.Defaults.t
  -> ?tick_hz:float
  -> ?max_tasks:int
  -> ?exit_on_last_window:bool
  -> ?motion:Gpuio.Animation.Preference.t
  -> ?desktop:Gpuio.Desktop.Identity.t
  -> (Eio_unix.Stdenv.base -> t -> unit)
  -> unit

(** Read the linked component schemas on the OS main thread before [run].
    This initializes the selected backend and freezes native registration.
    Compare with package definitions before constructing application windows. *)
val extension_catalog : unit -> Gpuio.Extension.Schema.t list Or_error.t

(** Statically linked document profiles; preflight on the main thread before run. *)
val document_profile_catalog : unit -> Gpuio.Document.Profile.Schema.t list Or_error.t

module Launch_outcome : sig
  type t =
    | Exited
    | Forwarded
  [@@deriving equal, sexp_of]
end

(** Desktop entry point with explicit startup arguments. On Linux, claim the
    application's identity on the current session bus before starting GPUI. If
    owned, atomically forward [startup_links] and return [Forwarded] without
    calling [initialize]. An empty secondary launch requests [on_reopen].
    The primary delivers startup links through [Desktop.attach]/[ready].
    macOS uses LaunchServices for packaged single-instance dispatch; explicit
    startup links are queued in addition to OS-delivered links.

    Each batch permits 64 UTF-8, NUL-free strings, at most 16 KiB each and
    256 KiB total. URI syntax is validated during normal desktop delivery.
    [Busy] means no part of the forwarded batch was admitted. [Native_failure]
    may mean the reply was lost after admission: do not automatically retry.
    Missing Linux session bus returns [Unavailable], without starting another UI.
    [Exited] means the primary ran and completed cleanup. Other options and
    callback exception behavior match [run]. No global argv parsing occurs. *)
val run_desktop
  :  ?document_defaults:unit Bonsai.Effect.t Gpuio.Document.Defaults.t
  -> ?tick_hz:float
  -> ?max_tasks:int
  -> ?exit_on_last_window:bool
  -> ?motion:Gpuio.Animation.Preference.t
  -> Gpuio.Desktop.Identity.t
  -> startup_links:string list
  -> (Eio_unix.Stdenv.base -> t -> unit)
  -> (Launch_outcome.t, Gpuio.Desktop.Error.t) Result.t
