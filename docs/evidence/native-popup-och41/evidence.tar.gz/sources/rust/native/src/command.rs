//! Window-owned command routing. Native shortcut matching, focus gates and edit
//! actions complete on the GPUI thread; application actions are queued to OCaml.
use super::View;
use crate::session::CommandInvocation;
use gpui::{App, Context, Focusable, Keystroke, Window};
use gpuio_protocol::{HandlerId, NodeId, v1::*};
use std::sync::Arc;

#[cfg(test)]
#[path = "command_lifetime_test.rs"]
mod lifetime_test;

#[cfg(test)]
#[path = "command_policy_test.rs"]
mod policy_test;

#[derive(Clone, PartialEq, Eq)]
pub(super) struct Route {
    scope: NodeId,
    handler: HandlerId,
    revision: i64,
    pub(super) config: Arc<CommandConfig>,
    source: CommandSource,
    editor_target: Option<(NodeId, gpui::WeakFocusHandle)>,
}
impl Route {
    pub(super) fn new(
        tree: &crate::tree::Tree,
        scope: NodeId,
        config: &Arc<CommandConfig>,
        source: CommandSource,
    ) -> Self {
        Self {
            scope,
            handler: tree
                .get(scope)
                .expect("scope")
                .handler
                .expect("registry handler"),
            revision: tree.revision(),
            config: config.clone(),
            source,
            editor_target: None,
        }
    }
    pub(super) fn bind_editor(mut self, target: (NodeId, gpui::WeakFocusHandle)) -> Self {
        self.editor_target = Some(target);
        self
    }
    pub(super) fn request(&self) -> CommandInvocation<'_> {
        CommandInvocation {
            scope: self.scope,
            handler: self.handler,
            revision: self.revision,
            command: &self.config.id,
            generation: self.config.generation,
            source: self.source,
        }
    }
}
fn keystroke(shortcut: &Shortcut) -> Keystroke {
    let mut modifiers = gpui::Modifiers::default();
    for modifier in &shortcut.modifiers {
        match modifier {
            ShortcutModifier::Primary => {
                #[cfg(target_os = "macos")]
                {
                    modifiers.platform = true;
                }
                #[cfg(not(target_os = "macos"))]
                {
                    modifiers.control = true;
                }
            }
            ShortcutModifier::Control => modifiers.control = true,
            ShortcutModifier::Alt => modifiers.alt = true,
            ShortcutModifier::Shift => modifiers.shift = true,
            ShortcutModifier::Super => modifiers.platform = true,
        }
    }
    Keystroke {
        key: shortcut.key.clone(),
        key_char: None,
        modifiers,
    }
}

fn native_action(action: NativeCommand) -> Box<dyn gpui::Action> {
    match action {
        NativeCommand::Copy => Box::new(gpui_base::input::Copy),
        NativeCommand::Cut => Box::new(gpui_base::input::Cut),
        NativeCommand::Paste => Box::new(gpui_base::input::Paste),
        NativeCommand::SelectAll => Box::new(gpui_base::input::SelectAll),
        NativeCommand::Undo => Box::new(gpui_base::input::Undo),
        NativeCommand::Redo => Box::new(gpui_base::input::Redo),
    }
}

/// Native input policy shared by routing and binding inspection. Availability
/// and scope/modal gates are separate: the first matching declaration reserves
/// the chord even when invocation subsequently fails those checks.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct InputContext {
    editing: bool,
    composing: bool,
    focused_kind: Option<Kind>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum InputGate {
    NativeNavigation,
    Composition,
    TextInput,
}

impl InputContext {
    fn reserves_navigation(key: &Keystroke, focused_kind: Option<Kind>) -> bool {
        (key.key == "tab"
            && !key.modifiers.control
            && !key.modifiers.platform
            && !key.modifiers.alt)
            || (!key.modifiers.modified()
                && matches!(key.key.as_str(), "enter" | "space")
                && focused_kind.is_some_and(|kind| {
                    matches!(
                        kind,
                        Kind::Button
                            | Kind::CommandButton
                            | Kind::Checkbox
                            | Kind::Switch
                            | Kind::Radio
                    )
                }))
    }

    fn gate(self, shortcut: &Shortcut, key: &Keystroke) -> Option<InputGate> {
        if shortcut.priority == ShortcutPriority::NativeFirst
            && Self::reserves_navigation(key, self.focused_kind)
        {
            return Some(InputGate::NativeNavigation);
        }
        if self.composing && !shortcut.during_composition {
            return Some(InputGate::Composition);
        }
        let allowed = match shortcut.text_input {
            ShortcutTextInput::Always => true,
            ShortcutTextInput::Never => !self.editing,
            ShortcutTextInput::ModifiedOnly => {
                !self.editing
                    || key.modifiers.control
                    || key.modifiers.platform
                    || key.modifiers.alt
            }
        };
        (!allowed).then_some(InputGate::TextInput)
    }

    fn matches(self, shortcut: &Shortcut, key: &Keystroke, priority: ShortcutPriority) -> bool {
        shortcut.priority == priority
            && self.gate(shortcut, key).is_none()
            && key.should_match(&gpui::KeybindingKeystroke::from_keystroke(keystroke(
                shortcut,
            )))
    }
}
impl View {
    fn bound_editor_action(
        &self,
        route: &Route,
        window: &Window,
        cx: &App,
    ) -> Option<(gpui::FocusHandle, NativeCommand)> {
        let CommandSource::Menu(menu) = route.source else {
            return None;
        };
        if !self.focus.borrow().interactive(menu)
            || !self.focus.borrow().allows(menu)
            || !self.command_route_available(route, window, cx)
        {
            return None;
        }
        let target = self.bound_editor_target(route, cx)?;
        let focus = self.editors.get(&target)?.focus_handle(cx);
        let action = self
            .session
            .borrow()
            .command_target(self.id, route.request())?;
        if !focus.is_focused(window) || action != route.config.target {
            return None;
        }
        let CommandTarget::Native(action) = action else {
            return None;
        };
        Some((focus, action))
    }
    fn bound_editor_target(&self, route: &Route, cx: &App) -> Option<NodeId> {
        let (target, focus) = route.editor_target.as_ref()?;
        let CommandSource::Menu(menu) = route.source else {
            return None;
        };
        let session = self.session.borrow();
        let owner = session.tree(self.id)?.get(menu)?;
        if owner.menu.as_ref()?.presentation != MenuPresentation::EditorContext
            || owner.children.as_ref() != [*target]
            || !self.focus.borrow().allows(*target)
            || !self.focus.borrow().visible(*target)
        {
            return None;
        }
        let editor = self.editors.get(target)?;
        (!editor.is_composing(cx) && editor.focus_handle(cx) == *focus).then_some(*target)
    }

    pub(super) fn command_route_available(&self, route: &Route, window: &Window, cx: &App) -> bool {
        if route.editor_target.is_none() {
            return self.command_available(&route.config, window, cx);
        }
        let Some(target) = self.bound_editor_target(route, cx) else {
            return false;
        };
        let CommandTarget::Native(action) = route.config.target else {
            return false;
        };
        route.config.enabled
            && self.editors[&target].command_available(action, cx)
            && (action != NativeCommand::Paste
                || cx
                    .read_from_clipboard()
                    .and_then(|item| item.text())
                    .is_some_and(|text| !text.is_empty()))
    }
    pub(super) fn install_command_interceptor(&mut self, window: &Window, cx: &mut Context<Self>) {
        if self.command_subscription.is_some() {
            return;
        }
        let target = window.window_handle();
        let owner = cx.weak_entity();
        self.command_subscription = Some(cx.intercept_keystrokes(move |event, window, cx| {
            if window.window_handle() != target {
                return;
            }
            let _ = owner.update(cx, |view, cx| {
                if event.keystroke.key == "escape"
                    && !event.keystroke.modifiers.modified()
                    && super::drag_drop::cancel(
                        view.id,
                        gpuio_protocol::drag_drop::CancelReason::Escape,
                        window,
                        cx,
                    )
                {
                    window.prevent_default();
                    cx.stop_propagation();
                    return;
                }
                if event.keystroke.key == "escape"
                    && !event.keystroke.modifiers.modified()
                    && view
                        .pointer_capture
                        .borrow_mut()
                        .cancel(PointerCancel::Escape, window)
                {
                    window.prevent_default();
                    cx.stop_propagation();
                    return;
                }
                // A scrollbar drag preserves the editor/table's focus. Its
                // bound Escape action runs before element key listeners, so
                // cancel capture here before that action can clear selection.
                if event.keystroke.key == "escape"
                    && !event.keystroke.modifiers.modified()
                    && view.cancel_scrollbar_drags(window, cx)
                {
                    window.prevent_default();
                    cx.stop_propagation();
                    return;
                }
                if !view.command_shortcut(&event.keystroke, ShortcutPriority::Override, window, cx)
                {
                    view.list_input_key(&event.keystroke, window, cx);
                }
            });
        }));
    }
    pub(super) fn command_editor(&self, window: &Window, cx: &App) -> Option<NodeId> {
        self.command_target_node(window, cx)
            .filter(|node| !self.tables.contains_key(node))
    }
    pub(super) fn command_target_node(&self, window: &Window, cx: &App) -> Option<NodeId> {
        self.editors
            .iter()
            .find(|(_, editor)| editor.focus_handle(cx).is_focused(window))
            .map(|(node, _)| *node)
            .or_else(|| {
                self.numbers
                    .iter()
                    .find(|(_, number)| number.focus_handle(cx).is_focused(window))
                    .map(|(node, _)| *node)
            })
            .or_else(|| {
                self.otps
                    .iter()
                    .find(|(_, otp)| otp.focus_handle(cx).is_focused(window))
                    .map(|(node, _)| *node)
            })
            .or_else(|| {
                self.color_inputs
                    .iter()
                    .find(|(_, color)| color.editing(window, cx))
                    .map(|(node, _)| *node)
            })
            .or_else(|| {
                self.tables
                    .iter()
                    .find(|(_, table)| table.borrow().owns_focus(window, cx))
                    .map(|(node, _)| *node)
            })
            .or_else(|| self.focus.borrow().last_command_target())
            .filter(|node| {
                (self.editors.contains_key(node)
                    || self.numbers.contains_key(node)
                    || self.otps.contains_key(node)
                    || self.color_inputs.contains_key(node)
                    || self.tables.contains_key(node))
                    && self.focus.borrow().allows(*node)
            })
    }
    pub(super) fn command_available(
        &self,
        config: &CommandConfig,
        window: &Window,
        cx: &App,
    ) -> bool {
        if !config.enabled {
            return false;
        }
        let CommandTarget::Native(action) = config.target else {
            return true;
        };
        let Some(editor) = self.command_target_node(window, cx) else {
            return false;
        };
        if let Some(table) = self.tables.get(&editor) {
            table.borrow().command_available(action, cx)
        } else if let Some(otp) = self.otps.get(&editor) {
            otp.command_available(action, cx)
        } else if let Some(number) = self.numbers.get(&editor) {
            number.command_available(action, cx)
        } else if let Some(color) = self.color_inputs.get(&editor) {
            color.command_available(action, window, cx)
        } else {
            self.editors[&editor].command_available(action, cx)
        }
    }

    pub(super) fn invoke_command(
        &mut self,
        route: &Route,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> bool {
        let source = match route.source {
            CommandSource::Button(node)
            | CommandSource::Palette(node)
            | CommandSource::Menu(node) => node,
            CommandSource::Shortcut => route.scope,
        };
        let allowed = match route.source {
            CommandSource::Menu(menu) => {
                if !self.focus.borrow().interactive(menu) {
                    return false;
                }
                let platform = self
                    .session
                    .borrow()
                    .tree(self.id)
                    .and_then(|tree| tree.get(menu))
                    .and_then(|node| node.menu.as_ref())
                    .is_some_and(|config| config.presentation == MenuPresentation::PlatformBar);
                if platform {
                    !self.focus.borrow().blocks_pointer(route.scope)
                } else {
                    self.focus.borrow().allows(source)
                }
            }
            CommandSource::Palette(_) => {
                // Modal selection closes before dispatch; embedded selection
                // keeps ordinary editor routing. Check current disability,
                // not a spent modal palette's rendering visibility.
                !self.focus.borrow().disabled(source)
                    && !self.focus.borrow().blocks_pointer(route.scope)
            }
            CommandSource::Button(_) => self.focus.borrow().allows(source),
            CommandSource::Shortcut => !self.focus.borrow().blocks_pointer(source),
        };
        if !allowed || !self.command_route_available(route, window, cx) {
            return false;
        }
        let target = self
            .session
            .borrow()
            .command_target(self.id, route.request());
        match target {
            Some(CommandTarget::Callback) => {
                let event = self
                    .session
                    .borrow()
                    .invoke_command(self.id, route.request());
                let Some(event) = event else {
                    return false;
                };
                if !self.transport.input(event) && self.session.borrow_mut().overload(self.id) {
                    self.transport.fault(self.id);
                }
                true
            }
            Some(CommandTarget::Native(action)) => {
                if route.editor_target.is_some() {
                    if self.bound_editor_action(route, window, cx).is_none() {
                        return false;
                    }
                    let owner = cx.weak_entity();
                    let route = route.clone();
                    window.defer(cx, move |window, cx| {
                        let resolved = owner
                            .update(cx, |view, cx| view.bound_editor_action(&route, window, cx))
                            .ok()
                            .flatten();
                        if let Some((focus, action)) = resolved {
                            // Revalidate after deferral, then dispatch to this exact focus
                            // node after releasing the host View borrow. No second queue.
                            focus.dispatch_action(native_action(action).as_ref(), window, cx);
                        }
                    });
                    return true;
                }
                let Some(editor) = self.command_target_node(window, cx) else {
                    return false;
                };
                if let Some(table) = self.tables.get(&editor) {
                    return table.borrow().invoke_copy(window, cx);
                }
                // Toolbar/button activation may have moved focus. Native edit
                // actions deliberately return it to the retained editing target.
                let focus = self
                    .numbers
                    .get(&editor)
                    .map(|number| number.focus_handle(cx))
                    .or_else(|| self.otps.get(&editor).map(|otp| otp.focus_handle(cx)))
                    .or_else(|| {
                        self.color_inputs
                            .get(&editor)
                            .and_then(|color| color.command_focus(window, cx))
                    })
                    .or_else(|| {
                        self.editors
                            .get(&editor)
                            .map(|editor| editor.focus_handle(cx))
                    });
                let Some(focus) = focus else {
                    return false;
                };
                window.focus(&focus, cx);
                window.dispatch_action(native_action(action), cx);
                true
            }
            None => false,
        }
    }
    /// Includes composite editors (numeric/OTP/color/palette), not just Input.
    pub(super) fn focused_input_composing(&self, window: &Window, cx: &App) -> bool {
        self.command_input_context(None, window, cx).composing
    }
    fn command_input_context(
        &self,
        focused_kind: Option<Kind>,
        window: &Window,
        cx: &App,
    ) -> InputContext {
        let editor = self
            .editors
            .values()
            .find(|editor| editor.focus_handle(cx).is_focused(window));
        let palette = self.palettes.values().find(|state| {
            !state.closed && state.query.read(cx).focus_handle(cx).is_focused(window)
        });
        let number = self
            .numbers
            .values()
            .find(|number| number.focus_handle(cx).is_focused(window));
        let otp = self
            .otps
            .values()
            .find(|otp| otp.focus_handle(cx).is_focused(window));
        let color = self
            .color_inputs
            .values()
            .find(|color| color.editing(window, cx));
        let composing = color.is_some_and(|color| color.is_composing(cx))
            || otp.is_some_and(|otp| otp.is_composing(cx))
            || number.is_some_and(|number| number.is_composing(cx))
            || editor.is_some_and(|editor| editor.is_composing(cx))
            || palette.is_some_and(|state| state.query.read(cx).bridge_composition().is_some());
        let editing = editor.is_some()
            || number.is_some()
            || palette.is_some()
            || otp.is_some()
            || color.is_some();
        InputContext {
            editing,
            composing,
            focused_kind,
        }
    }

    pub(super) fn command_shortcut(
        &mut self,
        key: &Keystroke,
        priority: ShortcutPriority,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> bool {
        let focused = self.focus.borrow().focused_node(window, cx);
        let focused_kind = focused.and_then(|id| {
            self.session
                .borrow()
                .tree(self.id)?
                .get(id)
                .map(|node| node.kind)
        });
        // Preserve the fast path: native navigation must not scan registries.
        if priority == ShortcutPriority::NativeFirst
            && InputContext::reserves_navigation(key, focused_kind)
        {
            return false;
        }
        let input = self.command_input_context(focused_kind, window, cx);
        let route = {
            let session = self.session.borrow();
            let Some(tree) = session.tree(self.id) else {
                return false;
            };
            focused.or(tree.root()).and_then(|start| {
                tree.commands_from(start)
                    .find(|(_, command)| {
                        command
                            .shortcuts
                            .iter()
                            .any(|shortcut| input.matches(shortcut, key, priority))
                    })
                    .map(|(scope, command)| {
                        Route::new(tree, scope, command, CommandSource::Shortcut)
                    })
            })
        };
        if let Some(route) = route
            && self.invoke_command(&route, window, cx)
        {
            cx.stop_propagation();
            true
        } else {
            false
        }
    }
}

#[path = "command_binding_view.rs"]
pub(super) mod binding;
