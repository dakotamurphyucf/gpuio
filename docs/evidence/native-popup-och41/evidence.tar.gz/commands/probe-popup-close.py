import sys, subprocess
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
from test_native_popup_macos import Mac, TITLE, open_keyboard
child=subprocess.Popen(['_build/default/examples/menus/main.exe','--platform-popup','--popup-close-test'])
mac=None
try:
 mac=Mac(child.pid,child)
 mac.wait_text(TITLE,'Total runs: 0')
 mac.set(mac.app,'AXFrontmost',mac.true)
 window=mac.window(TITLE);mac.perform(window,'AXRaise');mac.release(window)
 menu=open_keyboard(mac);mac.release(menu)
 print('POPUP_TRACKING_BEFORE_CLOSE_REQUEST',flush=True)
 assert child.wait(timeout=8)==0
 print('POPUP_CLOSED_DURING_TRACKING_OK',flush=True)
finally:
 if mac:mac.release(mac.app)
 if child.poll() is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:child.kill();child.wait()
