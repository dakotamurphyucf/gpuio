Base: 8cf5b5fe7ac7338b9275148eeab55fec4c18f99c. Local working changes are archived as source files.
macOS 14.5 arm64, M1 Max. Isolated toolchain; GPUIO_JOBS=2 for builds.

Final checks:
./scripts/gpuio exec cargo test -p gpuio-native --features native-image-tests,native-canvas-tests --lib --locked -j 2
./scripts/gpuio exec cargo clippy -p gpuio-native -p gpuio-protocol --all-targets --features native-image-tests,native-canvas-tests --locked -j 2 -- -D warnings
./scripts/gpuio exec dune build @fmt @runtest
./scripts/gpuio exec dune build examples/gallery/main.exe
Unchanged protocol after its full check:
./scripts/gpuio exec cargo test -p gpuio-protocol --locked -j 2
Native admission (before the private scheduler correction):
./scripts/gpuio exec cargo test -p gpuio-native --features native-image-tests --test menu_content --locked -j 2
All examples built before the private run-loop correction: ./scripts/gpuio exec dune build @runtest @all

Independent staging/build:
GPUIO_JOBS=2 python3 scripts/test_extension_consumer.py --example menus --workspace scratch/agents/root-20261004-resumed/native-popup-consumer
Physical (each local and with --binary scratch/agents/root-20261004-resumed/native-popup-consumer/consumer/_build/default/main.exe):
python3 scripts/test_native_popup_macos.py
python3 scripts/test_native_popup_macos.py --lifecycle close
python3 scripts/test_native_popup_macos.py --lifecycle retire
python3 scripts/test_native_popup_macos.py --lifecycle invalidate
python3 scripts/test_gallery.py --section native-popup

Five composed macOS graphs: cargo metadata --manifest-path <backend>/Cargo.toml --locked --offline --format-version 1 --filter-platform aarch64-apple-darwin
python3 scripts/audit_component_catalog.py (structural coverage, not feature acceptance)

Retained failures: native-popup-physical.log assumed an initial highlighted row; native-popup-close-probe.log demonstrates main-queue tracking starvation. Corrected logs are separately named. The initial system-menu-bar exploratory dump is excluded.
