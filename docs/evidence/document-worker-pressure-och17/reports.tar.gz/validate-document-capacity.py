import json, subprocess, time
from pathlib import Path
root = Path.cwd()
notes = root / "scratch/agents/root-20261007-access-check"
commands = [
 ("gallery", ["dune", "build", "-j2", "examples/gallery/main.exe"]),
 ("native", ["cargo", "test", "--offline", "--locked", "-j2", "-p", "gpuio-native", "--lib", "--features", "native-canvas-tests,native-image-tests"]),
 ("clippy", ["cargo", "clippy", "--offline", "--locked", "-j2", "--workspace", "--all-targets", "--features", "gpuio-native/native-tests,gpuio-native/native-canvas-tests,gpuio-native/native-image-tests,gpuio-native/presentation-diagnostics", "--", "-D", "warnings"]),
]
results=[]
for name, args in commands:
 started=time.time()
 with (notes / ("document-capacity-"+name+".log")).open("w") as output:
  result=subprocess.run(["./scripts/gpuio", "exec", *args],stdout=output,stderr=subprocess.STDOUT,env={**__import__("os").environ,"GPUIO_JOBS":"2"})
 results.append(dict(name=name,command=args,exit=result.returncode,seconds=time.time()-started))
 (notes / "document-capacity-validation.json").write_text(json.dumps(results,indent=2)+"\n")
 print(name,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
