import sys, subprocess, json, time
from pathlib import Path
sys.path.insert(0, str(Path("scripts").resolve()))
from mac_clipboard import preserved_clipboard
notes=Path("scratch/agents/root-20261007-access-check")
results=[]
for density in ["default", "large"]:
 args=[sys.executable,"scripts/test_macos_document_profile.py","--output", str(notes/("document-capacity-gui-"+density))]
 if density=="large": args.append("--large-density")
 with preserved_clipboard(), (notes/("document-capacity-gui-"+density+".log")).open("w") as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 results.append(dict(density=density,exit=result.returncode,clipboard_restored=True))
 (notes/"document-capacity-gui-results.json").write_text(json.dumps(results,indent=2)+"\n")
 print(density,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
