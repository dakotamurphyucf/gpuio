# Palette loading qualified locally — 2026-10-06 UTC
Base 50104a6 + current patch. OCH-41 open; goal active.
17874 terminal exit0: final installed Feedback real typing z during loading,
Finish loading, refocus and Cmd-Z restore query. Spinner pixel change76; full
Feedback/menu/notification sequence PASS. Driver reaped and clipboard restored.
38222 terminal exit0: ./scripts/gpuio build then check-fmt PASS (GPUIO_JOBS=2).
Final native74769 exit0 strictClippy then 968pass/2existingignored (image+canvas).
OCaml45310 full @runtest @fmt/gallery PASS; freshconsumer47525 PASS.
Binary SHA cd39e4f8731c517255f77968aa31095c1111e71f9209c275651b60792e8435c1.
Initial GUI81119 failed initialqueryfocus before loading, cause unestablished;
samebinary full runs11962 and17874 PASS; no application change between GUI runs.
Earlier native failures were fixture mistakes: already queued callbacks need
delivery before testing no renewal; child ID20 noncontiguous corrected2.
Initial .cma Dune target invalid native-only library, corrected .cmxa PASS.
No physical IME/VoiceOver or Linux GUI acceptance added. No live local handles.
Hosted37400903839 reverified live at2e9cd54: macBuild/LinuxOCamlRusttests.
Do not cancel by pushing normal PRbranch whilelive; reviewbranch push allowed.
Next archive exact patch/newdesign/logs/screens, update evidence/ledger/status,
commit, Linearcomment, then atomicquery-fencedresults/persistentembedding.
