Base 1760db5, macOS 14.5 arm64, M1 Max. GPUIO_JOBS=2.
./scripts/gpuio exec cargo test -p gpuio-native --features native-image-tests,native-canvas-tests --lib --locked -j 2
./scripts/gpuio exec cargo test -p gpuio-protocol --locked -j 2
./scripts/gpuio exec cargo clippy -p gpuio-native -p gpuio-protocol --features gpuio-native/native-image-tests,gpuio-native/native-canvas-tests --all-targets --locked -j 2 -- -D warnings
./scripts/gpuio exec dune build -j 2 @all @runtest @fmt
python3 scripts/test_extension_consumer.py --example gallery --workspace scratch/agents/root-20261004-resumed/palette-embedded-consumer
python3 scratch/agents/root-20261004-resumed/run_palette_embedded_gui.py
python3 scratch/agents/root-20261004-resumed/run_palette_embedded_installed_gui.py
./scripts/gpuio check-fmt
python3 -m py_compile scripts/test_gallery.py scripts/gallery_embedded_palette.py
git diff --check
Exact intermediate tests/failures are in work.md and logs. No expect output was promoted.
Private Rust focus follow-up: rebuild the existing consumer with OCAMLPATH=workspace/installed/lib and dune build --root workspace/consumer -j 2 main.exe @document_profile/test/runtest, then run --check-catalogs and the installed GUI wrapper. Installed OCaml libraries are unchanged.
Paired protocol full suite was run in the preceding implementation slice with identical wire source.
