from pathlib import Path
import os, signal, subprocess, sys
sys.path.insert(0, str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
base=Path('scratch/agents/root-20261004-resumed').resolve()
binary=Path('_build/default/examples/gallery/main.exe').resolve()
with preserved_clipboard(), (base/'palette-embedded-gallery-local.log').open('w') as log:
    child=subprocess.Popen([sys.executable,'scripts/test_gallery.py','--executable',str(binary),
        '--section','feedback','--images',str(base/'palette-embedded-images-local')],
        stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        code=child.wait(timeout=240)
        assert code==0,code
    finally:
        if child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try: child.wait(timeout=5)
            except subprocess.TimeoutExpired: os.killpg(child.pid,signal.SIGKILL);child.wait()
print('Local Feedback PASS; driver reaped; saved clipboard restored')
