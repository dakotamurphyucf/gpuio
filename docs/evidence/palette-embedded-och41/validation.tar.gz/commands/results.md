# OCH-41: embedded command palettes (WIP at 1760db5)

Goal turn classification: PROGRESS. No feature commit or acceptance claim yet.
External results are delivered at 1760db5; this work adds persistent presentation.
Read docs/design/palette-embedded.md for the draft public contract.

## Implementation
- Presentation.Modal (default) / Embedded, appended to paired palette options.
  Config.create/create_entries expose the option; default options remain elided.
- Embedded paints a normal-width Group in layout, with no deferred backdrop,
  automatic focus, trap, focus restoration or modal occluding hitbox.
- Native query, loading, grouped/rich rows, external results and controller reuse
  the existing implementation. Enter/click invoke repeatedly without closing or
  emitting Selected dismissal. Escape clears first when configured, then emits
  a cancellation request while retaining state. Child Escape keeps normal routing.
- Hidden/disabled states retain the query and refuse interaction. An inactive
  focus handle supports disabled paint when the shared focus scope is absent.
- Native edit actions use ordinary current/last document routing; the private
  query is never their document target. New TestPlatform test selects document
  text and preserves the query.
- Wheel capture/bubble compares each native list offset. Actual movement consumes
  the event; boundaries and horizontal input reach the ancestor scroller. Modal
  hitbox occlusion must be disabled for embedded mode or ancestors stay blocked.
- New Embedded_palette_preview.ml/mli uses only public APIs. Feedback includes
  its native note editor, persistent browser, count, cancel notification and hide.
  scripts/gallery_embedded_palette.py extends full Feedback with real keys,
  ordinary Tab, repeated actions, query retention and document selection/undo.

## Validation and retained failures
- 89677 all-target native/protocol check PASS.
- 99034 OCaml FAIL old custom-option fixture missing appended Modal byte;
  manually corrected independent bytes. 69079 corrected view API tests PASS.
- 62434 native FAIL hidden scope assumption + accessibility not enabled in test.
  Fixed visible guard/inactive handle and enabled AX in fixture; 34800 3 tests PASS.
- 80264 full native 974 PASS / 2 existing ignored, before extra tests/scroll work.
- 16108 expanded 4 native tests PASS including native document selection.
- 97552 gallery compile FAIL: B.toggle is an effect, not a function. Corrected.
- 33356 gallery + full @runtest PASS after that fix.
- 24584 full native 975 PASS / 2 ignored and full protocol 414 PASS.
- 87564 wheel test FAIL at boundary: parent offset remained zero. Removing modal
  occlusion fixed it; 29985 formatting + all 5 embedded tests PASS.
- 65103 first fmt exited 1 after format-only promotions. No expect output promoted.
- 33422 FINAL native 976 PASS / 2 existing ignored; strict all-target Clippy PASS.
- 31323 FINAL PASS: gallery, full @runtest, @fmt; no root Dune live.
- No GUI run for this slice yet. run_palette_embedded_gui.py is ready; it restores
  clipboard and reaps the full Feedback driver/application, with a 240s bound.

Logs: palette-embedded-*.log in this notepad directory. Tests use GPUIO_JOBS=2 and
./scripts/gpuio exec cargo test -p gpuio-native --features native-image-tests,native-canvas-tests --lib --locked -j 2
./scripts/gpuio exec cargo test -p gpuio-protocol --locked -j 2
./scripts/gpuio exec dune build -j 2 examples/gallery/main.exe @runtest @fmt

## Next concrete work
1. Poll 31323. Run local full Feedback; inspect inline screenshot and fix failures.
2. Review live Embedded->Modal transition: State.editor currently keeps original
   mount capture, so recapture the current/last document when becoming modal.
   Shared focus scope restoration may need to capture an outside focus target on
   trap transition. Add a targeted native mode-change edit/focus test before
   qualifying the draft's live presentation-change contract.
3. Final checks, fresh independent consumer and actual installed Feedback; archive
   source/logs/failures/screens, update catalog/status/Linear, commit and publish.
4. Then OS popup menus, chart gaps, complete catalog and macOS release gates.

CI37400903839 is on old2e9cd54, not this work. Latest poll: Linux success, macOS
native disclosure/navigation failure but job still running later checks. Retrieve
failure logs once terminal; don't cancel it by pushing the normal PR16 branch.
Review remote milestone-07-motion-review remains1760db5. Initial modal focus
intermittency from the prior slice remains unexplained and is not claimed fixed.

## Continuation 2026-10-06
Previous explanatory user turn: no goal progress; resumed implementation now.
Local GUI4925 failed in NEW embedded test after Steps2/Tab succeeded: Python
modifier flags incorrectly supplied as lists. Corrected Shift/Command integer
flags matching existing harness; application behavior was not the failure.
Log renamed palette-embedded-gallery-local-failed-flags.log before retry.
CI37400903839 still live, Linux success, macOS disclosure/navigation failure.

Transition follow-up: seven focused tests PASS (93901); full native final48458
has 978 PASS / 2 existing ignored, strict Clippy next in same session. Root
Dune78395 all examples/@runtest/@fmt live. No GUI.
Reproduced initial State.editor=None on Embedded->Modal; capture ordinary editor
before old gate becomes modal. Reproduced Escape restoring stale mount focus;
shared scope now captures current outside focus when changing to trap, retaining
prior target if focus already belongs to its query. Tests cover native SelectAll,
Escape, query identity and repeated presentation changes with inside focus.
Interim fixture failures: post-paint focus callback must simulate_next_frame,
not only draw; one read_with mutation compile error corrected to update.
Local full Feedback failure4925 was integer modifier misuse (corrected); rerun
86279 failed old Preview commands autofocus before new checks. Kept both logs.
Root Dune/@fmt31323 and strict Clippy33422 from preceding turn were PASS.

Full native978 PASS/2ignored + strict all-target Clippy48458 PASS. Root Dune78395
still building @all (presentation/resource-audit backend subprocesses verified).
CI37400903839 terminal FAILURE. Linux success; native navigation bounds width500
vs requested400 at navigation_lifecycle_test.rs:421 after actual viewport wait;
Metal hook/calibration failed; receiver skipped. OCH17 comment
f1cf8d7e-9a95-46c0-9584-8b62341da259 records exact status. Fullfailedlog retained;
macOS artifact ZIP download live for raw presentation evidence. No gate waived.

## Modal autofocus callback race follow-up
Installed GUI12856 failed same Preview commands focus assertion before embedded
checks, despite successful independent build85835. Retained failed log/image.
Current native ordering: GPUI executes queued next-frame callbacks before drawing
new dirty content (vendor/gpui/src/window.rs). A previous focus.finish_frame can
consume a newly admitted enter request against old recorded entries. Exact-boundary
regression43093 FAILED after creating a fresh modal, updating native state, then
calling the earlier reconciliation before any new paint. Earlier harness variants
that let the event loop run between operations passed and did not pin that boundary.
Fix: enter_needs_paint boolean set on new scope entry, cleared by begin_frame;
finish_frame retains pending entry until paint. No new polling or forced redraw.
32647 all eight focused tests PASS. 34346 formatting live, then full native/lint
and independent consumer refresh required. No final feature commit yet.
OCH48 created per owner: adjacent detailed Markdown walkthrough for every example
component; milestone07 Backlog, separate notepad OCH-48.md. Status page records it.

## Final local qualification
90950 full native979 PASS / 2 existing ignored and strict all-target Clippy PASS.
63580 installed composed backend rebuilt with final focus correction; catalogs PASS.
95694 complete installed Feedback PASS; app/driver reaped, saved clipboard restored.
Installed binary SHA fc1217ab05f886c3fcb81a632c6542d8cf3e809a9b4082be908a751545fbad77.
No focus assertion weakened/forced-focus substituted. Deterministic ordering race
reproduced/fixed; old historical failures lack tracing, so do not claim all causes.
Prior all-example/fullOCaml/fmt78395 PASS; final change is private Rust focus only.
Protocol414 unchanged source PASS from earlier slice. Finalfmt34346 PASS.
Current docs/design/evidence/catalog/status updated; archive/commit/publication next.
No local process remains live. CI37400903839 terminalfail recorded/archived.
