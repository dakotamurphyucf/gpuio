OCH-17 / OCH-41 pending local update — not published (session write-approval restriction remains).

Logical accessibility publication now merges unrealized prepared semantic blocks into the existing Document, keeping actual visible native control subtrees/actions. Offscreen headings/lists/tables/links, scalar/CRLF runs, block boundary separators, empty caret and atomic alternatives have real tree nodes with no invented geometry. Atomic alternative interiors remain invalid native selection positions. max_lines previews do not expand to the full document.

Tests cover complete ordered text over 200 paragraphs, prepared-position roundtrips, no fabricated offscreen bounds, refresh/replacement/window isolation, actual control identity/action preservation, nested list/table/link spans, Unicode/CRLF atomic alternatives/FFFC, and empty/clamped cases. An old pointer test was updated to determine native realization from actual attachments and bounds rather than AX text existence; pointer direction/selection requirements remain.

Local stock-toolchain macOS results: cargo native suite 1,140 passed / 2 existing ignored; strict workspace clippy and rustfmt pass. Base patch c77049e5267b21408001d84f16c673df408ab6767ff4c1d04cdd348a2fcbcd66 reconstructs all 243 files exactly. Broader workspace test handle18343 is running; do not report its completion yet.

Not complete: text gaps inside realized nested structures, large-tree publication cost, visual-line adjacency, final-paint selection and guarded native reveal/activation/OS selection. No actual desktop/VoiceOver claim; no current-source Linux or clean-machine/release claim. Changes remain local/uncommitted; both tickets stay In Progress.
