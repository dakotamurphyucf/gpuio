import hashlib,json,os,subprocess,time
from pathlib import Path
base=Path(__file__).resolve().parent
report={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_dirty':True,'commands':[],'source_hashes':{}}
for name in ('scripts/qualify_metal_presentation.swift','scripts/test_metal_presentation.py','scripts/metal_timing_availability.py','rust/native/tests/native_metal_presentation.rs'):
 report['source_hashes'][name]=hashlib.sha256(Path(name).read_bytes()).hexdigest()
commands=[
 ('swift-build',['xcrun','swiftc','-O','-module-cache-path',str(base/'swift-modules'),'scripts/qualify_metal_presentation.swift','-o',str(base/'api-probe')]),
 ('api',['python3','scripts/metal_timing_availability.py','--api-binary',str(base/'api-probe'),'--output',str(base/'api')]),
 ('hook',['python3','scripts/test_metal_presentation.py','--allow-unavailable-timing','--output',str(base/'hook')]),
 ('pair',['python3','scripts/metal_timing_availability.py','--hook-output',str(base/'hook'),'--api-output',str(base/'api'),'--output',str(base/'pair')])]
for name,command in commands:
 print('START',name,flush=True)
 started=time.monotonic()
 with (base/f'{name}.log').open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'GPUIO_JOBS':'2'})
 report['commands'].append({'name':name,'command':command,'exit':result.returncode,'elapsed_seconds':time.monotonic()-started})
 (base/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
 print('FINISH',name,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
report['complete']=True
report['binary_sha256']=hashlib.sha256((base/'api-probe').read_bytes()).hexdigest()
(base/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
