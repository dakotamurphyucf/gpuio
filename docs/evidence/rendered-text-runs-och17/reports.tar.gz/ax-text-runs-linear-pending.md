OCH-17 progress update — NOT published (approval required, policy never)

Local uncommitted checkpoint after b02b6079: actual native TextRuns now sit beneath the existing labels and link proxies, with cached shaped geometry and preserved hard line breaks. Run IDs include exact prepared fragment endpoints. Bidirectional native/logical position lookup rejects stale preparations, other windows and invalid characters. Bindings are filtered against actual completed Document descendants, excluding measurement-only and unrelated nodes. Native control IDs/actions remain stable.

Current binding implementation: 1,137 native library tests pass, 2 existing ignored; strict all-target Clippy, Rust formatting and diff check pass. Full Rust workspace and Dune @all/@runtest/@fmt passed the PRECEDING leaf-publication stage; preserved source hashes/archive distinguish it from the subsequent binding addition. No current-binding broad Dune claim.

Cached pinned archive reconstruction matches exactly: GPUI157files patch37301e87dff2eaa4ff0ccdfccc23c17a27d8f1521feb6c75d613f120386014b8; Base242files patch279bdd638e160133d69092feb2cc0322954b309bb40c06e70bf695f2a57dd81a, excludingCargo.lock. An old scratch helper omitted an existing Cargo feature; the mismatch was caught and regeneration now preserves prior manifest patches. Fresh download blockedDNS; cached upstream hashes verified.

Actual macOS desktop editor/document attempt timed out300sec after HIServices/LaunchServices errors under the restricted sandbox; owned process group killed/reaped and clipboard preservation unwound. NO GUI acceptance. No local processes remain running.

Versioned evidence: docs/evidence/rendered-text-runs-och17.md and verified adjacent reports/manifest. Design/status updated. Full Document separators/atomic/offscreen text, visual-line adjacency, final-paint selection and guarded OS actions, physical VoiceOver and full release gates remain required. Last-prepaint mapping is not action/visibility authorization. OCH17/OCH41 remain open; OCH48 docs remains Done429sources/266groups/0pending.

The current session has read-only .git and cannot commit/push. Linear save_comment was rejected because the connector requires approval and the session policy is never. Do not try alternate connectors to bypass that restriction. Publish only when the permitted connection is restored, updating revision links and any subsequent changes accurately.
