from pathlib import Path
import contextlib,json,os,signal,subprocess,sys,time
notes=Path('scratch/agents/root-20261004-resumed')
sys.path.insert(0,str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
base=['./scripts/gpuio','exec']; env=dict(os.environ,GPUIO_JOBS='2',RUST_BACKTRACE='1')
checks=[
 ('desktop-006',base+['cargo','test','--offline','--locked','-j2','-p','gpuio-native','--features','native-tests','--test','native_editor','--test','native_document'],300,True),
 ('workspace-007',base+['cargo','test','--offline','--workspace','--locked','-j2'],900,False),
 ('clippy-008',base+['cargo','clippy','--offline','--workspace','--all-targets','--locked','-j2','--features','gpuio-native/native-canvas-tests,gpuio-native/native-image-tests,gpuio-native/presentation-diagnostics','--','-D','warnings'],600,False),
 ('dune-009',base+['dune','build','-j2','@all','@runtest','@fmt'],1800,False),
]
results=[]
for name,command,timeout,clipboard in checks:
 path=notes/('ax-coordinates-'+name+'.log');start=time.monotonic();print('START',name,flush=True)
 with (preserved_clipboard() if clipboard else contextlib.nullcontext()),path.open('w') as log:
  child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:status=child.wait(timeout=timeout)
  except BaseException:
   os.killpg(child.pid,signal.SIGKILL);child.wait();raise
 result=dict(name=name,command=command,exit=status,seconds=time.monotonic()-start,log=str(path))
 results.append(result);(notes/'ax-coordinates-final-checks.json').write_text(json.dumps(results,indent=2)+'\n');print('END',name,status,flush=True)
 if status:raise SystemExit(status)
