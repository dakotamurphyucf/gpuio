import hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path.cwd();out=root/'scratch/agents/root-20261007-access-check/preview-source'
rev='b90fb769';sha=subprocess.check_output(['git','rev-parse',rev]).decode().strip()
expected={}
for row in subprocess.check_output(['git','ls-tree','-rz',rev]).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob',(name,kind)
 expected[name.decode()]={'mode':mode,'blob':oid}
seen=set();licenses=[];binary=[];total=0
path=out/'gpuio-b90fb769.tar.gz'
with tarfile.open(path,mode='r|gz') as t:
 for m in t:
  if m.isdir():continue
  assert m.isfile(),m.name
  assert m.name.startswith('gpuio-preview/');name=m.name[len('gpuio-preview/'):]
  assert name in expected and name not in seen,name;seen.add(name)
  h=hashlib.sha1(('blob '+str(m.size)+'\0').encode());f=t.extractfile(m);prefix=f.read(16);h.update(prefix)
  while chunk:=f.read(1024*1024):h.update(chunk)
  assert h.hexdigest()==expected[name]['blob'],name
  assert bool(m.mode&0o111)==(expected[name]['mode']=='100755'),name
  if prefix.startswith((b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xce\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe',b'!<arch>\n',b'MZ')):binary.append(name)
  if any(x in name.lower() for x in ['license','copying','notice']):licenses.append(name)
  total+=m.size
assert seen==expected.keys()
required=['LICENSE','THIRD_PARTY.md','third_party/ASSET_NOTICES.md','third_party/licenses/fira-code.txt','docs/developer-preview.md','docs/getting-started.md','third_party/sources.json','third_party/notice-sources.json','third_party/rust-notice-gaps.json']
assert all(p in seen for p in required)
assert not any(any(x in p.split('/') for x in ['scratch','_build','.opam-root','target','.git']) for p in seen)
with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
r={'revision':sha,'artifact':path.name,'sha256':digest,'bytes':path.stat().st_size,'tracked_files':len(seen),'uncompressed_bytes':total,'git_blob_and_mode_matches':len(seen),'binary_signatures':binary,'required_notice_and_guide_paths':required,'notice_related_paths':licenses,'excluded_local_artifacts':True,'published':False}
(out/'assembled-source.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['notice_related_paths','required_notice_and_guide_paths']},indent=2))
