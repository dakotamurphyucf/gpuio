import collections,gzip,hashlib,io,json,pathlib,subprocess,tarfile,zipfile
root=pathlib.Path.cwd(); out=root/'scratch/agents/root-20261007-access-check/preview-source'
paths=[pathlib.Path(p) for p in subprocess.check_output(['git','ls-files','-z']).decode().split('\0') if p]
counts=collections.Counter(); archives=[]; suspicious=[]; hashes=[]; file_rows=[]
magic={b'\x7fELF':'ELF',b'\xcf\xfa\xed\xfe':'Mach-O',b'\xce\xfa\xed\xfe':'Mach-O',b'\xfe\xed\xfa\xcf':'Mach-O',b'\xca\xfe\xba\xbe':'fat Mach-O/Java',b'!<arch>\n':'ar',b'MZ':'PE'}
def check(name, prefix, size):
    counts['files']+=1;counts['uncompressed_bytes']+=size
    file_rows.append({'path':name,'size':size})
    kind=next((v for k,v in magic.items() if prefix.startswith(k)),None)
    if kind or pathlib.Path(name).suffix.lower() in {'.exe','.so','.dylib','.a','.o','.dll','.ttf','.otf','.woff','.woff2','.zip','.tgz','.xz','.gz'}:
        suspicious.append({'path':name,'size':size,'kind':kind})
def tar_scan(f,label,depth=0):
    if depth>4: raise RuntimeError('nesting')
    with tarfile.open(fileobj=f,mode='r|*') as t:
        n=0
        for m in t:
            if m.isfile():
                n+=1
                stream=t.extractfile(m)
                prefix=stream.read(16)
                name=label+'!'+m.name
                check(name,prefix,m.size)
                if m.name.endswith(('.tar.gz','.tgz','.tar','.zip')):
                    if m.size>100_000_000: raise RuntimeError('oversize nested archive '+name)
                    payload=io.BytesIO(prefix+stream.read())
                    if m.name.endswith('.zip'):
                        with zipfile.ZipFile(payload) as z:
                            for zi in z.infolist():
                                if not zi.is_dir():
                                    with z.open(zi) as s: check(name+'!'+zi.filename,s.read(16),zi.file_size)
                    else:tar_scan(payload,name,depth+1)
            elif not m.isdir(): suspicious.append({'path':label+'!'+m.name,'type':repr(m.type),'target':m.linkname})
        archives.append({'path':label,'regular_files':n})
for p in paths:
    if p.is_symlink():
        suspicious.append({'path':str(p),'type':'symlink','target':str(p.readlink())});continue
    with p.open('rb') as f: prefix=f.read(16)
    check(str(p),prefix,p.stat().st_size)
    if p.name.endswith('.tar.gz'):
        with p.open('rb') as f:tar_scan(f,str(p))
        hashes.append({'path':str(p),'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()})
    elif p.suffix=='.gz':
        with gzip.open(p,'rb') as f:check(str(p)+'!decompressed',f.read(16),0)
result={'revision':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'counts':dict(counts),'archives':archives,'suspicious':suspicious,'archive_hashes':hashes,'files':file_rows}
(out/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':dict(counts),'archives':len(archives),'findings':len(suspicious),'binary_findings':[x for x in suspicious if x.get('kind')],'nested_archives':[x for x in archives if '!' in x['path']]},indent=2))
