import sys,time
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import test_agent_chat_results as r
class Finished(Exception):pass
def click(self,point,right=False):
    print('HELD_CLICK_BEFORE',point.x,point.y,flush=True)
    self.send(5,point)
    self.send(1,point)
    try:
        time.sleep(.3)
        after=self.cell('000001')
        print('HELD_CLICK_AFTER_DOWN',after.x,after.y,flush=True)
        assert abs(after.x-point.x)<.01 and abs(after.y-point.y)<.01
        r.screenshot(self,Path('scratch/agents/root-20261004-resumed/view-reentrancy-held-down.png'),title=r.TITLE)
    finally:self.send(2,point)
    self.wait_text(r.TITLE,'Selected result 000001 · number')
    after=self.cell('000001')
    print('HELD_CLICK_AFTER_UP',after.x,after.y,flush=True)
    assert abs(after.x-point.x)<.01 and abs(after.y-point.y)<.01
    raise Finished()
r.Results.click=click
try:r.main()
except Finished:print('GPUIO_RESULTS_HELD_CLICK_OK: stable down/up geometry and original row selection; diagnostic child reaped')
