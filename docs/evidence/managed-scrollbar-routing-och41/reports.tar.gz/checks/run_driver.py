import runpy
import signal
import sys

sys.path.insert(0, 'scripts')

def stop(*_):
    raise RuntimeError('managed scrollbar test exceeded 360-second watchdog')

signal.signal(signal.SIGALRM, stop)
signal.alarm(360)
sys.argv = ['scripts/test_gallery.py', '--section', 'managed-scrollbars', *sys.argv[1:]]
runpy.run_path('scripts/test_gallery.py', run_name='__main__')
