open Core
module B = Bonsai.Cont
module Row = Gpuio.Table_data.Row_ref
module Config = Gpuio.Table.Config
module Selection = Gpuio.Table.Selection
module Request = Gpuio.Table.Request
module Target = Gpuio.Table.Target

module Cell : sig
  (** The retained [copy_text] is also the native cell's accessibility value.
      Provide a readable textual equivalent for custom visual content. Native
      controls inside the cell retain their own accessibility semantics. *)
  type t

  (** Copy text and the child View are independent. Column identity must match
      the column passed to [render_cell]. Copy text uses the Core cell bounds. *)
  val create
    :  column:Gpuio.Table_column.Id.t
    -> copy_text:string
    -> unit Bonsai.Effect.t Gpuio.View.t
    -> t Or_error.t

  (** Compact plain-text cell: display, clipboard and accessibility text are
      identical. Uses one retained native leaf; [create] keeps arbitrary rich
      content and its ordinary View resource/transaction costs. *)
  val text : column:Gpuio.Table_column.Id.t -> string -> t Or_error.t
end

module Controller : sig
  (** One mounted source and query, without a payload-bearing source snapshot.
      Retired mounts/queries and absent/reincarnated targets ignore delayed work. *)
  type t

  (** An explicit batch of at most 64 commands. A newer batch supersedes one
      that has not yet been displayed. Put selection and reveal in one batch
      when both must execute. A newer native selection supersedes a pending batch.
      Invalid current targets discard the whole batch;
      malformed offsets and oversized batches return Error at construction. *)
  val batch : t -> Row.t Target.t list -> unit Bonsai.Effect.t Or_error.t

  val select : t -> Row.t Selection.t -> unit Bonsai.Effect.t
  val reveal : t -> ?column:Gpuio.Table_column.Id.t -> Row.t -> unit Bonsai.Effect.t

  (** Prepare a bounded destination row set together with the command, using
      the latest compatible viewport when available. Pins retain priority and
      native layout remains authoritative. This avoids a separate cell round
      trip for ordinary jumps; unknown/resized geometry or an insufficient row
      budget can still require further native demand. *)
  val scroll_to : t -> ?offset:float -> Row.t -> unit Bonsai.Effect.t Or_error.t

  val scroll_to_column : t -> Gpuio.Table_column.Id.t -> unit Bonsai.Effect.t
  val scroll_to_end : t -> unit Bonsai.Effect.t
  val reset_columns : t -> unit Bonsai.Effect.t
end

module Output : sig
  type 'data t

  val view : _ t -> unit Bonsai.Effect.t Gpuio.View.t
  val controller : _ t -> Controller.t
  val selection : _ t -> Row.t Selection.t
  val target : _ t -> Gpuio.Table_data.Id.t -> Row.t Or_error.t

  (** Latest native observation for the current query, order and configuration.
      Changes can temporarily return [None] until a matching observation arrives.
      A rendered-frame acknowledgement does not guarantee that observation has
      already been delivered to Bonsai. *)
  val viewport : _ t -> Gpuio.Virtual_list.Viewport.t option

  (** Latest horizontal column bands for the current source/query/configuration.
      Includes pinned and partially visible columns, even with no data rows.
      [None] means not yet observed, distinct from a measured empty viewport.
      Like [viewport], this is an asynchronous layout snapshot, not OS occlusion
      or a guarantee of visibility after a window/subtree stops drawing. *)
  val column_viewport : _ t -> Gpuio.Table.Column_viewport.t option

  val active_rows : _ t -> int
  val active_cells : _ t -> int
  val budget_exhausted : _ t -> bool
end

(** A bounded read-only native table. The application owns [source], accepted
    columns/sort in [config], and data loading. Native selection is optimistic;
    observe [Output.selection] or issue an explicit controller command. Removed
    rows/columns and disallowed modes repair selection to Empty. Sort, resize,
    reorder, activation, context and copy proposals reach [on_request]; apply
    accepted column/query changes in application state. This component never
    sorts a partial remote dataset or synchronously calls OCaml from Rust.

    A fresh Table_data lineage resets the entire widget. Increasing
    [query_generation] retires old effects and transient cell models while keeping
    the native table and surviving row anchors/selection. Source/query changes
    do not cancel application I/O; reset the Eio pager to cancel its producers.
    Generations must be nonnegative and cannot decrease within a native mount.

    Requested/pinned rows and bounded programmatic scroll preparation allocate
    cells. All columns of each active row
    count against [config]'s cell limit. Cells use Managed_rows' default-reset
    lifecycle contract and receive their own lifetime guard. Preferences and
    application jobs belong outside transient cell computations. Source-order
    metadata is O(logical rows); point updates share it without rebuilding keys.
    Give the table bounded geometry through [style] or its parent. The caller's
    key and style belong to the native table root: padding, border and surface
    decoration are applied once. Style updates preserve selection and anchors;
    source-lineage resets remain independent of the caller's sibling key.

    [headers] submits keyed rich leaf/group Views through [Gpuio.Table_header].
    Their computations belong to the caller and are independent of body-row
    eviction and cell lifetimes. Native controls retain their keyed owners until
    removed or the table mount is replaced. Header content consumes normal View
    resources but does not consume the active body-cell budget.

    [header_presentation] styles native header bands through a checked paint and
    typography scope. [render_row_presentation] runs once per active row in that
    row's managed lifetime, independently of columns. Eviction tears it down;
    durable application work belongs outside it. Presentation updates retain
    native geometry, scroll owners and cell computations. Native interaction
    states are resolved locally without callbacks into OCaml.

    [scrollbar] configures the actual native viewport, inside any layout
    wrappers. It defaults to [B.return None], which retains legacy native
    presentation. Changing it preserves the viewport and mounted row state;
    [config]'s scrollbar enable flag still takes precedence. *)
val component
  :  'data Gpuio.Table_data.t B.t
  -> config:Config.t B.t
  -> ?key:Gpuio.Key.t
  -> ?style:Gpuio.Style.t B.t
  -> ?scrollbar:Gpuio.Scrollbar.t option B.t
  -> ?headers:unit Bonsai.Effect.t Gpuio.View.t Gpuio.Table_header.t list B.t
  -> ?header_presentation:Gpuio.Table_presentation.Header.t B.t
  -> ?render_row_presentation:
       (row:Row.t B.t
        -> data:'data B.t
        -> lifetime:Managed_rows.Lifetime.t B.t
        -> B.graph
        -> Gpuio.Table_presentation.Row.t Or_error.t B.t)
  -> ?query_generation:int64 B.t
  -> ?on_request:(Row.t Request.t -> unit Bonsai.Effect.t) B.t
  -> render_cell:
       (row:Row.t B.t
        -> data:'data B.t
        -> column:Gpuio.Table_column.t B.t
        -> lifetime:Managed_rows.Lifetime.t B.t
        -> B.graph
        -> Cell.t Or_error.t B.t)
  -> B.graph
  -> 'data Output.t Or_error.t B.t

module Paging = Virtual_list.Paging

(** Requests Ready boundaries after native layout, including empty/short sources.
    Failed boundaries require [Paging.retry]. Leaving the viewport does not cancel
    application loads. [auto_load=false] suspends new automatic requests. Controls
    must recheck generation at execution; Gpuio_eio.Table_paging.controls does so. *)
val paged
  :  ('query, 'data) Gpuio.Table_paging.Snapshot.t B.t
  -> paging:Paging.t B.t
  -> config:Config.t B.t
  -> ?key:Gpuio.Key.t
  -> ?style:Gpuio.Style.t B.t
  -> ?scrollbar:Gpuio.Scrollbar.t option B.t
  -> ?headers:unit Bonsai.Effect.t Gpuio.View.t Gpuio.Table_header.t list B.t
  -> ?header_presentation:Gpuio.Table_presentation.Header.t B.t
  -> ?render_row_presentation:
       (row:Row.t B.t
        -> data:'data B.t
        -> lifetime:Managed_rows.Lifetime.t B.t
        -> B.graph
        -> Gpuio.Table_presentation.Row.t Or_error.t B.t)
  -> ?auto_load:bool B.t
  -> ?on_request:(Row.t Request.t -> unit Bonsai.Effect.t) B.t
  -> render_cell:
       (row:Row.t B.t
        -> data:'data B.t
        -> column:Gpuio.Table_column.t B.t
        -> lifetime:Managed_rows.Lifetime.t B.t
        -> B.graph
        -> Cell.t Or_error.t B.t)
  -> B.graph
  -> 'data Output.t Or_error.t B.t
