open Core
module P = Gpuio_protocol
module W = P.Wire
let ok = Or_error.ok_exn
let () = Eio_main.run (fun env ->
  let clock = Eio.Stdenv.mono_clock env in
  let elapsed f =
    let start = Eio.Time.Mono.now clock in
    f ();
    Mtime.span start (Eio.Time.Mono.now clock) |> Mtime.Span.to_float_ns
  in
  let window = P.Window_id.create ~slot:0L ~generation:1L |> ok in
  let node i = P.Node_id.create ~slot:(Int64.of_int i) ~generation:1L |> ok in
  let cases = [ "label8", 1, 8, 10000; "labels100", 100, 64, 1000;
                "labels1000", 1000, 64, 100; "text256k", 1, 262144, 100 ] in
  List.iter cases ~f:(fun (name, count, length, loops) ->
    let text = String.make length 'x' in
    let operations = List.init count ~f:(fun i -> W.Op.Set_text (node i, text)) in
    let message = W.Message.Apply {window; base=1L; revision=2L; operations} in
    let encode () = W.Message.encode message |> ok |> Stdlib.Sys.opaque_identity in
    let bytes = encode () in
    Eio.Path.save ~create:(`Or_truncate 0o600) Eio.Path.(Eio.Stdenv.fs env / (name ^ ".bin")) bytes;
    for _ = 1 to 100 do ignore (encode () : string) done;
    let samples = List.init 11 ~f:(fun _ ->
      let ns = elapsed (fun () -> for _ = 1 to loops do ignore (encode () : string) done) in
      ns /. Float.of_int loops /. 1000.) |> List.sort ~compare:Float.compare in
    Eio.Flow.copy_string
      (sprintf "ENCODE name=%s bytes=%d loops=%d batches=11 median_us=%.3f min_us=%.3f max_us=%.3f\n"
        name (String.length bytes) loops (List.nth_exn samples 5) (List.hd_exn samples) (List.last_exn samples))
      (Eio.Stdenv.stdout env)))
