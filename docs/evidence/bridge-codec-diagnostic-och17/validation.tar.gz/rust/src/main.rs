use std::{hint::black_box, time::Instant};
fn main() {
    for (name, loops) in [("label8", 10000), ("labels100", 1000), ("labels1000", 100), ("text256k", 100)] {
        let bytes = std::fs::read(format!("{name}.bin")).unwrap();
        for _ in 0..100 { black_box(gpuio_protocol::decode(black_box(&bytes)).unwrap()); }
        let mut samples = Vec::new();
        for _ in 0..11 {
            let start = Instant::now();
            for _ in 0..loops { black_box(gpuio_protocol::decode(black_box(&bytes)).unwrap()); }
            samples.push(start.elapsed().as_secs_f64() * 1e6 / loops as f64);
        }
        samples.sort_by(f64::total_cmp);
        println!("DECODE name={name} bytes={} loops={loops} batches=11 median_us={:.3} min_us={:.3} max_us={:.3}", bytes.len(), samples[5], samples[0], samples[10]);
    }
}
