import hashlib, json, os, subprocess
from pathlib import Path
base = Path(__file__).resolve().parent
assert not subprocess.check_output(['git', 'status', '--porcelain']).strip()
build = json.loads((base / 'collector-overhead-build.json').read_text())
assert build['exit'] == 0 and build['feature_verification']
variants = {
 'A': ('_build/default/examples/performance_plain/main.exe', ['--wall-clock']),
 'B': ('_build/default/examples/performance_presented/list/main.exe', ['--presentation']),
}
report = dict(revision=subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
 plan='Prior unassisted batch stopped at inactive B warmup frame timeout. This distinct batch applies the same one-time foreground preflight to BOTH variants, completes it before history begins, never reactivates mid-run, and retains all prior failures. One smoke warmup per variant, then fixed A1/B1/B2/A2/A3/B3. A=ordinary backend wall-clock; B=active CPU+presentation diagnostics. Same 10k rows/full traversal/growth/60s idle/cleanup. Stop on any failed trial; preserve all attempts. No post-hoc thresholds. Total instrumentation comparison, not pure presentation callback overhead.',
 build=build, trials=[], running=None)
order = [('A-warmup', 'A', True), ('B-warmup', 'B', True),
         ('A1','A',False), ('B1','B',False), ('B2','B',False),
         ('A2','A',False), ('A3','A',False), ('B3','B',False)]
env = dict(os.environ)
env.pop('GPUIO_TRACE_METAL_STARTUP', None)
awake = subprocess.Popen(['/usr/bin/caffeinate','-di','-w',str(os.getpid())])
def save():
 (base / 'collector-overhead-foreground-batch.json').write_text(json.dumps(report, indent=2)+'\n')
try:
 for name, variant, smoke in order:
  binary, flags = variants[variant]
  assert hashlib.sha256(Path(binary).read_bytes()).hexdigest() == build['binaries'][variant]['sha256']
  output = base / f'collector-overhead-foreground-{name}'
  cmd = ['python3',str(base / 'measure-list-foreground.py'),'--build-profile','release',
         '--executable',binary,'--timeout','900','--output',str(output)] + flags
  if smoke: cmd.append('--smoke')
  elif variant == 'B': cmd.append('--check-budgets')
  report['running'] = name
  save()
  print('START', name, flush=True)
  with (base / f'collector-overhead-foreground-{name}.log').open('w') as log:
   result = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
  raw = json.loads((output / 'report.json').read_text())
  trial = dict(name=name, variant=variant, smoke=smoke, command=cmd, driver_exit=result.returncode,
               child_exit=raw.get('returncode'), complete=raw['complete'], error=raw.get('error'))
  report['trials'].append(trial)
  report['running'] = None
  save()
  print('FINISH',trial,flush=True)
  if result.returncode or not raw['complete']:
   raise RuntimeError('Stopping planned comparison after failed trial; retain incomplete evidence')
finally:
 awake.terminate()
 awake.wait(timeout=5)
 report['keep_awake_reaped'] = True
 save()
