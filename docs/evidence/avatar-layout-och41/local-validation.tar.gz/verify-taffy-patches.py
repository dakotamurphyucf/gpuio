from pathlib import Path
import hashlib, json, subprocess, tarfile, tempfile
vendor = Path('vendor/taffy').resolve()
manifest = json.loads((vendor / 'UPSTREAM.json').read_text())
archive = next(Path.home().joinpath('.cargo/registry/cache').glob('*/taffy-0.13.0.crate'))
digest = lambda data: hashlib.sha256(data).hexdigest()
assert digest(archive.read_bytes()) == manifest['crate_sha256']
with tempfile.TemporaryDirectory(prefix='gpuio-taffy-verify-') as directory:
    root = Path(directory)
    with tarfile.open(archive) as bundle:
        for name, expected in manifest['original_files_sha256'].items():
            relative = Path(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            member = bundle.getmember('taffy-0.13.0/' + name)
            assert member.isfile()
            data = bundle.extractfile(member).read()
            assert digest(data) == expected, name
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    for name in manifest['patches']:
        result = subprocess.run(['patch', '--batch', '--forward', '-p1', '-i', str(vendor / name)], cwd=root, text=True, capture_output=True, check=True)
        assert 'fuzz' not in result.stdout and 'offset' not in result.stdout, result.stdout
    for name in manifest['original_files_sha256']:
        assert (root / name).read_bytes() == (vendor / name).read_bytes(), name
assert digest((vendor / 'LICENSE').read_bytes()) == manifest['license_sha256']
print('TAFFY_RECONSTRUCTION_OK', len(manifest['original_files_sha256']), 'upstream files;', len(manifest['patches']), 'patches; license unchanged')
