import sys,time,ctypes as C
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import test_agent_chat_results as r
original=r.Results.columns
def columns(self):
    p,s=self.bounds('Run results','AXTable')
    w,ws=self.bounds(r.TITLE,'AXWindow')
    point=r.Point(p.x-8,w.y+ws.y/2)
    self.send(5,point)
    wheel=self.cg.CGEventCreateScrollWheelEvent
    wheel.restype,wheel.argtypes=C.c_void_p,[C.c_void_p,C.c_uint,C.c_uint,C.c_int]
    locate=self.cg.CGEventSetLocation
    locate.restype,locate.argtypes=None,[C.c_void_p,r.Point]
    event=wheel(None,0,1,5000)
    try:
        locate(event,point)
        self.key_flags(event,0)
        self.post(0,event)
    finally:self.release(event)
    time.sleep(.3)
    r.screenshot(self,Path('scratch/agents/root-20261004-resumed/results-geometry-top.png'),title=r.TITLE)
    return original(self)
click_original=r.Results.click
click_count=0
def click(self,point,right=False):
    print('CLICK_BEFORE',point.x,point.y,flush=True)
    self.send(5,point)
    self.send(1,point)
    try:
        time.sleep(.3)
        after=self.cell('000001')
        print('CLICK_AFTER_DOWN',after.x,after.y,flush=True)
        r.screenshot(self,Path('scratch/agents/root-20261004-resumed/results-after-down.png'),title=r.TITLE)
    finally:self.send(2,point)
    time.sleep(.3)
    after=self.cell('000001')
    print('CLICK_AFTER_UP',after.x,after.y,flush=True)
    self.dump(r.TITLE)
    raise RuntimeError('DIAGNOSTIC_COMPLETE')
r.Results.click=click
r.Results.columns=columns
r.main()
