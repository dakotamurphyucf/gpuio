from pathlib import Path
import os,subprocess
root=Path.cwd(); logs=root/'scratch/agents/root-20261004-resumed/mark-api'
env=os.environ.copy();env['GPUIO_JOBS']='2'
steps=[
 ('gallery-marks-qualified',['python3','scripts/test_gallery.py','--section','chart-marks','--images',str(logs/'gallery-images-qualified')]),
 ('gallery-marks-consumer',['python3','scripts/test_extension_consumer.py','--example','gallery','--run','--gallery-section','chart-marks','--workspace',str(logs/'installed-marks')]),
]
for name,args in steps:
 print('RUN',name,flush=True)
 with (logs/(name+'.log')).open('w') as log:
  result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('RESULT',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
