from pathlib import Path
import os, subprocess
root=Path.cwd();logs=root/'scratch/agents/root-20261004-resumed/mark-api'
env=os.environ.copy();env['GPUIO_JOBS']='2'
steps=[
 ('final-fmt-rust',['cargo','fmt','--all']),
 ('final-fmt-ocaml',['ocamlformat','-i','lib/core/chart.mli','lib/core/chart_style.mli','lib/core/chart_appearance.mli','lib/eio/chart_registry.ml','examples/gallery/chart_marks.ml','examples/gallery/chart_marks.mli','examples/gallery/charts_page.ml']),
 ('final-dune',['dune','build','-j2','@all','@runtest','@fmt']),
 ('final-native',['cargo','test','-p','gpuio-native','--features','native-canvas-tests,native-image-tests','--lib','--locked','-j2']),
 ('final-native-view',['cargo','test','-p','gpuio-native','--features','native-canvas-tests','--test','native_chart_view','--locked','-j2']),
 ('final-feature-clippy',['cargo','clippy','-p','gpuio-native','--features','native-canvas-tests,native-image-tests','--lib','--tests','--locked','-j2','--','-D','warnings']),
]
for name,args in steps:
 print('RUN',name,flush=True)
 with (logs/(name+'.log')).open('w') as log:
  r=subprocess.run(['./scripts/gpuio','exec',*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('RESULT',name,r.returncode,flush=True)
 if r.returncode: raise SystemExit(r.returncode)
