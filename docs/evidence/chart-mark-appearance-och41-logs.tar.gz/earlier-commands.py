from pathlib import Path
import os, subprocess
root=Path.cwd()
logs=root/'scratch/agents/root-20261004-resumed/mark-api'
env=os.environ.copy();env['GPUIO_JOBS']='2'
steps=[
 ('attached-fmt-rust', ['cargo','fmt','--all']),
 ('attached-fmt-ocaml', ['ocamlformat','-i','lib/core/chart.mli','lib/core/chart_style.ml','lib/core/chart_style.mli','lib/protocol/chart_style_wire.ml','lib/protocol/chart_view_wire.ml','test/chart/chart_style_test.ml','test/chart/chart_view_test.ml','test/chart/chart_node_labels_test.ml','test/chart/chart_pie_labels_test.ml','test/chart/chart_appearance_test.ml']),
 ('attached-core-final',['dune','build','-j2','@test/chart/runtest']),
 ('attached-protocol-max',['cargo','test','-p','gpuio-protocol','--test','chart_view','--locked','-j2']),
 ('attached-native-all',['cargo','test','-p','gpuio-native','--features','native-canvas-tests,native-image-tests','--lib','--locked','-j2']),
 ('attached-gpu',['cargo','test','-p','gpuio-native','--features','native-canvas-tests','--test','native_chart_paint','--locked','-j2']),
 ('attached-clippy',['cargo','clippy','--workspace','--all-targets','--locked','-j2','--','-D','warnings']),
 ('attached-feature-clippy',['cargo','clippy','-p','gpuio-native','--features','native-canvas-tests,native-image-tests','--lib','--tests','--locked','-j2','--','-D','warnings']),
]
for name,args in steps:
 print('RUN',name,flush=True)
 with (logs/(name+'.log')).open('w') as log:
  r=subprocess.run(['./scripts/gpuio','exec',*args],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('RESULT',name,r.returncode,flush=True)
 if r.returncode: raise SystemExit(r.returncode)
