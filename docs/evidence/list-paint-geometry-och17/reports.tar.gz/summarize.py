import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
totals = []
samples = []
for line in path.read_text().splitlines():
    if line.startswith('GPUIO_PAINT_TOTALS '):
        totals.append(json.loads(line.removeprefix('GPUIO_PAINT_TOTALS ')))
    if line.startswith('GPUIO_PAINT_GEOMETRY '):
        samples.append(json.loads(line.removeprefix('GPUIO_PAINT_GEOMETRY ')))
assert totals, 'No paint observations'
assert [t[0] for t in totals] == list(range(1, len(totals) + 1))
assert len(totals) < 100000, 'Diagnostic output cap reached'
assert all(all(a <= b for a,b in zip(left,right)) for left,right in zip(totals,totals[1:]))
# Independently verify retained sample geometry; all-frame counts come from Rust.
for sample in samples:
    rows = sorted((r for r in sample['painted'] if r['kind'] != 'content'), key=lambda r:r['index'])
    overlaps = []
    for left,right in zip(rows, rows[1:]):
        end = left['bounds'][1] + left['bounds'][3]
        if end > right['bounds'][1] + .5:
            overlaps.append([left['index'], right['index'], end-right['bounds'][1]])
    assert bool(overlaps) == any(s.startswith('overlap:') for s in sample['issues'])
report = {
    'diagnostic_only': True,
    'list_paint_callbacks': totals[-1][0],
    'row_paints': totals[-1][1],
    'placeholder_paints': totals[-1][2],
    'frames_with_geometry_issue': totals[-1][3],
    'frames_at_record_cap': totals[-1][4],
    'frames_without_row_records': sum(right[1] == left[1] for left,right in zip([[0]*5]+totals,totals)),
    'retained_geometry_samples':len(samples),
    'issues': [s for s in samples if s['issues']],
    'limitations': 'Paint callback geometry, not captured display pixels or presentation cadence; diagnostic logging perturbs timing.',
}
print(json.dumps(report, indent=2))
