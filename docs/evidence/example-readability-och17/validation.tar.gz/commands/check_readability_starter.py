from pathlib import Path
import subprocess, sys
sys.path.insert(0, str(Path('scripts').resolve()))
from test_agent_chat import Mac
binary = Path('scratch/agents/root-20261004-resumed/readability-starter-consumer/consumer/_build/default/main.exe').resolve()
child = subprocess.Popen([str(binary)])
try:
    mac = Mac(child.pid, child)
    title = 'GPUIO · Getting started'
    mac.wait_text(title, 'Count: 0')
    for n in range(1, 4):
        mac.press(title, 'Increment')
        mac.wait_text(title, f'Count: {n}')
    mac.press(title, 'Reset')
    mac.wait_text(title, 'Count: 0')
    mac.press(title, 'Close')
    assert child.wait(timeout=15) == 0
    print('STARTER_PASS increment/reset/normal closure; child reaped')
finally:
    if child.poll() is None:
        child.terminate()
        try: child.wait(timeout=5)
        except subprocess.TimeoutExpired: child.kill(); child.wait()
