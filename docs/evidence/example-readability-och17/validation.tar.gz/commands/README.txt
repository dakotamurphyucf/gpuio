Source base: bdab7f1. Local macOS 14.5 arm64. Repository OCaml 5.3/Bonsai v0.17/Core/Eio environment.
PASS: GPUIO_JOBS=2 ./scripts/gpuio exec dune build -j 2 examples/getting_started/main.exe examples/gallery/main.exe examples/agent_chat/main.exe examples/signal_studio/main.exe @runtest @fmt
PASS: GPUIO_JOBS=2 python3 scripts/test_extension_consumer.py --example getting_started --workspace scratch/agents/root-20261004-resumed/readability-starter-consumer
PASS: GPUIO_JOBS=2 python3 scripts/test_extension_consumer.py --example gallery --workspace scratch/agents/root-20261004-resumed/readability-gallery-consumer
PASS: GPUIO_JOBS=2 python3 scripts/test_extension_consumer.py --example signal_studio --workspace scratch/agents/root-20261004-resumed/readability-signal-consumer
Initial GUI batch (run_readability_checks.py): metadata and chat/Signal self-tests PASS; gallery core INCOMPLETE at outer 120s timeout, subsequent feedback not run.
First targeted batch (run_readability_targeted.py): obsolete Level: 35 assertion FAIL; preserved *-stale-label.log. Corrected batch PASS all five checks.
PASS: python3 -u scratch/agents/root-20261004-resumed/check_readability_starter.py
PASS: python3 -m py_compile scripts/test_gallery.py
PASS: git diff --check
Initial reserved-keyword compile/format failures retained. No expectations promoted.
Hosted 37387307992 tests earlier f6e34e2; not this source.
