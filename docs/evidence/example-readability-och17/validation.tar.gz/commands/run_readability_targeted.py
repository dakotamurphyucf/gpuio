from pathlib import Path
import os,signal,subprocess,sys,tempfile
sys.path.insert(0,str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
root=Path.cwd(); logs=root/'scratch/agents/root-20261004-resumed'
def run(args,name,timeout=240):
 with (logs/name).open('w') as log:
  child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   code=child.wait(timeout=timeout)
   assert code==0,(name,code)
  finally:
   if child.poll() is None:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 print('PASS',name,flush=True)
gallery=logs/'readability-gallery-consumer/consumer/_build/default/main.exe'
signal_binary=logs/'readability-signal-consumer/consumer/_build/default/main.exe'
with preserved_clipboard():
 run([sys.executable,'scripts/test_gallery.py','--executable',str(gallery),'--section','shell'],'readability-gallery-shell.log')
 run([sys.executable,'scripts/test_gallery.py','--executable',str(gallery),'--section','feedback'],'readability-gallery-feedback.log')
 run([sys.executable,'scripts/test_macos_window_lifecycle.py','--executable',str(gallery),'--custom-chrome','--output',str(logs/'readability-custom-chrome')],'readability-custom-chrome.log')
 with tempfile.TemporaryDirectory(prefix='gpuio-readability-') as directory:
  run([str(signal_binary),'--self-test','--document-path='+directory+'/workspace.sexp'],'readability-signal-document.log')
 run([sys.executable,'scripts/test_signal_studio.py','--executable',str(signal_binary),'--output',str(logs/'readability-signal-walkthrough')],'readability-signal-walkthrough.log')
print('All children reaped; saved clipboard restored',flush=True)
