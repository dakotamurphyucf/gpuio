from pathlib import Path
import os,signal,subprocess,sys,plistlib
root=Path.cwd(); logs=root/'scratch/agents/root-20261004-resumed'
def run(args, name, timeout=120):
    with (logs/name).open('w') as log:
        child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            code=child.wait(timeout=timeout)
            assert code==0,(args,code)
        finally:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL);child.wait()
    print('PASS',name,flush=True)
for example,identifier in [('gallery','com.gpuio.component-studio'),('agent_chat','com.gpuio.agent-chat'),('signal_studio','com.gpuio.signal-studio')]:
    binary=root/f'_build/default/examples/{example}/main.exe'
    data=subprocess.check_output([str(binary),'--print-info-plist'],timeout=10)
    info=plistlib.loads(data)
    if example!='gallery':assert info['CFBundleIdentifier']==identifier,info
    (logs/f'readability-{example}-info.plist').write_bytes(data)
    print('METADATA',example,info['CFBundleIdentifier'],flush=True)
run([str(root/'_build/default/examples/agent_chat/main.exe'),'--self-test'],'readability-chat-self-test.log')
run([str(root/'_build/default/examples/signal_studio/main.exe'),'--self-test'],'readability-signal-self-test.log')
run([sys.executable,'scripts/test_gallery.py','--section','core'],'readability-gallery-core.log')
run([sys.executable,'scripts/test_gallery.py','--section','feedback'],'readability-gallery-feedback.log')
