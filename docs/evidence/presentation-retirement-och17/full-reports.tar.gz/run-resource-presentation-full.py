import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
binary=Path('_build/default/examples/resource_audit/main.exe')
assert not subprocess.check_output(['git','status','--porcelain']).strip()
assert len(json.loads((base/'resource-presentation-validation.json').read_text()))==5
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
assert sha=='37a988883d90530d1002112579e330b522a7bd08e1596da94ed4d10f01bf3e95'
report=dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),executable_sha256=sha,
 plan='After completed smoke-002, exactly three independent full runs of three warmups plus thirty measured lifecycle cycles. Active presentation, native entities, Metal allocations, physical memory and closed IOSurface checks. Existing limits unchanged. Retain every outcome; stop batch on any failing run.',trials=[],running=None)
awake=subprocess.Popen(['/usr/bin/caffeinate','-di','-w',str(os.getpid())])
try:
 for n in ('001','002','003'):
  command=['python3','scripts/measure_resource_lifecycle.py','--build-profile','release','--native-entities','--presentation','--metal-memory','--physical-memory','--check-closed-surfaces','--check-budgets','--executable',str(binary),'--timeout','600','--output',str(base/f'resource-presentation-full-{n}')]
  report['running']=n
  (base/'resource-presentation-full-batch.json').write_text(json.dumps(report,indent=2)+'\n')
  print('START',n,flush=True)
  with (base/f'resource-presentation-full-{n}.log').open('w') as output:
   result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
  child=json.loads((base/f'resource-presentation-full-{n}/report.json').read_text())
  report['trials'].append(dict(name=n,command=command,driver_exit=result.returncode,child_exit=child.get('returncode'),complete=child['complete'],failure=child.get('failure')))
  report['running']=None
  (base/'resource-presentation-full-batch.json').write_text(json.dumps(report,indent=2)+'\n')
  print('FINISH',report['trials'][-1],flush=True)
  if result.returncode or not child['complete']: sys.exit(1)
finally:
 awake.terminate();awake.wait(timeout=5)
 report['keep_awake_reaped']=True
 (base/'resource-presentation-full-batch.json').write_text(json.dumps(report,indent=2)+'\n')
