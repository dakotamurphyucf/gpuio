from pathlib import Path
import json,os,subprocess,sys
base=Path(__file__).resolve().parent
commands=[
 ['cargo','test','--offline','--manifest-path','examples/resource_audit/rust/Cargo.toml','--locked','--lib','-j2'],
 ['cargo','clippy','--offline','--manifest-path','examples/resource_audit/rust/Cargo.toml','--locked','--features','presentation-diagnostics','--all-targets','-j2','--','-D','warnings'],
 ['cargo','metadata','--offline','--manifest-path','examples/resource_audit/backend/Cargo.toml','--format-version','1'],
 ['dune','runtest','-j2','examples/resource_audit/ocaml'],
 ['dune','build','--profile','release','-j2','examples/resource_audit/main.exe','examples/performance_lifecycle/main.exe'],
]
results=[]
for n,args in enumerate(commands,1):
 log=base/f'resource-presentation-validation-{n:02}.log'
 command=['./scripts/gpuio','exec',*args]
 print('START',command,flush=True)
 with log.open('w') as output:
  child=subprocess.run(command,env={**os.environ,'GPUIO_JOBS':'2'},stdout=output,stderr=subprocess.STDOUT)
 results.append(dict(command=command,exit=child.returncode,log=str(log)))
 (base/'resource-presentation-validation.json').write_text(json.dumps(results,indent=2)+'\n')
 print('FINISH',child.returncode,flush=True)
 if child.returncode:sys.exit(child.returncode)
