import sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
import test_gallery as g
original=g.expect_focus
def diagnostic(mac,*args,**kwargs):
    try:return original(mac,*args,**kwargs)
    except Exception:
        active=mac.attr(mac.app,'AXFocusedUIElement')
        if active:
            try:print('ACTUAL_FOCUS',*[mac.text(active,k) for k in ['AXRole','AXTitle','AXDescription','AXValue']],flush=True)
            finally:mac.release(active)
        raise
g.expect_focus=diagnostic
g.main()
