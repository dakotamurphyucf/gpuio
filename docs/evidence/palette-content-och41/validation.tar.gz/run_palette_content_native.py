import os
from pathlib import Path
import re
import signal
import subprocess
import sys
sys.path.insert(0,str(Path('scripts').resolve()))
from mac_clipboard import preserved_clipboard
log=Path('scratch/agents/root-20261004-resumed/palette-content-os-build-final.log').read_text()
match=re.findall(r'Executable tests/native_palette.rs \(([^)]+)\)',log)
assert len(match)==1, 'Missing unambiguous compiled native test executable'
executable=Path(match[0]).resolve()
with preserved_clipboard():
    process=subprocess.Popen([str(executable)],start_new_session=True)
    try:
        code=process.wait(timeout=180)
        assert code==0, f'Native palette exit {code}'
    finally:
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGTERM)
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
print('Native palette child reaped; original clipboard restored')
