import hashlib, json, subprocess
from pathlib import Path
base = Path(__file__).resolve().parent
report = dict(exit=0, command='GPUIO_JOBS=2 ./scripts/gpuio exec dune build --profile release -j2 examples/performance_plain/main.exe examples/performance_presented/list/main.exe', revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), binaries={}, feature_verification=False)
for variant, relative, manifest, package in [
 ('A','examples/performance_plain/main.exe','Cargo.toml','gpuio-native'),
 ('B','examples/performance_presented/list/main.exe','examples/performance_presented/backend/Cargo.toml','gpuio-presentation-backend')]:
 p = Path('_build/default') / relative
 data = p.read_bytes()
 assert b'GPUIO_TRACE_IDLE' not in data and b'GPUIO_METAL_STARTUP' not in data
 cmd = ['./scripts/gpuio','exec','cargo','tree','--locked','--offline','--manifest-path',manifest,'-p',package,'--edges','normal','--format','{p} features=[{f}]']
 result = subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (base / f'collector-overhead-features-{variant}.log').write_text(result.stdout)
 assert result.returncode == 0
 selected = [line for line in result.stdout.splitlines() if any(name in line for name in ['gpuio-native v','gpui v','gpuio-performance-probe v','gpui_apple v'])]
 assert selected
 if variant == 'A':
  assert all('profiler' not in line and 'presentation-diagnostics' not in line and 'gpuio-performance-probe v' not in line for line in selected)
 else:
  assert any('gpuio-native v' in line and 'presentation-diagnostics' in line for line in selected)
  assert any('gpui v' in line and 'profiler' in line and 'presentation-diagnostics' in line for line in selected)
  assert any('gpuio-performance-probe v' in line and 'presentation-diagnostics' in line for line in selected)
 report['binaries'][variant] = dict(path=str(p),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),feature_command=cmd,selected_features=selected)
report['feature_verification'] = True
(base / 'collector-overhead-build.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
