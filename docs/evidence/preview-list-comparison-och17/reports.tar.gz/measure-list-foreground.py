"""One startup activation before measurement; never reactivate during a phase."""
import ctypes as C
from pathlib import Path
import sys, time
sys.path.insert(0, str(Path.cwd() / 'scripts'))
import measure_list_history as driver
from test_agent_chat import Mac
original_collect = driver.collect

def foreground_collect(executable, log_path, report, timeout, **kwargs):
    Mac.require_accessibility()
    state = dict(policy='One owned-window raise/activation before the history begin record; no activation or AX queries during measurement', requested=False, confirmed=False)
    report['foreground_preflight'] = state
    mac = None
    started = time.monotonic()
    def poll(child):
        nonlocal mac
        if state['confirmed']:
            return
        text = log_path.read_text()
        if 'GPUIO_PERF begin ' in text or 'GPUIO_PERF wall-begin ' in text:
            raise RuntimeError('Measurement began before foreground preflight completed')
        if 'GPUIO_PERF config ' not in text:
            return
        if mac is None:
            mac = Mac(child.pid, child)
        if not state['requested']:
            window = mac.window('GPUIO · Performance qualification')
            if not window:
                return
            try:
                mac.set(mac.app, 'AXFrontmost', mac.true)
                mac.perform(window, 'AXRaise')
            finally:
                mac.release(window)
            state.update(requested=True, request_seconds=time.monotonic()-started)
        value = mac.attr(mac.app, 'AXFrontmost')
        if value:
            get = mac.cf.CFBooleanGetValue
            get.restype, get.argtypes = C.c_bool, [C.c_void_p]
            try:
                active = bool(get(value))
            finally:
                mac.release(value)
            if active:
                # Verify that even the completed AX read preceded the phase boundary.
                text = log_path.read_text()
                if 'GPUIO_PERF begin ' in text or 'GPUIO_PERF wall-begin ' in text:
                    raise RuntimeError('Foreground read overlapped measurement start')
                state.update(confirmed=True, confirmed_seconds=time.monotonic()-started)
                mac.release(mac.app)
                mac = None
        if state['requested'] and time.monotonic()-started-state['request_seconds'] > 5:
            raise RuntimeError('One-time foreground activation was not confirmed')
    try:
        original_collect(executable, log_path, report, timeout, on_poll=poll, **kwargs)
        if not state['confirmed']:
            raise RuntimeError('Missing foreground preflight evidence')
    finally:
        if mac is not None:
            mac.release(mac.app)

driver.collect = foreground_collect
driver.main()
