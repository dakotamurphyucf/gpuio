"""Real OS-routed measured-track gesture checks; no hardware trackpad claim."""
import ctypes as C
import json
import time


def exercise(mac, images=None):
    from test_gallery import (
        TITLE, GalleryMouse, activate, element_rect, focus_gallery_control,
        reveal_gallery_control,
    )

    label = 'Measured idea cards'
    report = {'complete': False, 'events': [],
              'scope': 'synthetic CG events through AppKit; not physical trackpad hardware'}
    mouse = GalleryMouse(mac)
    create = mac.cg.CGEventCreateScrollWheelEvent2
    create.restype, create.argtypes = C.c_void_p, [C.c_void_p, C.c_uint, C.c_uint, C.c_int, C.c_int, C.c_int]
    set_integer = mac.cg.CGEventSetIntegerValueField
    set_integer.restype, set_integer.argtypes = None, [C.c_void_p, C.c_int, C.c_longlong]
    get_integer = mac.cg.CGEventGetIntegerValueField
    get_integer.restype, get_integer.argtypes = C.c_longlong, [C.c_void_p, C.c_int]
    locate = mac.cg.CGEventSetLocation
    locate.restype, locate.argtypes = None, [C.c_void_p, GalleryMouse.Point]
    post_pid = mac.cg.CGEventPostToPid
    post_pid.restype, post_pid.argtypes = None, [C.c_int, C.c_void_p]
    caption = None

    def scroll(point, dx, dy, phase):
        event = create(None, 0, 2, dy, dx, 0)  # Pixel units; fixed arity on arm64.
        assert event
        try:
            set_integer(event, 99, phase)  # CoreGraphics CGScrollPhase.
            assert get_integer(event, 88) == 1, 'Event is not precise scrolling'
            assert get_integer(event, 97) == dx and get_integer(event, 96) == dy
            locate(event, GalleryMouse.Point(*point))
            post_pid(mac.pid, event)
            report['events'].append(dict(dx=dx, dy=dy, phase=phase))
        finally:
            mac.release(event)

    try:
        mac.press(TITLE, 'Carousels & journeys')
        mac.wait_text(TITLE, 'Selected card: Capture')
        activate(mac, mac.wait_find(TITLE, 'Compact viewport', 'AXCheckBox'))
        x, y, w, h = reveal_gallery_control(mac, label, 'AXGroup')
        focus_gallery_control(mac, label, 'AXGroup')
        caption = mac.wait_find(TITLE, 'Selected card: Capture', 'AXStaticText')
        point = (x + w / 2, y + h - 8)
        mouse.check_owner(point)
        mouse.send(5, point)
        # CG phase values are Began=1, Changed=2, Ended=4, Cancelled=8.
        # AppKit converts these to NSEventPhase (1,4,8,16 respectively).
        # Deliver both without crossing the native 28ms quiet fallback.
        scroll(point, -200, 0, 1)
        # Cancellation must discard the terminal delta and preceding preview.
        scroll(point, -1, 0, 8)
        start = time.monotonic()
        observed = []
        while time.monotonic() - start < .7:
            value = mac.text(caption, 'AXTitle')
            observed.append(value)
            time.sleep(.02)
        report['cancel_observations'] = observed
        assert all(value == 'Selected card: Capture' for value in observed), (
            'Cancelled gesture changed selection', observed)
        # The same movement with a real end must select the nearest measured stop.
        scroll(point, -200, 0, 1)
        scroll(point, -1, 0, 4)
        mac.wait_text(TITLE, 'Selected card: Explore')
        report['complete'] = True
        print('GALLERY_CAROUSEL_GESTURES_OK: native cancelled versus ended precise scroll', flush=True)
    except BaseException as error:
        report['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        if caption:
            mac.release(caption)
        if images:
            (images / 'carousel-gestures-report.json').write_text(json.dumps(report, indent=2) + '\n')
