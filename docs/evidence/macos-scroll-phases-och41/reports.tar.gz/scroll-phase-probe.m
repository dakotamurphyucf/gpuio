#import <Cocoa/Cocoa.h>
int main(void) {
  @autoreleasepool {
    for (int phase = 1; phase <= 8; phase *= 2) {
      CGEventRef event = CGEventCreateScrollWheelEvent2(NULL, kCGScrollEventUnitPixel, 2, 0, -200, 0);
      CGEventSetIntegerValueField(event, kCGScrollWheelEventScrollPhase, phase);
      NSEvent *native = [NSEvent eventWithCGEvent:event];
      printf("cg_phase=%d native_phase=%lu precise=%d x=%.0f y=%.0f\n", phase, (unsigned long)native.phase, native.hasPreciseScrollingDeltas, native.scrollingDeltaX, native.scrollingDeltaY);
      CFRelease(event);
    }
  }
}
