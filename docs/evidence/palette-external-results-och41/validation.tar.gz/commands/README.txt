Base 37303a5, macOS 14.5 arm64; GPUIO_JOBS=2 throughout.
./scripts/gpuio exec dune build -j 2 @test/view_api/runtest lib/eio/gpuio_eio.cmxa examples/gallery/main.exe
./scripts/gpuio exec cargo test -p gpuio-protocol --test palette_state --locked -j 2
./scripts/gpuio exec cargo clippy -p gpuio-native -p gpuio-protocol --features gpuio-native/native-image-tests,gpuio-native/native-canvas-tests --all-targets --locked -j 2 -- -D warnings
./scripts/gpuio exec cargo test -p gpuio-native --features native-image-tests,native-canvas-tests --lib --locked -j 2
./scripts/gpuio exec dune build -j 2 @runtest @fmt examples/gallery/main.exe
python3 scripts/test_extension_consumer.py --example gallery --workspace scratch/agents/root-20261004-resumed/palette-results-consumer
python3 scratch/agents/root-20261004-resumed/run_palette_results_installed_gui.py
./scripts/gpuio build
./scripts/gpuio check-fmt
python3 -m py_compile scripts/test_gallery.py
git diff --check
Retained failures: gallery interface/record qualification; native composition range type; final page-state assertion; old malformed tag3 fixture; formatting-only corrections. Final logs establish coverage.
Full protocol: ./scripts/gpuio exec cargo test -p gpuio-protocol --locked -j 2
Consumer demo-only refresh: copy examples/gallery/external_palette_preview.ml to consumer/, set OCAMLPATH to workspace/installed/lib and run ./scripts/gpuio exec dune build --root workspace/consumer -j 2 main.exe @document_profile/test/runtest. Installed libraries unchanged. Re-run --check-catalogs and installed Feedback.
Archive source patch excludes untracked files; new production modules/driver/design are separately included.
