# External palette results WIP at37303a5, 2026-10-06 UTC
OCH-41 remainsopen. No GUI run yet. No featurecommit yet.

Core Results.create/create_entries (validated configured commandreferences+groups),
Search.External, Publish_results (alwaysqueryfenced), Eio.publish_results.
Protocolpaired tag5command/tag3policy/Invalid_results error9; rejectsabsentfence.
Nativepalette retains boundedIDs/layout withobserver+nativeeditorrevision;
retirementqueryABA/composition/configIDchange/policy/detach/close; emptyuntilpublish;
publishatomicrows+loadingfalse, preservedselection/undo; sequencechangesforreorder;
originaldeclared_index retainedforrichslots. Externalmode reserves2MiBat treeadmission.
Newdesign docs/design/palette-external-results.md explicitlyWIPandstagecontract.

Staging uses existingDriver acceptedLifecycle snapshots (not renderedframes).
Newruntimeexpecttest proves source1lifecycle runs afternativeAccepted even when
source2arriveswhilepending. NewExternal_palette_preview demo usespageownedEioscope,
requestserial/nativequery checks/cancel, dynamiccommandIDs/richrows, on_change
lifecyclepublishing. Eiosearchcapabilityclosure passedapplication->component->pages
->Feedback. Demo Searchworkspace titleWorkspace search. Queryslow0.8s,others0.18s,
missingempty; labels=querynotes/references, >256bytequeryusesboundedgenericlabels.
Coreonobserveinitialstate can'tusecontrollert.snapshotNoneforSetLoading, soExpert
usescapturednativeobservationdirectly. Chooser mounts onlyScopeReady.
Newdriverhelper scripts/gallery_external_palette.py calledafterFeedbackexisting
checks. Testsrealtypingz supersedesslow, nativeEnter/Down,empty/replacement,close/
pagecleanup. Notexecutedyet. Usesexistingtest_gallery Machelpers/screenshots.

Completed:
30051 Rustall-targetcheckPASS.
79908 OCamlFAIL recordfieldnamespace;33443 correctedCore/EioPASS.
13681 nativeexternalfilter4PASS (2new+2existingunrelated).
80879 protocol4PASS thennativecompileFAILwrong bridge_composition type(Range).
24937 correctedexpandednative3/3PASS.
23468 protocol5/5PASS (independentfixtures,missingfence,malformedgroups,bounds).
41018 GalleryFAILmissingupdatedmliarg;19425 FAIL Pagesml/mliargorder;
56887 FAILCandidatefieldnamespace;21825 correctedgallery+@test/runtimePASS.
33574 fmt firstexit1 format-onlypromoted; no expectoutputpromoted.

LIVE:55004strictClippy logfilepalette-results-clippy.log.
LIVE: newrootDunehandle (capturefromtoolresponse) runsfmt thenfull@runtest/@fmt/gallery,
logpalette-results-fmt-final.log,palette-results-ocaml-full.log.
Do NOT startanotherrootDune untilterminal. NoGUI/nootherlocalhandles.

Next polls -> resolveClippy/build, fullnative/protocol suites. ActuallocalFeedback
usingbuiltgallery withsavedclipboard wrapper; thenfreshinstalledconsumer/currentGUI.
Add resource/lifecycle evidence and inspect screenshot, archivefailures/source/logs,
updateledger/status/Linear,commitpublishreviewbranch. CI37400903839 stillliveat2e9;
do notcancel bypushingnormalPRbranch. Native/fmt/etcnotwholecatalogacceptance.

2026-10-06 resumed: 86515 terminal exit0: full @runtest/@fmt/gallery PASS.
55004 strict Clippy PASS per prior output. Starting local Feedback GUI; next full native suite.

70673 GUI terminal FAIL final assertion expecting page state reset; all external
query/typing/empty/activation/close cases passed before it. Bonsai branch state persists.
Retained failure log palette-results-gallery-local-failed-001.log. Fix expectation
to preserved selection; explicitly retire transient opened/candidate/controller on
page deactivation; validate fresh reopened query after page revisit. No assertion
of pending producer cancellation via page switch: modal Escape cancels it first.
23417 native full terminal log:971 passed,2 existing ignored,0 failed.

39501 rebuild gallery/@runtest PASS. 50375 corrected full Feedback PASS, including
new delayed results/native typing/empty result/Down+Enter/cancel/page return/reopen.
Screenshot inspected: readable two rich rows, selected first row, query and footer.
Driver reaped, saved clipboard restored. Starting fresh installed consumer and
full protocol suite; no GUI running. Root Dune reserved for consumer until exit.

20529 full protocol FAIL: old palette_options malformed-tag fixture still used3,
which is now valid External. Change unknown tag to4 and add independent External
encode/decode fixture. Production decoder correctly accepted3. Re-run full suite.

25092 fresh installed consumer PASS;8829 installed full Feedback PASS, binary
1d0a4b1b43c094107a9e79ce34c3db26cb4abcb2e118d63895983a3597e17623.
21736 full protocol PASS414 tests after fixture correction.
67476 check-fmt FAIL only Rust independent-fixture line wrapping; fmt applied.
Source review: guard delayed Set_loading acknowledgement before starting producer,
so an already closed/superseded request does not launch unnecessary work. Demo-only
change requires rebuild/retest; production libraries unchanged.
36889 fmt formatting-only exit1 (promoted source, no expect output);31450 second
fmt then all-example build LIVE. Next refresh demo ML in existing independent
consumer (installed libs unchanged), rebuild and repeat Feedback against final demo.
No GUI running now. Final docs/archive/Linear/commit still pending.

31450 all-example build+second fmt PASS. 5001 consumer demo refresh PASS.
47832 final GUI FAIL before external checks: existing Preview commands initial
query focus, AXWindow focused. Same symptom as prior loading slice, cause unknown.
All-example linking overlapped; don't claim causation. Retained focus-failed log
and screenshot. 65031 same-binary full repeat LIVE after all-build complete.
82652 finalcheckfmt/strictClippy LIVE. No root compilation or otherGUI.

65031 final installed Feedback PASS (same binary as preserved focus failure).
82652 finalcheckfmt and strict all-target Clippy PASS. 31450 all-example build PASS.
Final binary4221296fc87003fed8e961feb6a46ef40c6b5dc7a18e9797c616d91865629582.
All local handles terminal, no GUI. Final screenshot retained/inspected alongside
local rendering. Evidence/design/status/catalog now updated; archive/commit next.
Full native971+2existingignored; fullprotocol414; OCamlfullsuite passed.
Remainingrelease focusfailure still unexplained, no120FPS/IME/VO/LinuxGUIclaim.
